
/* ===== 定義 ===== */
const O={ // 93-067 選択肢マスタ（この通り。足さない）
 aite:['本気','情報収集','うんざり','他社先行','仕事中・移動中'],
 kbn:['マスト','できたら'],
 shokureki:['一つの職場が長い','複数の職場を経験','ブランクあり','新卒・第二新卒'],
 yakin:['あり（二交代）','あり（三交代）','なし','もうやりたくない'],
 kikkake:['給与','人間関係','夜勤・体力','家庭の事情','通勤','評価・昇給','職場の方針','漠然・情報収集'],
 fuman:['人間関係','評価・昇給','夜勤・体力','残業','家庭との両立','職場の方針','教育体制','その他'],
 kyuyo:['上げたい','同じくらいでいい','他を優先して少し下がってもいい'],
 renraku:['ショートメッセージ','電話','LINE','メール'],
 jikantai:['日中（10〜16時）','夕方（16〜18時）','夜（18時〜）','朝（〜10時）','土日'],
 tsuyomi:['急変対応','家族への説明','新人の指導','多職種連携','記録の正確さ','看取り','認知症ケア','在宅・訪問','段取り・調整','夜勤帯を任される','子どもの安全','保護者対応','行事の企画','献立・発注','衛生管理','その他'],
 hani:['未確認','全部可','人となりのみ','条件のみ','不可'],
 honne:['取れた','一回目は出ず','確認のみ','表向きと同じだった'],
 nashi:['求人なし','条件不一致','意向低'],
 tasha:['有','無','確認中'],
 sms:['可','不可']
};
// 入力欄（93-067 の項目。src: 新規／既存）
const F=[
 // ① 入口
 {id:'aite',p:1,g:'0.5 相手の状態',l:'相手の状態',t:'sel',o:O.aite,req:1,src:'新規'},
 {id:'koyou',p:1,g:'1.5 確認',l:'希望雇用形態',t:'text',req:1,src:'既存マスタ「雇用形態」',ph:'既存マスタから選ぶ'},
 {id:'shikaku',p:1,g:'1.5 確認',l:'保有資格',t:'text',src:'既存',ph:'登録情報を読み上げて確認'},
 {id:'keiken',p:1,g:'1.5 確認',l:'経験職種／経験施設形態',t:'text',src:'既存',ph:'病棟・診療科・施設形態'},
 {id:'shokureki',p:1,g:'1.5 確認',l:'職歴の形',t:'sel',o:O.shokureki,src:'新規'},
 {id:'yakin',p:1,g:'1.5 確認',l:'夜勤経験',t:'sel',o:O.yakin,src:'新規'},
 {id:'gessyu',p:1,g:'1.5 確認',l:'現在の月収',t:'num',unit:'万円（夜勤込み）',src:'既存'},
 // ② ストーリー
 {id:'kikkake',p:2,g:'2-1 転職のきっかけ',l:'転職のきっかけ分類',t:'chk',o:O.kikkake,src:'新規',hint:'CAが分類。本人の言葉は面談メモへ'},
 {id:'memo',p:2,g:'2-1 転職のきっかけ',l:'面談メモ',t:'ta',src:'既存（拾った言葉）',ph:'相手の言葉をそのまま。一行に一つ　例：「夜勤がきつくなってきた」',rows:4},
 {id:'jiki',p:2,g:'2-2 転職時期',l:'希望転職時期（紹介）',t:'text',src:'既存',ph:'「未定」も値。空にしない',must:'jiki'},
 {id:'haikei',p:2,g:'背景',l:'背景メモ',t:'ta',src:'新規（4000）',ph:'通勤・時期・給与の背景、下げてもいい理由、動く条件',w:3},
 // ③ 希望
 {id:'tsukin',p:3,g:'5-1 通勤圏',l:'通勤許容時間',t:'num',unit:'分',src:'既存',must:'tsukin'},
 {id:'shudan',p:3,g:'5-1 通勤圏',l:'通勤手段',t:'text',src:'既存',ph:'電車／車 など（既存マスタ）',must:'tsukin'},
 {id:'tsukin_kbn',p:3,g:'5-1 通勤圏',l:'通勤の区分',t:'seg',o:O.kbn,src:'新規'},
 {id:'kyuyo_hoko',p:3,g:'5-2 希望給与',l:'希望給与の方向',t:'sel',o:O.kyuyo,req:1,src:'新規',must:'kyuyo'},
 {id:'kyuyo_must',p:3,g:'5-2 希望給与',l:'給与マスト',t:'num',unit:'万円（月給）これを割ったら提案しない',req:1,src:'新規',must:'kyuyo'},
 {id:'kyuyo_dekitara',p:3,g:'5-2 希望給与',l:'希望の月収',t:'num',unit:'万円（できたら）',src:'既存'},
 {id:'kinmu',p:3,g:'5-3 勤務形態',l:'希望勤務形態（看）',t:'text',src:'既存',ph:'日勤のみ／夜勤可 など（既存マスタ）',must:'kinmu'},
 {id:'oncall',p:3,g:'5-3 勤務形態',l:'オンコール/当直',t:'text',src:'既存（項目の有無 要確認）',ph:'不可／相談／可'},
 {id:'kinmu_kbn',p:3,g:'5-3 勤務形態',l:'勤務形態の区分',t:'seg',o:O.kbn,src:'新規'},
 {id:'yasumi',p:3,g:'5-4 休日',l:'希望の休み曜日',t:'text',src:'既存',ph:'土日 など'},
 // ④ 戻り
 {id:'fuman',p:4,g:'5.5 戻り',l:'現状の不満',t:'chk',o:O.fuman,src:'新規',hint:'マストの源泉'},
 {id:'honne',p:4,g:'5.5 戻り',l:'転職理由（本音）',t:'ta',src:'新規・要配慮',ph:'戻りでしか出ない。表向きと分けて',w:3},
 {id:'honne_st',p:4,g:'5.5 戻り',l:'本音の取得状況',t:'sel',o:O.honne,src:'新規',hint:'空欄と「出なかった」は違う'},
 {id:'renraku',p:4,g:'6-2 連絡',l:'連絡手段',t:'chk',o:O.renraku,req:1,src:'新規',must:'renraku'},
 {id:'jikantai',p:4,g:'6-2 連絡',l:'連絡可能時間帯',t:'chk',o:O.jikantai,req:1,src:'新規',must:'renraku'},
 {id:'renraku_kibo',p:4,g:'6-2 連絡',l:'連絡方法に関する希望',t:'text',src:'既存',ph:'避けたい時間帯と理由'},
 {id:'tasha',p:4,g:'7 他社',l:'他社利用',t:'sel',o:O.tasha,req:1,src:'既存マスタ',must:'tasha'},
 // ⑤ 締め
 {id:'hitotonari',p:5,g:'8 締め',l:'人となりメモ',t:'ta',src:'新規（4000）',ph:'施設に伝えてほしいこと・得意・エピソード・休日・やりたいこと・返した良さ',rows:4},
 {id:'hani',p:5,g:'8 締め',l:'施設に伝えてよい範囲',t:'sel',o:O.hani,src:'新規',hint:'推薦文を送る前に必ず'},
 {id:'appo',p:5,g:'8 締め',l:'次回アポ日時',t:'dt',req:1,src:'新規',must:'appo',hint:'空なら24h／4日でSMSが追う'},
 {id:'sms',p:5,g:'8 締め',l:'SMS連絡の同意',t:'sel',o:O.sms,req:1,src:'既存マスタ',hint:'自動配信の入口。未選択＝(空白)'},
 {id:'tanto',p:5,g:'8 締め',l:'担当への希望',t:'text',src:'新規',ph:'サポート役・引き継ぎ相手への希望'},
 {id:'yakusoku',p:5,g:'8 締め',l:'施設に確認すると約束したこと',t:'ta',src:'新規',ph:'内容と期限。返さないと信用が消える'},
 {id:'nashi',p:5,g:'通話のあと',l:'紹介先なしの理由',t:'sel',o:O.nashi,src:'新規',hint:'紹介先が無かったときだけ'},
 // 下の面
 {id:'tsuyomi',p:0,l:'強みタグ',t:'chk',o:O.tsuyomi,src:'新規'}
];
const FM=Object.fromEntries(F.map(f=>[f.id,f]));
// マスト8（93-046）
const MUST=[
 {k:'aite',l:'相手の状態',ok:v=>!!v.aite,p:1},
 {k:'tsukin',l:'通勤圏（値＋手段）',ok:v=>!!v.tsukin&&!!v.shudan,p:3},
 {k:'jiki',l:'転職時期',ok:v=>!!v.jiki,p:2},
 {k:'kinmu',l:'勤務形態',ok:v=>!!v.kinmu,p:3},
 {k:'kyuyo',l:'希望給与（方向＋マスト）',ok:v=>!!v.kyuyo_hoko&&!!v.kyuyo_must,p:3},
 {k:'renraku',l:'連絡方法（手段＋時間帯）',ok:v=>(v.renraku||[]).length>0&&(v.jikantai||[]).length>0,p:4},
 {k:'tasha',l:'他社',ok:v=>!!v.tasha,p:4},
 {k:'appo',l:'次回アポ日時',ok:v=>!!v.appo,p:5}
];
// 面（五つ）と、節ごとの秒（93-044 時間の実測：早口／標準／ゆっくり）
const SEC={iriguchi:[118,146,185],kakunin:[49,61,79],sengen:[[111,134,167],[30,37,47],[6,8,10]],ondo:[101,127,162],shikaku:[44,55,70],genjo:[19,24,31],kibo:[163,204,261],must:[39,49,63],modori:[190,238,304],renraku:[48,60,77],tasha:[41,51,65],shime:[190,236,299]};
const PH=[
 {n:1,nm:'入口',sub:'相手・確認・宣言',secs:s=>SEC.iriguchi[s]+SEC.kakunin[s]+SEC.sengen[st.sengen][s]},
 {n:2,nm:'ストーリー',sub:'きっかけ・時期',secs:s=>SEC.ondo[s]+SEC.shikaku[s]+SEC.genjo[s]},
 {n:3,nm:'希望',sub:'通勤・給与・勤務',secs:s=>SEC.kibo[s]+SEC.must[s]},
 {n:4,nm:'戻り',sub:'本音・連絡・他社',secs:s=>SEC.modori[s]+SEC.renraku[s]+SEC.tasha[s]},
 {n:5,nm:'締め',sub:'次回・同意',secs:s=>SEC.shime[s]}
];
// 強みタグの手がかり（キーワード一致。AIなし）
const KW={'急変対応':['急変','救急','緊急'],'家族への説明':['家族','ご家族','説明'],'新人の指導':['新人','指導','プリセプター','教育'],'多職種連携':['多職種','連携','リハ','ケアマネ','医師と'],'記録の正確さ':['記録','正確','カルテ'],'看取り':['看取り','ターミナル','終末期'],'認知症ケア':['認知症'],'在宅・訪問':['在宅','訪問'],'段取り・調整':['段取り','調整','回し','シフト','お迎え'],'夜勤帯を任される':['夜勤帯','夜勤リーダー','任され','頼まれ'],'子どもの安全':['園児','安全','怪我'],'保護者対応':['保護者'],'行事の企画':['行事','企画'],'献立・発注':['献立','発注'],'衛生管理':['衛生']};

/* ===== 台本（93-044） ===== */
const SENGEN=[
 `「ありがとうございます。<b>貴重なお時間をいただいているので、無駄がないように、短い時間でできるだけたくさん伺って、〇〇さんの選択肢を多く考えられるようにしたいんです。</b>だから少し駆け足になるかもしれませんが、ご容赦ください。⏸
<b>ここから、少し立ち入ったことも伺うので、先にこちらの約束をお伝えさせてください。</b>⏸

まず、<b>〇〇さんの情報は、必要なところに、必要な分だけしか出しません。</b>⏸
それと、<b>AIも使って無駄なく進めたいので、この通話は録音させていただいています。</b>録った内容も同じで、必要なところに必要な分だけ。不要に回すことはしません。⏸
施設さんに出すときも、<b>〇〇さんに中身を見ていただいてからです。</b>勝手には出しません。⏸

それと、<b>面接を勝手に組んだりはしません。</b>〇〇さんが行きたいと思ってから、私が動きます。⏸
<b>転職するかどうかも、〇〇さんが決めてください。</b>私は、今の職場と候補で<b>何がどう変わるか</b>を、そのままお出しするだけです。良いところも、良くないところも。⏸

その代わり、<b>一つだけお願いがあって。嘘だけはつかないでいただきたいんです。</b>⏸　迷ってるとか、やっぱりやめたいとか、そのままで大丈夫なので。<b>正直に言っていただけたら、その範囲で、できることは全部やります。</b>⏸

あと、他の会社さんとも話されてるかもしれませんが、<b>それは全然かまいません。</b>⏸　ただ、同じ求人を重ねて出したりすると〇〇さんが困るので、<b>話しやすいときで大丈夫です、どこかで教えてください。</b>⏸

——<b>以上です。</b>では、聞かせてください」`,
 `「貴重なお時間なので、駆け足でたくさん伺いますね。ここから少し立ち入ったことも伺うので、<b>先に二つだけ。</b>⏸
〇〇さんの情報は、<b>勝手に出しません。</b>AIも使うので録音していますが、それも同じです。施設さんに出すときも、中身を見ていただいてからです。⏸
それと、<b>転職するかどうかは〇〇さんが決めてください。</b>私は、何がどう変わるかを、そのままお出しするだけです。⏸
その代わり一つだけ、<b>嘘だけはつかないでください。</b>正直に言っていただけたら、できることは全部やります」`,
 `「AIも使うので録音していますが、<b>〇〇さんの情報を勝手に出したり、面接を勝手に組んだりはしませんので、そこはご安心ください</b>」`
];
const SENGEN_T=['全文 1分38秒','短縮 37秒','一言 8秒'];

// 受け：項目の値ごと（93-044 答え別の受け方／93-051）
const RECV={
 aite:{
  '本気':'<b>フル台本。</b>今日中に送る',
  '情報収集':'<b>売り込まない。</b>「決めていなくて大丈夫です」。動く条件を一つ取って、連絡の許可',
  'うんざり':'<b>同じ話をさせない、と先に言う。</b>短く。「今日は5分で、状況だけ伺って、合うものがあれば送ります」',
  '他社先行':'<b>同じ求人を並べない。</b>「そちらで足りていないものはありますか」。進捗だけ聞いて、違う角度の一件を送る',
  '仕事中・移動中':'時間を取って切る。「では<b>いつなら</b>5分いただけますか」→ 日時を取る'
 },
 shokureki:{
  '一つの職場が長い':'「一つの病院で〇年ですか。<b>それは施設さんから見ると、かなり信頼される経歴です</b>」',
  '複数の職場を経験':'「いろんな現場を見られてるんですね。<b>そのぶん、合う合わないが分かってらっしゃると思います</b>」<span class="no">　×「転職が多いですね」（絶対に言わない）</span>',
  'ブランクあり':'「<b>ブランクは全然大丈夫です。</b>復帰の方を受け入れている職場、けっこうあります」⏸「差し支えなければ、どのくらいお休みされてました？」<span class="no">　×理由を先に聞く</span>',
  '新卒・第二新卒':'「最初の職場ですね。<b>ここで合うところを選べると、その後がぜんぜん違います</b>」'
 },
 yakin:{
  'あり（二交代）':'「夜勤もされてたんですね。<b>夜勤ありなら、選べる求人がぐっと増えます</b>」',
  'あり（三交代）':'「夜勤もされてたんですね。<b>夜勤ありなら、選べる求人がぐっと増えます</b>」',
  'なし':'「<b>日勤のみで探されている方、多いです。</b>数は絞られますが、ちゃんとあります」<span class="no">　×「夜勤ができないと厳しいですよ」</span>',
  'もうやりたくない':'「<b>日勤のみで探されている方、多いです。</b>数は絞られますが、ちゃんとあります」→ 希望勤務形態「日勤のみ」に直結<span class="no">　×脅し</span>'
 },
 kikkake:{
  '給与':'「あー、そうなんですね。⏸ <b>それって、金額そのものというより、上がっていく感じがしない、みたいなところもありますか？</b>」',
  '人間関係':'「<b>それは、しんどいですね。</b>」⏸「差し支えない範囲で大丈夫ですので」<span class="no">　×面白がる／職場を悪く言う</span>',
  '夜勤・体力':'「夜勤、きついですよね。<b>何年か続けると、体の方が先に言ってきますよね</b>」<span class="no">　×「まだお若いのに」</span>',
  '家庭の事情':'「<b>お子さん（ご家族）のことですね。</b>⏸ そうすると、時間の方が大事になってきますよね」→ 通勤・勤務形態の背景に直結<span class="no">　×詳しく聞き込む</span>',
  '通勤':'「毎日だと、往復で相当な時間ですもんね」',
  '評価・昇給':'「あー、そうなんですね。⏸ 上がっていく感じがしない、というところですかね」',
  '職場の方針':'「なるほど。⏸ それって、〇〇（相手の言葉）が一番大きい、ということですかね？」',
  '漠然・情報収集':'「<b>それで全然大丈夫です。</b>⏸ 逆に、今の職場で<b>ここだけは</b>、というのはありますか？」<span class="no">　×「本気で探してますか」</span>'
 },
 kyuyo_hoko:{
  '上げたい':'「<b>最低ここは絶対、というラインはありますか？</b> それとも、できればこのくらい、という希望でしょうか」',
  '同じくらいでいい':'「同じくらいですね、承知しました。⏸ 最低ここは、というラインだけ伺っておいてもいいですか」',
  '他を優先して少し下がってもいい':'「<b>そうなんですね。</b>それ、けっこう大事なところなので、あとでもう少し聞かせてください」→ 戻りで「<b>何を得るためなら</b>、下げてもいいと思えますか？」'
 },
 tasha:{
  '有':'「<b>そうですよね、何社かから連絡きますよね。</b>⏸ 教えていただいてありがとうございます」→「それなら、こちらは〇〇（違う角度）で探しますね」<span class="no">　×詮索する</span>',
  '無':'「そうなんですね。<b>では、うちだけの情報になってしまうので、比べる材料もちゃんとお出しします</b>」<span class="no">　×「うちだけにしてください」</span>',
  '確認中':'それ以上聞かない。二回目に。「今でなくて大丈夫」を守る'
 },
 sms:{
  '可':'「ありがとうございます。持ち物や確認はショートメッセージでお送りしますね」',
  '不可':'「承知しました。では電話（または選んだ手段）でご連絡しますね」'
 }
};

// 各面の台本（左）
function scriptHTML(p){
 const v=allVals();
 if(p===1)return `
 <div class="sec"><h3>0.5 繋がった瞬間 <span class="t">30秒で読む</span></h3>
  <div class="say next">「〇〇さん、はじめまして。〇〇の〇〇と申します。ご登録ありがとうございます。今、<b>5分ほど</b>お話しできますか？」
「今回ご登録いただいたのは、<b>本格的に探されている感じですか？それとも、まずは情報収集で？</b>——どちらでも大丈夫です」</div>
  ${recvBox('aite','相手の状態を選ぶと、こちらがやること')}
 </div>
 <div class="sec"><h3>1 最初のひと言 <span class="t">約2.4分・まだ宣言しない</span></h3>
  <div class="say">「ありがとうございます。<b>登録されると、たぶんもう何件かお電話きてますよね。</b>⏸ すみません、うちもその一つなんですけど。⏸
<b>同じことを何度もお聞きするつもりはないので、</b>まず、ご登録の内容だけ確認させてください。⏸</div>
  <details><summary>続き（時間を取る）</summary><div class="say">そのうえで、今日は〇〇さんがどういう働き方を探しているかを伺って、通える範囲で条件に合う求人を、<b>今日中か明日にはお送りします。</b>
<b>できれば15分</b>いただけると条件をしっかり伺えますし、余裕があれば、本当は何を変えたいのかというところまで話せると<b>外さない提案</b>ができるので、<b>トータル30分</b>ほど。<b>今日はどのくらい大丈夫そうですか？</b>」</div><p class="note">相手の答えで上の「持ち時間」を合わせる。5分→通勤圏と時期の二つ＋次回の約束。15分→短縮版の宣言＋四つ。</p></details>
 
  <details><summary>応募からの入口（求人を見て応募した人はこちら）</summary><div class="say">「〇〇さん、はじめまして。<b>△△の求人にご応募いただいた件で</b>お電話しました、Good Luckの□□です。ありがとうございます。⏸
あの求人は、<b>私どもが施設さんからお預かりしていて、ご応募の方の窓口を私が務めます。</b>⏸
まず一つだけ——<b>あの求人の、どこに惹かれましたか？</b>⏸
ありがとうございます。<b>実は、同じ条件で他にもお出しできる求人がいくつかあるので、あの求人を軸に、比べるものも一緒にお持ちします。</b>⏸ 選ぶのは〇〇さんです。
そのために、<b>施設さんに推薦するときに要る分だけ、〇〇さんのことを伺ってもいいですか？</b>⏸ 10分ほどで済みます」</div><p class="note">応募先を否定しない・窓口として名乗る・「惹かれた点」＝希望条件の入口。宣言は一言版。戻りは二回目。</p></details>
</div>
 <div class="sec"><h3>1.5 確認 <span class="t">1〜2分・パンパン</span></h3>
  <div class="say">「まず、<b>ご登録いただいた情報を確認させてください。</b>はい・いいえで大丈夫です。
正看護師さんでお間違いないですか？——ご経験は〇年——今は〇〇病院にお勤めで——お住まいは〇〇市——」
「<b>いくつか質問させてください。</b>——夜勤のご経験は？——今の月給は、夜勤込みでだいたい？——」</div>
  <p class="note">登録情報があるなら読み上げて確認するだけ。聞き直さない。背景はここでは取らない。</p>
  ${recvBox('shokureki','職歴の形の受け')}
  ${recvBox('yakin','夜勤経験の受け')}
  <div class="recv"><span class="lab">給料の受け</span>「<b>29万で、夜勤4回込みですよね。</b>」（必ず復唱）
言いたくなさそう →「<b>だいたいで大丈夫です。</b>20万台の前半か後半か、くらいでも」<span class="no">　×「安いですね」「もっともらえますよ」</span></div>
 </div>
 <div class="sec"><h3>1.8 宣言 <span class="t" id="sengenT">${SENGEN_T[st.sengen]}</span></h3>
  <div class="seg" id="sengenSeg">${['全文','短縮','一言'].map((s,i)=>`<button class="${st.sengen===i?'on':''}" data-i="${i}">${s}</button>`).join('')}</div>
  <div class="say" style="margin-top:6px">${SENGEN[st.sengen]}</div>
  <p class="note">30分→全文／15分→短縮／5分・うんざり・情報収集→一言。相手が既に本音を話し始めていたら遮らず後回し。</p>
 </div>`;
 if(p===2){
  const q={'本気':'「差し支えなければ、<b>今回、転職を考えられたきっかけ</b>を教えていただけますか？」','情報収集':'「<b>ご登録いただいたのは、今の職場で何か気になることがあって？</b>それとも、たまたま？」——たまたまなら、それでいい','他社先行':'「他の会社さんとお話しされているなら、<b>同じことを二度お聞きするのは申し訳ないので</b>、一つだけ——<b>そちらで、これは違うなと思ったことはありますか？</b>」'};
  const qq=q[v.aite]||q['本気'];
  return `
 <div class="sec"><h3>2-1 転職のきっかけ <span class="t">開いて聞く・掘らない</span></h3>
  <div class="say next">${qq}</div>
  ${v.aite&&!q[v.aite]?'<p class="note">うんざり・仕事中は台本を降りる。動く条件を一つと連絡の許可だけ。</p>':'<p class="note">相手の状態（①）で問いが変わる。今は「'+(v.aite||'本気')+'」の問い。</p>'}
  <div class="recv"><span class="lab">受け（話が止まったら）</span>「あー、そうなんですね。」⏸
「<b>それって、〇〇（相手の言葉）が一番大きい、ということですかね？</b>」
（しんどい話なら）「それは、大変でしたね。」</div>
  ${recvBox('kikkake','きっかけ別の受け')}
  <details><summary>詰まって出てこないとき（ここで初めて例を出す）</summary><div class="say">「皆さんいろいろで、<b>お給料の方もいれば、夜勤がしんどい、ご家庭の事情、という方も</b>います。〇〇さんはどのあたりが近いですか？」</div><p class="note">最初から例を出さない。出すと相手がそれに寄る。</p></details>
 </div>
 <div class="sec"><h3>2-2 転職時期 <span class="t">目標90%</span></h3>
  <div class="say">「<b>いつ頃までに</b>次の職場に移りたい、というイメージはありますか？」</div>
  <div class="recv"><span class="lab">答え別の受け</span><ul>
  <li>すぐ・1ヶ月 →「承知しました。<b>では今日中に出せるものをお送りします</b>」</li>
  <li>具体月 →「〇月ですね。<b>だと、逆算すると〇月には面接ですね</b>」</li>
  <li>未定 →「<b>決まってなくて、全然大丈夫です。</b>そういう方の方が多いので」⏸「<b>何かあれば動く、というのはありますか？</b>給料が上がる求人が出たら、とか、日勤のみのところが見つかったら、とか」<span class="no">　×急がせる</span></li></ul></div>
  <p class="note">背景（ボーナス・契約・子ども）は話の中で出ていればメモ。出ていなければここでは聞かない。戻りで。</p>
 </div>
 <div class="sec"><h3>2-3 現職の状態・3 資格・4 現状 <span class="t">確認で済んでいれば飛ばす</span></h3>
  <div class="say">「今は、お仕事はされていますか？」（在職中→「退職の意思は、職場にお伝えしていますか？」）
「経験年数と、<b>これまでどんな病棟・診療科</b>をご経験されましたか？」
「通勤は今、どのくらいかかっていますか？」</div>
  <div class="recv"><span class="lab">受け</span>「12年ですか、長いですね。」「そのご経験があると、<b>出せる求人がだいぶ変わります。</b>」（事実に驚く。お世辞にしない）</div>
 </div>`;
 }
 if(p===3)return `
 <div class="sec"><h3>5-1 通勤圏 <span class="t">目標90%・最も効く</span></h3>
  <div class="say next">「通勤は、<b>どのくらいまでなら</b>大丈夫ですか？例えば電車で30分とか、車で40分とか」
「<b>電車ですか、車ですか</b>」</div>
  <div class="recv"><span class="lab">受け</span>「車で30分ですね。<b>だと、〇〇の辺りまでは入ってきますね。</b>」（地図を見ながら範囲を言う）</div>
  <p class="note">背景（お迎え・介護・車が無い）は、②で出ていればもう分かっている。出ていなければここでは聞かない。戻りで。</p>
 </div>
 <div class="sec"><h3>5-2 希望給与 <span class="t">目標80%・三段で</span></h3>
  <div class="say">①「今のお給料は、月給でいくらくらいですか？」→ 例「28万」
②「<b>その28万を基準に、次はどうなりたいですか？</b> 上げたい、同じくらいでいい、他を優先して少し下がってもいい」
③「<b>最低ここは絶対、というラインはありますか？</b> それとも、<b>できればこのくらい、という希望</b>でしょうか」</div>
  ${recvBox('kyuyo_hoko','方向別の受け')}
  <p class="note">マストは提案の下限、できたらは順位付け。分けないと提案先がなくなる。</p>
 </div>
 <div class="sec"><h3>5-3 勤務形態 <span class="t">目標90%</span></h3>
  <div class="say">「<b>日勤だけがいいですか、夜勤もできますか？</b>」（夜勤OKなら）「月に何回くらいまでなら？」
「<b>オンコールは大丈夫ですか？</b>」</div>
  <div class="recv"><span class="lab">日勤のみなら</span>「日勤のみですね。<b>数は絞られるので、給与は少し下がる可能性があります。</b>そこは正直にお伝えしておきます」（後で揉めない）</div>
 </div>
 <div class="sec"><h3>5-4 休日</h3>
  <div class="say">「お休みのご希望はありますか？<b>土日は休みたいという方が多いですが、平日休みの方が助かる、という方もいます</b>」</div>
 </div>
 <div class="sec"><h3>6 マスト／できたら <span class="t">一項目ずつ二択で</span></h3>
  <div class="say">「いろいろ伺いました。<b>全部を満たす求人はなかなか無いのが正直なところ</b>です。一つずつ確認させてください——
通勤〇分以内、これは<b>絶対</b>ですか、<b>できれば</b>ですか？
日勤のみ、これは絶対ですか、できればですか？」</div>
  <div class="recv"><span class="lab">分岐</span>全部マスト →「全部を絶対にすると、正直、求人がほぼ無くなります。<b>どれか一つ、できたらに落とせるものはありますか？</b>」
全部できたら → 本音が出ていない。②に戻って「何を変えたいか」</div>
 </div>`;
 if(p===4){
  const w=words();
  const omote=(v.kikkake||[])[0]||'〇〇';
  const kata={'給与':'評価が上がらない／人間関係（師長・同僚）／残業が付かない','通勤':'家庭の事情（お迎え・介護）／夜勤明けの帰宅がきつい','夜勤・体力':'体力・体調／子どもの時間／人間関係','漠然・情報収集':'「今の職場で、ここだけは、というのはありますか？」'}[omote]||'評価が上がらない／人間関係／体力';
  return `
 <div class="sec"><h3>5.5 戻り <span class="t">「先ほどのお話ですが」一巡だけ</span></h3>
  <div class="say next">「先ほど、<b>${omote}</b>とおっしゃっていましたが——<b>他の方ですと、${kata}という話もよく伺います。</b>そういったところは、いかがですか？」</div>
  <p class="note">相手自身の言葉に戻る＋型を差し出す。相手は選ぶだけ。違えば「ちょっと違って…」と言いやすい。</p>
  <div class="recv"><span class="lab">分岐</span><ul>
  <li>「そうです」→ 記録。<b>それ以上は掘らない</b></li>
  <li>「いや、そういうのではなくて…」→ <b>ここが本命。</b>否定のあとに本当の理由が続く。聞く</li>
  <li>「特に…」→ <b>追わない。</b>「分かりました、また何かあれば」。本音の取得状況＝一回目は出ず</li></ul></div>
  <details${w.length?' open':''}><summary>戻る材料（条件の背景）</summary><div class="say">通勤 →「先ほど、通勤は${v.tsukin?v.tsukin+'分':'〇分'}以内と伺いましたが——<b>お子さんのお迎えとか、ご家族のことで、時間に制約がある方が多いのですが、</b>そういったご事情でしょうか？」
時期 →「${v.jiki||'〇月頃'}、とおっしゃっていましたが——<b>ボーナスの後で、とか、契約の区切りで、という方が多いのですが、</b>何かそういった区切りですか？」
${v.kyuyo_hoko==='他を優先して少し下がってもいい'?'下げてもいい →「少し下がってもいい、とおっしゃっていましたが——<b>夜勤をやめたい、お子さんの時間を取りたい、で下げる方が多いんです。</b>〇〇さんの場合は、何を優先するために、でしょう？」':''}</div></details>
 </div>
 <div class="sec"><h3>6-2 連絡 <span class="t">例を先に。勧めたいものを先頭に</span></h3>
  <div class="say">「ご連絡なんですが——<b>電話の方もショートメッセージの方もいらっしゃるんですけど、</b>LINEもあります。<b>何が一番いいですか？</b>」
「<b>出やすい時間帯</b>はありますか？日中がいちばん多いんですけど、夜の方がいいという方も、休みの日だけという方もいます」
「逆に、<b>避けた方がいい時間</b>はありますか？夜勤明けで寝ている時間とか、職場で出られない時間とか」</div>
  <p class="note">「一番多い」は事実になってから言う（今は電話が大半）。</p>
 </div>
 <div class="sec"><h3>7 他社 <span class="t">最初にお願いした件、として</span></h3>
  <div class="say">「最初にお願いした件なんですが——他の会社さんとのお話、<b>もし進んでいるところがあれば</b>、こちらもそれに合わせて動けるので、<b>差し支えない範囲で</b>教えていただけますか？」</div>
  ${recvBox('tasha','他社の受け')}
 </div>`;
 }
 if(p===5)return `
 <div class="sec"><h3>8 締め・人となり <span class="t">推薦文の一行目</span></h3>
  <div class="say next">「最後に一つだけ。施設さんに〇〇さんを紹介するとき、<b>これは伝えてほしい、というのはありますか？</b>『真面目に働きます』より、『<b>急変対応が得意です</b>』『<b>家族への説明が丁寧です</b>』みたいな方が、ちゃんと伝わるので」</div>
 </div>
 <div class="sec"><h3>良さを返す <span class="t">一通話で二つまで</span></h3>
  <div class="say">「さっきの〇〇の話——<b>それ、〇〇さんの強みですよ</b>」
「もしかして、本当に大事なのは30分じゃなくて、<b>16時半に上がれること</b>ですか？」</div>
  <p class="note">下の面で光った候補のうち、本当にそうだと思うものだけ。</p>
 </div>
 <div class="sec"><h3>次回アポ <span class="t">日時を取ってから切る</span></h3>
  <div class="say">「ありがとうございます。伺った条件で、<b>通える範囲の求人を今日中に〇件ほど</b>お送りします。<b>〇日の〇時頃</b>に、それを見ていただいた感想を伺いにお電話してもよろしいですか？」</div>
  <div class="recv"><span class="lab">取れないとき</span>「では明日、送ったあとにこちらから一度ご連絡します」でこちらの約束にする。空なら24時間後と4日後にSMSが自動で追う。</div>
 </div>
 <div class="sec"><h3>SMS同意 <span class="t">さらっと</span></h3>
  <div class="say">「それと、求人のお知らせや、面接の前の持ち物・確認は、<b>ショートメッセージでお送りしますね。大丈夫ですか？</b>」</div>
  ${recvBox('sms','')}
 </div>
 <div class="sec"><h3>担当への希望</h3>
  <div class="say">「あと一つだけ。<b>私がお休みの日はサポート役がつきますし、もし途中で担当が変わることがあったら</b>、引き継ぐ相手について——<b>こういう方がいい、というご希望があれば聞かせてください。</b>同じ年代がいい、とか、テンポよく進めてほしい、とか」</div>
  <p class="note">「〇〇さんのままで」と言われたら、それが今の担当の評価。</p>
 </div>
 <div class="sec"><h3>知らないことを聞かれたら</h3>
  <div class="recv">「すみません、そこは私、現場を経験していないので正確なことは言えません。<b>施設さんに直接聞けるのが私の仕事なので、確認して〇日までにお返しします</b>」→「施設に確認すると約束したこと」に書く</div>
 </div>`;
}
function recvBox(id,lab){
 const r=RECV[id];if(!r)return'';
 const v=allVals()[id];const sel=Array.isArray(v)?v:(v?[v]:[]);
 const items=Object.keys(r).map(k=>`<li class="${sel.includes(k)?'hit':''}">${k} → ${r[k]}</li>`).join('');
 return `<div class="recv">${lab?`<span class="lab">${lab}</span>`:''}<ul>${items}</ul></div>`;
}

/* ===== 状態 ===== */
const st={p:1,sengen:0,run:false,t0:null,acc:0,phaseT:0,phaseAcc:{}};
const BUDGET=()=>+document.getElementById('budget').value;
const SPEED=()=>+document.getElementById('speed').value;
function vals(){
 const v={};
 F.forEach(f=>{
  const el=document.querySelector(`[data-f="${f.id}"]`);if(!el)return;
  if(f.t==='chk')v[f.id]=[...el.querySelectorAll('input:checked')].map(i=>i.value);
  else if(f.t==='seg')v[f.id]=el.dataset.v||'';
  else v[f.id]=(el.value||'').trim();
 });
 return v;
}
function words(){
 const v=allVals();const m=v.memo||'';
 return m.split(/\n|／/).map(s=>s.replace(/^[「『]|[」』]$/g,'').trim()).filter(Boolean);
}

/* ===== 描画 ===== */
function buildForm(){
 const wrap=document.getElementById('form');wrap.innerHTML='';
 const p=st.p;const fs=F.filter(f=>f.p===p);
 let g='';let gdiv;
 fs.forEach(f=>{
  if(f.g!==g){g=f.g;gdiv=document.createElement('div');gdiv.className='grp';gdiv.innerHTML=`<h3>${g}</h3>`;wrap.appendChild(gdiv);}
  gdiv.appendChild(fieldEl(f));
 });
 if(p===5){const d=document.createElement('p');d.className='note';d.textContent='通話後：必ず取る8つが埋まっているか確認 → 約束した求人を送る → 自己PR文の下書き（別途）';wrap.appendChild(d);}
 restore();
}
function fieldEl(f){
 const d=document.createElement('div');d.className='f';d.id='f_'+f.id;
 const lab=`<label for="i_${f.id}">${f.l}${f.req?'<span class="req">*</span>':''}<span class="src">${f.src||''}</span></label>`;
 let inp='';
 if(f.t==='sel')inp=`<div><select id="i_${f.id}" data-f="${f.id}"><option value="">—</option>${f.o.map(o=>`<option>${o}</option>`).join('')}</select>${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='text')inp=`<div><input type="text" id="i_${f.id}" data-f="${f.id}" placeholder="${f.ph||''}">${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='num')inp=`<div class="unit"><input type="number" id="i_${f.id}" data-f="${f.id}" min="0"><span>${f.unit||''}</span></div>`;
 else if(f.t==='dt')inp=`<div><input type="datetime-local" id="i_${f.id}" data-f="${f.id}" step="60">${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='ta')inp=`<div><textarea id="i_${f.id}" data-f="${f.id}" rows="${f.rows||3}" placeholder="${f.ph||''}"></textarea>${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='chk')inp=`<div><div class="chips" data-f="${f.id}">${f.o.map(o=>`<label class="chip"><input type="checkbox" value="${o}">${o}</label>`).join('')}</div>${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='seg')inp=`<div><div class="seg kbn" data-f="${f.id}" data-v="">${f.o.map(o=>`<button type="button" data-v="${o}">${o}</button>`).join('')}</div></div>`;
 d.innerHTML=lab+inp;
 return d;
}
// 値の保持（面を切り替えてもDOMを作り直すので、メモリに持つ）
const store={};
function persist(){Object.assign(store,vals());}
function restore(){
 F.forEach(f=>{
  const el=document.querySelector(`[data-f="${f.id}"]`);if(!el)return;const v=store[f.id];if(v==null)return;
  if(f.t==='chk'){el.querySelectorAll('input').forEach(i=>{i.checked=v.includes(i.value);i.parentElement.classList.toggle('on',i.checked)});}
  else if(f.t==='seg'){el.dataset.v=v;el.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));}
  else el.value=v;
 });
}
function allVals(){persist();return Object.assign({},store);}

function buildPhases(){
 const s=SPEED();const el=document.getElementById('phases');el.innerHTML='';
 PH.forEach(ph=>{
  const min=(ph.secs(s)/60).toFixed(1);
  const b=document.createElement('button');b.className='ph'+(ph.n===st.p?' on':'')+(ph.n<st.p?' done':'');b.dataset.n=ph.n;
  const pct=phasePct(ph.n);
  b.innerHTML=`<span class="n">${ph.n}</span><span class="col"><div><span class="nm">${ph.nm}</span><span class="mn">見込み ${min}分</span></div><span class="fill"><i style="width:${pct}%"></i></span></span>`;
  b.onclick=()=>go(ph.n);el.appendChild(b);
 });
}
function phasePct(n){
 const v=allVals();const fs=F.filter(f=>f.p===n);if(!fs.length)return 0;
 const filled=fs.filter(f=>has(v[f.id])).length;return Math.round(filled/fs.length*100);
}
function has(x){return Array.isArray(x)?x.length>0:!!x;}

function updateTop(){
 const v=allVals();
 // マスト
 const m=MUST.map(x=>x.ok(v));const n=m.filter(Boolean).length;
 document.getElementById('mustN').textContent=n;
 document.getElementById('mustDots').innerHTML=m.map((ok,i)=>`<i class="${ok?'on':''}" title="${MUST[i].l}"></i>`).join('');
 // 全体%（背景・本音は重く）
 let tot=0,got=0;F.filter(f=>f.p>0).forEach(f=>{const w=f.w||1;tot+=w;if(has(v[f.id]))got+=w;});
 document.getElementById('allP').textContent=Math.round(got/tot*100);
 document.getElementById('aiteChip').textContent=v.aite?'・'+v.aite:'';
 // 見込み
 const s=SPEED();const inPhase=phaseElapsed();
 let must=0,all=0;
 PH.forEach(ph=>{let sec=ph.secs(s);if(ph.n===st.p)sec=Math.max(0,sec-inPhase);if(ph.n>=st.p){all+=sec;if(ph.n<=3)must+=sec;}});
 document.getElementById('etaMust').textContent=st.p<=3?'あと'+Math.ceil(must/60)+'分':'済';
 document.getElementById('etaAll').textContent='あと'+Math.ceil(all/60)+'分';
 // 促し
 nudges(v,n);
 // 拾った言葉
 const w=words();const ul=document.getElementById('words');
 ul.innerHTML=w.length?w.map(x=>`<li title="台本の〇〇に入れる"><span class="q">「${x}」</span></li>`).join(''):'<li class="empty">面談メモに相手の言葉を一行ずつ</li>';
 ul.querySelectorAll('li:not(.empty)').forEach((li,i)=>li.onclick=()=>{document.querySelectorAll('#script .say').forEach(s=>{s.innerHTML=s.innerHTML.replace(/〇〇（相手の言葉）|〇〇（表向き）/g,'<b>'+w[i]+'</b>')});});
 // 強み
 lightTsuyomi(v);
 // 入った印
 F.forEach(f=>{const d=document.getElementById('f_'+f.id);if(d)d.classList.toggle('filled',has(v[f.id]));});
 buildPhases();
}
function nudges(v,n){
 const L=[];
 const after=(p)=>st.p>p;
 if(after(1)&&!v.aite)L.push(['相手の状態が空です（目標100%）。一言で記録','']);
 if(after(3)&&!(v.tsukin&&v.shudan))L.push(['通勤圏、まだ取れていません（目標90%の項目です）','']);
 if(after(2)&&!v.jiki)L.push(['転職時期が空です。「未定」も値','']);
 if(after(3)&&!(v.kyuyo_hoko))L.push(['希望給与が空です。「今より上/同じ/下でもいい」だけでも','']);
 if(after(3)&&!v.kinmu)L.push(['勤務形態、まだ。「日勤だけ？夜勤も？」の一言','']);
 if(after(4)&&!v.tasha)L.push(['他社状況、確認しましたか','']);
 if(after(4)&&!((v.renraku||[]).length&&(v.jikantai||[]).length))L.push(['連絡は手段＋時間帯まで取って「取れた」','']);
 if(st.p===5&&!v.appo)L.push(['次回アポ日時が空です。日時を取ってから切りましょう','']);
 if(st.p>=3&&v.tsukin&&!(v.haikei||'').length)L.push(['通勤の背景、まだ拾えていません','soft']);
 if(st.p>=4&&!v.honne&&!v.honne_st)L.push(['本音、まだ取れていません → 「先ほど'+((v.kikkake||[])[0]||'〇〇')+'と伺いましたが、他の方だと…」','soft']);
 if(v.kyuyo_hoko==='他を優先して少し下がってもいい'&&!(v.haikei||'').match(/下げ|得|ため/))L.push(['「下げてもいい」の理由（何を得るため）が背景メモに無い','soft']);
 if(!L.length)L.push([n===8?'マスト 8/8。全体は%で見る':'今の面で取るものは揃っています','ok']);
 document.getElementById('nudge').innerHTML=L.map(([t,c])=>`<li class="${c}">${t}</li>`).join('');
}
function lightTsuyomi(v){
 const text=(v.memo||'')+'\n'+(v.hitotonari||'')+'\n'+(v.haikei||'');
 const hits=[];
 document.querySelectorAll('#tsuyomi .chip').forEach(c=>{
  const tag=c.querySelector('input').value;const kws=KW[tag]||[];
  const hit=kws.some(k=>text.includes(k));c.classList.toggle('hint',hit);if(hit)hits.push(tag);
 });
 const h=document.getElementById('tsuyomiHint');
 h.textContent=hits.length?'メモの言葉から候補：'+hits.join('・')+'　→ 事実と対で口に出す。「さっきの〇〇の話、それ強みですよ」':'メモに事実が入ると、候補が光ります。事実が無い良さは出しません。';
}
function phaseElapsed(){return (st.phaseAcc[st.p]||0)+(st.run?(Date.now()-st.phaseT)/1000:0);}

function go(n){
 if(n<1||n>5)return;persist();
 if(st.run){st.phaseAcc[st.p]=phaseElapsed();st.phaseT=Date.now();}
 st.p=n;render();
}
function render(){
 buildForm(); // 先に入力欄を作って store から戻す（台本は store を読むので、この順）
 document.getElementById('script').innerHTML=scriptHTML(st.p);
 const seg=document.getElementById('sengenSeg');
 if(seg)seg.querySelectorAll('button').forEach(b=>b.onclick=()=>{st.sengen=+b.dataset.i;render();});
 wire();updateTop();
}
function wire(){
 document.querySelectorAll('#form [data-f]').forEach(el=>{
  el.addEventListener('input',()=>{updateTop();refreshRecv();});
  el.addEventListener('change',()=>{updateTop();refreshRecv();});
 });
 document.querySelectorAll('#form .chips').forEach(c=>c.querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>{i.parentElement.classList.toggle('on',i.checked);updateTop();refreshRecv();})));
 document.querySelectorAll('#form .seg.kbn').forEach(s=>s.querySelectorAll('button').forEach(b=>b.onclick=()=>{s.dataset.v=s.dataset.v===b.dataset.v?'':b.dataset.v;s.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x.dataset.v===s.dataset.v));updateTop();}));
}
function refreshRecv(){ // 受けだけ差し替え（入力中に台本全体を作り直さない）
 const keep=document.getElementById('script');const scroll=keep.scrollTop;
 const open=[...keep.querySelectorAll('details')].map(d=>d.open);
 keep.innerHTML=scriptHTML(st.p);
 [...keep.querySelectorAll('details')].forEach((d,i)=>{if(open[i]!=null)d.open=open[i]});
 const seg=document.getElementById('sengenSeg');if(seg)seg.querySelectorAll('button').forEach(b=>b.onclick=()=>{st.sengen=+b.dataset.i;render();});
 keep.scrollTop=scroll;
}

/* ===== タイマー（30分版） ===== */
function tick(){
 const e=st.acc+(st.run?(Date.now()-st.t0)/1000:0);
 const mm=Math.floor(e/60),ss=Math.floor(e%60);
 document.getElementById('clock').textContent=`${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
 const b=BUDGET()*60;const r=b-e;const rEl=document.getElementById('remain');
 const rm=Math.floor(Math.abs(r)/60),rs=Math.floor(Math.abs(r)%60);
 rEl.textContent=(r<0?'超過 ':'残り ')+`${String(rm).padStart(2,'0')}:${String(rs).padStart(2,'0')}`;
 rEl.classList.toggle('warn',r<180);
 const w=document.getElementById('warnline');
 const v=store;
 if(st.run&&r<180&&!v.appo){w.textContent=(r<0?'時間を超えています。':'残り3分です。')+'次回アポを取りましょう。';w.classList.add('on');}
 else w.classList.remove('on');
 if(st.run&&Math.floor(e)%5===0)updateTop();
}
document.getElementById('startBtn').onclick=function(){
 if(st.run){st.acc+=(Date.now()-st.t0)/1000;st.phaseAcc[st.p]=phaseElapsed();st.run=false;this.textContent='再開';}
 else{st.t0=Date.now();st.phaseT=Date.now();st.run=true;this.textContent='一時停止';}
};
document.getElementById('resetBtn').onclick=()=>{st.run=false;st.acc=0;st.phaseAcc={};document.getElementById('startBtn').textContent='開始';tick();updateTop();};
setInterval(tick,500);
document.getElementById('budget').onchange=function(){const b=+this.value;st.sengen=b>=30?0:b>=15?1:2;render();tick();};
document.getElementById('speed').onchange=()=>updateTop();

/* ===== キー ===== */
document.addEventListener('keydown',e=>{
 const tag=(e.target.tagName||'').toLowerCase();const typing=['input','textarea','select'].includes(tag);
 if(e.key==='ArrowRight'&&(!typing||e.altKey)){e.preventDefault();go(st.p+1);}
 if(e.key==='ArrowLeft'&&(!typing||e.altKey)){e.preventDefault();go(st.p-1);}
 if(e.key==='Tab'&&e.ctrlKey){e.preventDefault();go(e.shiftKey?st.p-1:st.p+1);}
});

/* ===== ⑤ 強みタグ ===== */
(function(){
 const w=document.getElementById('tsuyomi');
 w.innerHTML=O.tsuyomi.map(o=>`<label class="chip"><input type="checkbox" value="${o}">${o}</label>`).join('');
 w.dataset.f='tsuyomi';
 w.querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>{i.parentElement.classList.toggle('on',i.checked);store.tsuyomi=[...w.querySelectorAll('input:checked')].map(x=>x.value);}));
})();
// vals() は #form 内の [data-f] を見るので、強みタグは store に直接持つ（上）。allVals で合流。
const _vals=vals;
vals=function(){const v=_vals();v.tsuyomi=[...document.querySelectorAll('#tsuyomi input:checked')].map(x=>x.value);return v;};

/* ===== PORTERSへ書く内容 ===== */
function buildOut(){
 const v=allVals();const L=[];
 const fmt=x=>Array.isArray(x)?x.join('／'):x;
 const dt=x=>x?x.replace('T',' '):'';
 L.push('【レジュメ更新】Aさん　一回目ヒアリング　'+new Date().toLocaleDateString('ja-JP'));
 const m=MUST.map(x=>x.ok(v));
 L.push(`マスト ${m.filter(Boolean).length}/8　全体 ${document.getElementById('allP').textContent}%　通話 ${document.getElementById('clock').textContent}`);
 L.push('');
 let g='';
 F.filter(f=>f.p>0).forEach(f=>{
  if(!has(v[f.id]))return;
  if(f.g!==g){g=f.g;L.push('■ '+g);}
  let val=f.t==='dt'?dt(v[f.id]):fmt(v[f.id]);
  if(f.t==='num'&&f.unit)val+=' '+f.unit.split('（')[0];
  if(f.t==='ta')L.push(`${f.l}：\n${val.split('\n').map(s=>'　'+s).join('\n')}`);
  else L.push(`${f.l}：${val}`);
 });
 if((v.tsuyomi||[]).length){L.push('■ この人の良さ');L.push('強みタグ：'+v.tsuyomi.join('／'));}
 const miss=MUST.filter((x,i)=>!m[i]).map(x=>x.l);
 L.push('');L.push(miss.length?'△ 取れていないマスト：'+miss.join('／')+'　→ 次回の先頭に':'○ マスト 8/8');
 if(!v.appo)L.push('△ 次回アポが空。24時間後・4日後にSMSが自動で追う（同意：'+(v.sms||'(空白)')+'）');
 return L.join('\n');
}
document.getElementById('outBtn').onclick=()=>{document.getElementById('outText').textContent=buildOut();document.getElementById('out').classList.add('on');document.getElementById('out').scrollIntoView({behavior:'smooth'});};
document.getElementById('copyBtn').onclick=async()=>{
 const t=document.getElementById('outText').textContent;const msg=document.getElementById('copyMsg');
 try{await navigator.clipboard.writeText(t);msg.textContent='コピーしました';}
 catch(e){const r=document.createRange();r.selectNodeContents(document.getElementById('outText'));const s=getSelection();s.removeAllRanges();s.addRange(r);msg.textContent='選択しました。⌘C で';}
 setTimeout(()=>msg.textContent='',2500);
};

/* ===== 見本（Aさん・93-049 の例。個人情報なし） ===== */
const SAMPLE={aite:'本気',koyou:'正社員',shikaku:'正看護師',keiken:'急性期病棟 12年（二交代）',shokureki:'一つの職場が長い',yakin:'あり（二交代）',gessyu:'29',
 kikkake:['夜勤・体力','家庭の事情'],memo:'「夜勤がきつくなってきた」\n「子どもが小学校に上がる」\n「17時にお迎え」\n「同じような病院ばかり」\n「師長に頼まれるのは急変対応」\n「家族の話を聞くのが好き」',jiki:'2027年4月',haikei:'子どもの進学。4月が本命。\n通勤30分は17時の学童のお迎えのため。16時半上がりなら40分圏でも。\n下げてもいい理由：夜勤をやめて子どもの時間。本当のマストは日勤のみ。',
 tsukin:'30',shudan:'車',tsukin_kbn:'マスト',kyuyo_hoko:'他を優先して少し下がってもいい',kyuyo_must:'25',kyuyo_dekitara:'27',kinmu:'日勤のみ',oncall:'不可',kinmu_kbn:'マスト',yasumi:'土日（できたら）',
 fuman:['夜勤・体力','家庭との両立'],honne:'',honne_st:'一回目は出ず',renraku:['ショートメッセージ','電話'],jikantai:['日中（10〜16時）'],renraku_kibo:'夜勤明けの午前は不可。17〜20時は家事',tasha:'有',
 hitotonari:'施設に伝えてほしいこと：「家族の話を聞くのが好き。患者さんより家族が不安なことが多い」\n休日：子どもと公園。パン作り。\n返した良さ：家族を含めて看る目／生活を回し切る段取り力',hani:'人となりのみ',appo:'',sms:'可',tanto:'今の担当のままがいい。話が早いので',yakusoku:'B社は「同じような病院ばかり」→ クリニック・訪看で違う角度を3件、今日中に',tsuyomi:['急変対応','家族への説明']};
document.getElementById('sampleBtn').onclick=()=>{Object.assign(store,SAMPLE);store.tsuyomi=SAMPLE.tsuyomi;document.querySelectorAll('#tsuyomi input').forEach(i=>{i.checked=SAMPLE.tsuyomi.includes(i.value);i.parentElement.classList.toggle('on',i.checked)});render();};
document.getElementById('clearBtn').onclick=()=>{if(!confirm('入力を全部消しますか'))return;Object.keys(store).forEach(k=>delete store[k]);document.querySelectorAll('#tsuyomi input').forEach(i=>{i.checked=false;i.parentElement.classList.remove('on')});document.getElementById('out').classList.remove('on');render();};

render();tick();

;
(function(){function h(){var t=document.querySelector(".top");if(t)document.documentElement.style.setProperty("--toph",t.offsetHeight+"px");}h();window.addEventListener("resize",h);setTimeout(h,300);})();
;
(function(){function c(){var n=document.querySelectorAll("#tsuyomi .chip.hint, #tsuyomi .chip.on").length;var e=document.getElementById("tsuyomiCnt");if(e)e.textContent=n;}setInterval(c,800);})();
;

/* ===== ⑥ 通話ログ ===== */
(function(){
 const list=document.getElementById('logList'),nEl=document.getElementById('logN');
 const KEY=['夜勤','お迎え','小学校','急変','家族','説明','新人','指導','看取り','認知症','訪問','段取り','頼まれ','子ども','保護者','行事','献立','衛生','夜勤帯'];
 let t0=null;
 function hhmm(){if(!t0)t0=Date.now();const s=Math.floor((Date.now()-t0)/1000);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
 function mark(txt){let h=txt.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));KEY.forEach(k=>{h=h.split(k).join('<span class="hit">'+k+'</span>');});return h;}
 window.logAdd=function(who,txt){
  const li=document.createElement('li');li.className=who==='me'?'me':'';
  li.innerHTML='<span class="t">'+hhmm()+'</span><span class="w">'+(who==='me'?'CA':'相手')+'</span><span>'+mark(txt)+'</span>';
  li.title='面談メモに入れる';
  li.onclick=()=>{ if(who==='me'||li.classList.contains('picked'))return; const ta=document.querySelector('[data-f="memo"]')||document.querySelector('textarea[name="memo"],#memo'); const cur=(store.memo||'').trim(); store.memo=(cur?cur+'\n':'')+'「'+txt+'」'; li.classList.add('picked'); try{restore();words();lightTsuyomi(allVals());}catch(e){} };
  list.appendChild(li); nEl.textContent=list.children.length+'行'; list.scrollTop=list.scrollHeight;
 };
 const inp=document.getElementById('logInput');
 inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&inp.value.trim()){window.logAdd('you',inp.value.trim());inp.value='';}});
 const DEMO=[['me','お忙しいところありがとうございます。今5分ほどお時間いただけますか？'],['you','はい、大丈夫です。'],['me','ご登録の内容を確認させてください。正看護師さんで間違いないですか？'],['you','はい。急性期の病棟に12年います。二交代です。'],['you','夜勤がきつくなってきて。子どもが来年小学校に上がるので、17時にお迎えに行きたくて。'],['me','なるほど、夜勤と時間ですね。'],['you','夜勤帯を任されることが多くて、急変のときは私が先に動く感じでした。'],['you','家族への説明は師長から頼まれることが多かったです。'],['me','それは頼りにされていますね。'],['you','同じような病院ばかりで、訪問とかも少し気になっています。']];
 document.getElementById('logPlay').onclick=()=>{let i=0;t0=Date.now();const iv=setInterval(()=>{if(i>=DEMO.length){clearInterval(iv);return;}window.logAdd(DEMO[i][0],DEMO[i][1]);i++;},1400);};
})();

;/* ===== 音声で書き起こす（Chromeの音声認識・日本語）。相手の声も拾うには、Macの音の経路（BlackHole）を Chrome のマイクにする ===== */
(function(){
 var btn=document.getElementById('micBtn'); if(!btn) return;
 var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){ btn.disabled=true; btn.title='このブラウザでは音声認識が使えません（Chromeで開いてください）'; return; }
 var rec=null, on=false, wantOn=false, lastFinal='';
 function start(){
  rec=new SR(); rec.lang='ja-JP'; rec.continuous=true; rec.interimResults=false; rec.maxAlternatives=1;
  rec.onresult=function(e){ for(var i=e.resultIndex;i<e.results.length;i++){ var r=e.results[i]; if(!r.isFinal) continue; var txt=(r[0].transcript||'').trim(); if(!txt||txt===lastFinal) continue; lastFinal=txt; window.logAdd('you',txt); } };
  rec.onerror=function(e){ if(e.error==='not-allowed'||e.error==='service-not-allowed'){ wantOn=false; setOn(false); alert('マイクの許可が要ります。板の見出しの「別窓」で開くと許可を出せます。'); } };
  rec.onend=function(){ on=false; if(wantOn){ try{ start(); }catch(err){ setOn(false); } } else setOn(false); }; // 無音で切れても続ける
  rec.start(); on=true; setOn(true);
 }
 function setOn(v){ btn.classList.toggle('on',v); btn.textContent=v?'🎙 書き起こし中（押すと止める）':'🎙 音声で書き起こす'; }
 btn.addEventListener('click',function(){ if(wantOn){ wantOn=false; try{ rec&&rec.stop(); }catch(err){} setOn(false); } else { wantOn=true; try{ start(); }catch(err){ wantOn=false; setOn(false); } } });
})();

;document.getElementById('logHead').addEventListener('click',function(){document.getElementById('log').classList.toggle('open')});
document.getElementById('bottomBar').addEventListener('click',function(){document.getElementById('bottom').classList.toggle('open')});

// bridge.js（別スクリプト）から使う
window.F=F;window.FM=FM;window.store=store;window.allVals=allVals;window.render=render;

;(function(){ // 上段の高さが変わったら --toph を追従（フォント読込・幅変更・折り返し）
 var top=document.querySelector('.top'); if(!top||!window.ResizeObserver) return;
 new ResizeObserver(function(){ document.documentElement.style.setProperty('--toph', top.offsetHeight+'px'); }).observe(top);
 window.addEventListener('load',function(){ document.documentElement.style.setProperty('--toph', top.offsetHeight+'px'); });
})();
