
/* ===== 定義 ===== */
const O={ // 93-067 選択肢マスタ（この通り。足さない）
 aite:['本気','情報収集','うんざり','他社先行','仕事中・移動中'],
 kbn:['マスト','できたら'],
 shokureki:['一つの職場が長い','複数の職場を経験','ブランクあり','新卒・第二新卒'],
 yakin:['あり（二交代）','あり（三交代）','なし','もうやりたくない'],
 kikkake:['給与','人間関係','夜勤・体力','家庭の事情','通勤','評価・昇給','職場の方針','漠然・情報収集'],
 fuman:['人間関係','評価・昇給','夜勤・体力','残業','家庭との両立','職場の方針','教育体制','その他'],
 kyuyo:['上げたい','同じくらいでいい','他を優先して少し下がってもいい'],
 renraku:['ショートメッセージ','電話','LINE','メール'],
 jikantai:['日中（10〜16時）','夕方（16〜18時）','夜（18時〜）','朝（〜10時）','土日'],
 tsuyomi:['急変対応','家族への説明','新人の指導','多職種連携','記録の正確さ','看取り','認知症ケア','在宅・訪問','段取り・調整','夜勤帯を任される','子どもの安全','保護者対応','行事の企画','献立・発注','衛生管理','その他'],
 hani:['未確認','全部可','人となりのみ','条件のみ','不可'],
 honne:['取れた','一回目は出ず','確認のみ','表向きと同じだった'],
 nashi:['求人なし','条件不一致','意向低'],
 tasha:['有','無','確認中'],
 sms:['可','不可']
};
// 入力欄（93-067 の項目。src: 新規／既存）
const F=[
 // ① 入口
 {id:'aite',p:1,g:'0.5 相手の状態',l:'相手の状態',t:'sel',o:O.aite,req:1,src:'新規'},
 {id:'koyou',p:1,g:'1.5 確認',l:'希望雇用形態',t:'text',req:1,src:'既存マスタ「雇用形態」',ph:'既存マスタから選ぶ'},
 {id:'shikaku',p:1,g:'1.5 確認',l:'保有資格',t:'text',src:'既存',ph:'登録情報を読み上げて確認'},
 {id:'keiken',p:1,g:'1.5 確認',l:'経験職種／経験施設形態',t:'text',src:'既存',ph:'病棟・診療科・施設形態'},
 {id:'shokureki',p:1,g:'1.5 確認',l:'職歴の形',t:'sel',o:O.shokureki,src:'新規'},
 {id:'yakin',p:1,g:'1.5 確認',l:'夜勤経験',t:'sel',o:O.yakin,src:'新規'},
 {id:'gessyu',p:1,g:'1.5 確認',l:'現在の月収',t:'num',unit:'万円（夜勤込み）',src:'既存'},
 // ② ストーリー
 {id:'kikkake',p:2,g:'2-1 転職のきっかけ',l:'転職のきっかけ分類',t:'chk',o:O.kikkake,src:'新規',hint:'CAが分類。本人の言葉は面談メモへ'},
 {id:'memo',p:2,g:'2-1 転職のきっかけ',l:'面談メモ',t:'ta',src:'既存（拾った言葉）',ph:'相手の言葉をそのまま。一行に一つ　例：「夜勤がきつくなってきた」',rows:4},
 {id:'jiki',p:2,g:'2-2 転職時期',l:'希望転職時期（紹介）',t:'text',src:'既存',ph:'「未定」も値。空にしない',must:'jiki'},
 {id:'haikei',p:2,g:'背景',l:'背景メモ',t:'ta',src:'新規（4000）',ph:'通勤・時期・給与の背景、下げてもいい理由、動く条件',w:3},
 // ③ 希望
 {id:'tsukin',p:3,g:'5-1 通勤圏',l:'通勤許容時間',t:'num',unit:'分',src:'既存',must:'tsukin'},
 {id:'shudan',p:3,g:'5-1 通勤圏',l:'通勤手段',t:'text',src:'既存',ph:'電車／車 など（既存マスタ）',must:'tsukin'},
 {id:'tsukin_kbn',p:3,g:'5-1 通勤圏',l:'通勤の区分',t:'seg',o:O.kbn,src:'新規'},
 {id:'kyuyo_hoko',p:3,g:'5-2 希望給与',l:'希望給与の方向',t:'sel',o:O.kyuyo,req:1,src:'新規',must:'kyuyo'},
 {id:'kyuyo_must',p:3,g:'5-2 希望給与',l:'給与マスト',t:'num',unit:'万円（月給）これを割ったら提案しない',req:1,src:'新規',must:'kyuyo'},
 {id:'kyuyo_dekitara',p:3,g:'5-2 希望給与',l:'希望の月収',t:'num',unit:'万円（できたら）',src:'既存'},
 {id:'kinmu',p:3,g:'5-3 勤務形態',l:'希望勤務形態（看）',t:'text',src:'既存',ph:'日勤のみ／夜勤可 など（既存マスタ）',must:'kinmu'},
 {id:'oncall',p:3,g:'5-3 勤務形態',l:'オンコール/当直',t:'text',src:'既存（項目の有無 要確認）',ph:'不可／相談／可'},
 {id:'kinmu_kbn',p:3,g:'5-3 勤務形態',l:'勤務形態の区分',t:'seg',o:O.kbn,src:'新規'},
 {id:'yasumi',p:3,g:'5-4 休日',l:'希望の休み曜日',t:'text',src:'既存',ph:'土日 など'},
 // ④ 戻り
 {id:'fuman',p:4,g:'5.5 戻り',l:'現状の不満',t:'chk',o:O.fuman,src:'新規',hint:'マストの源泉'},
 {id:'honne',p:4,g:'5.5 戻り',l:'転職理由（本音）',t:'ta',src:'新規・要配慮',ph:'戻りでしか出ない。表向きと分けて',w:3},
 {id:'honne_st',p:4,g:'5.5 戻り',l:'本音の取得状況',t:'sel',o:O.honne,src:'新規',hint:'空欄と「出なかった」は違う'},
 {id:'renraku',p:4,g:'6-2 連絡',l:'連絡手段',t:'chk',o:O.renraku,req:1,src:'新規',must:'renraku'},
 {id:'jikantai',p:4,g:'6-2 連絡',l:'連絡可能時間帯',t:'chk',o:O.jikantai,req:1,src:'新規',must:'renraku'},
 {id:'renraku_kibo',p:4,g:'6-2 連絡',l:'連絡方法に関する希望',t:'text',src:'既存',ph:'避けたい時間帯と理由'},
 {id:'tasha',p:4,g:'7 他社',l:'他社利用',t:'sel',o:O.tasha,req:1,src:'既存マスタ',must:'tasha'},
 // ⑤ 締め
 {id:'hitotonari',p:5,g:'8 締め',l:'人となりメモ',t:'ta',src:'新規（4000）',ph:'施設に伝えてほしいこと・得意・エピソード・休日・やりたいこと・返した良さ',rows:4},
 {id:'hani',p:5,g:'8 締め',l:'施設に伝えてよい範囲',t:'sel',o:O.hani,src:'新規',hint:'推薦文を送る前に必ず'},
 {id:'appo',p:5,g:'8 締め',l:'次回アポ日時',t:'dt',req:1,src:'新規',must:'appo',hint:'空なら24h／4日でSMSが追う'},
 {id:'sms',p:5,g:'8 締め',l:'SMS連絡の同意',t:'sel',o:O.sms,req:1,src:'既存マスタ',hint:'自動配信の入口。未選択＝(空白)'},
 {id:'tanto',p:5,g:'8 締め',l:'担当への希望',t:'text',src:'新規',ph:'サポート役・引き継ぎ相手への希望'},
 {id:'yakusoku',p:5,g:'8 締め',l:'施設に確認すると約束したこと',t:'ta',src:'新規',ph:'内容と期限。返さないと信用が消える'},
 {id:'nashi',p:5,g:'通話のあと',l:'紹介先なしの理由',t:'sel',o:O.nashi,src:'新規',hint:'紹介先が無かったときだけ'},
 // 下の面
 {id:'tsuyomi',p:0,l:'強みタグ',t:'chk',o:O.tsuyomi,src:'新規'}
];
const FM=Object.fromEntries(F.map(f=>[f.id,f]));
// マスト8（93-046）
const MUST=[
 {k:'aite',l:'相手の状態',ok:v=>!!v.aite,p:1},
 {k:'tsukin',l:'通勤圏（値＋手段）',ok:v=>!!v.tsukin&&!!v.shudan,p:3},
 {k:'jiki',l:'転職時期',ok:v=>!!v.jiki,p:2},
 {k:'kinmu',l:'勤務形態',ok:v=>!!v.kinmu,p:3},
 {k:'kyuyo',l:'希望給与（方向＋マスト）',ok:v=>!!v.kyuyo_hoko&&!!v.kyuyo_must,p:3},
 {k:'renraku',l:'連絡方法（手段＋時間帯）',ok:v=>(v.renraku||[]).length>0&&(v.jikantai||[]).length>0,p:4},
 {k:'tasha',l:'他社',ok:v=>!!v.tasha,p:4},
 {k:'appo',l:'次回アポ日時',ok:v=>!!v.appo,p:5}
];
// 面（五つ）と、節ごとの秒（93-044 時間の実測：早口／標準／ゆっくり）
const SEC={iriguchi:[118,146,185],kakunin:[49,61,79],sengen:[[111,134,167],[30,37,47],[6,8,10]],ondo:[101,127,162],shikaku:[44,55,70],genjo:[19,24,31],kibo:[163,204,261],must:[39,49,63],modori:[190,238,304],renraku:[48,60,77],tasha:[41,51,65],shime:[190,236,299]};
const PH=[
 {n:1,nm:'入口',sub:'相手・確認・宣言',secs:s=>SEC.iriguchi[s]+SEC.kakunin[s]+SEC.sengen[st.sengen][s]},
 {n:2,nm:'ストーリー',sub:'きっかけ・時期',secs:s=>SEC.ondo[s]+SEC.shikaku[s]+SEC.genjo[s]},
 {n:3,nm:'希望',sub:'通勤・給与・勤務',secs:s=>SEC.kibo[s]+SEC.must[s]},
 {n:4,nm:'戻り',sub:'本音・連絡・他社',secs:s=>SEC.modori[s]+SEC.renraku[s]+SEC.tasha[s]},
 {n:5,nm:'締め',sub:'次回・同意',secs:s=>SEC.shime[s]}
];
// 強みタグの手がかり（キーワード一致。AIなし）
const KW={'急変対応':['急変','救急','緊急'],'家族への説明':['家族','ご家族','説明'],'新人の指導':['新人','指導','プリセプター','教育'],'多職種連携':['多職種','連携','リハ','ケアマネ','医師と'],'記録の正確さ':['記録','正確','カルテ'],'看取り':['看取り','ターミナル','終末期'],'認知症ケア':['認知症'],'在宅・訪問':['在宅','訪問'],'段取り・調整':['段取り','調整','回し','シフト','お迎え'],'夜勤帯を任される':['夜勤帯','夜勤リーダー','任され','頼まれ'],'子どもの安全':['園児','安全','怪我'],'保護者対応':['保護者'],'行事の企画':['行事','企画'],'献立・発注':['献立','発注'],'衛生管理':['衛生']};

/* ===== 台本（93-044） ===== */
const SENGEN=[
 `「ありがとうございます。<b>貴重なお時間をいただいているので、無駄がないように、短い時間でできるだけたくさん伺って、〇〇さんの選択肢を多く考えられるようにしたいんです。</b>だから少し駆け足になるかもしれませんが、ご容赦ください。⏸
<b>ここから、少し立ち入ったことも伺うので、先にこちらの約束をお伝えさせてください。</b>⏸

まず、<b>〇〇さんの情報は、必要なところに、必要な分だけしか出しません。</b>⏸
それと、<b>AIも使って無駄なく進めたいので、この通話は録音させていただいています。</b>録った内容も同じで、必要なところに必要な分だけ。不要に回すことはしません。⏸
施設さんに出すときも、<b>〇〇さんに中身を見ていただいてからです。</b>勝手には出しません。⏸

それと、<b>面接を勝手に組んだりはしません。</b>〇〇さんが行きたいと思ってから、私が動きます。⏸
<b>転職するかどうかも、〇〇さんが決めてください。</b>私は、今の職場と候補で<b>何がどう変わるか</b>を、そのままお出しするだけです。良いところも、良くないところも。⏸

その代わり、<b>一つだけお願いがあって。嘘だけはつかないでいただきたいんです。</b>⏸　迷ってるとか、やっぱりやめたいとか、そのままで大丈夫なので。<b>正直に言っていただけたら、その範囲で、できることは全部やります。</b>⏸

あと、他の会社さんとも話されてるかもしれませんが、<b>それは全然かまいません。</b>⏸　ただ、同じ求人を重ねて出したりすると〇〇さんが困るので、<b>話しやすいときで大丈夫です、どこかで教えてください。</b>⏸

——<b>以上です。</b>では、聞かせてください」`,
 `「貴重なお時間なので、駆け足でたくさん伺いますね。ここから少し立ち入ったことも伺うので、<b>先に二つだけ。</b>⏸
〇〇さんの情報は、<b>勝手に出しません。</b>AIも使うので録音していますが、それも同じです。施設さんに出すときも、中身を見ていただいてからです。⏸
それと、<b>転職するかどうかは〇〇さんが決めてください。</b>私は、何がどう変わるかを、そのままお出しするだけです。⏸
その代わり一つだけ、<b>嘘だけはつかないでください。</b>正直に言っていただけたら、できることは全部やります」`,
 `「AIも使うので録音していますが、<b>〇〇さんの情報を勝手に出したり、面接を勝手に組んだりはしませんので、そこはご安心ください</b>」`
];
const SENGEN_T=['全文 1分38秒','短縮 37秒','一言 8秒'];

// 受け：項目の値ごと（93-044 答え別の受け方／93-051）
const RECV={
 aite:{
  '本気':'<b>フル台本。</b>今日中に送る',
  '情報収集':'<b>売り込まない。</b>「決めていなくて大丈夫です」。動く条件を一つ取って、連絡の許可',
  'うんざり':'<b>同じ話をさせない、と先に言う。</b>短く。「今日は5分で、状況だけ伺って、合うものがあれば送ります」',
  '他社先行':'<b>同じ求人を並べない。</b>「そちらで足りていないものはありますか」。進捗だけ聞いて、違う角度の一件を送る',
  '仕事中・移動中':'時間を取って切る。「では<b>いつなら</b>5分いただけますか」→ 日時を取る'
 },
 shokureki:{
  '一つの職場が長い':'「一つの病院で〇年ですか。<b>それは施設さんから見ると、かなり信頼される経歴です</b>」',
  '複数の職場を経験':'「いろんな現場を見られてるんですね。<b>そのぶん、合う合わないが分かってらっしゃると思います</b>」<span class="no">　×「転職が多いですね」（絶対に言わない）</span>',
  'ブランクあり':'「<b>ブランクは全然大丈夫です。</b>復帰の方を受け入れている職場、けっこうあります」⏸「差し支えなければ、どのくらいお休みされてました？」<span class="no">　×理由を先に聞く</span>',
  '新卒・第二新卒':'「最初の職場ですね。<b>ここで合うところを選べると、その後がぜんぜん違います</b>」'
 },
 yakin:{
  'あり（二交代）':'「夜勤もされてたんですね。<b>夜勤ありなら、選べる求人がぐっと増えます</b>」',
  'あり（三交代）':'「夜勤もされてたんですね。<b>夜勤ありなら、選べる求人がぐっと増えます</b>」',
  'なし':'「<b>日勤のみで探されている方、多いです。</b>数は絞られますが、ちゃんとあります」<span class="no">　×「夜勤ができないと厳しいですよ」</span>',
  'もうやりたくない':'「<b>日勤のみで探されている方、多いです。</b>数は絞られますが、ちゃんとあります」→ 希望勤務形態「日勤のみ」に直結<span class="no">　×脅し</span>'
 },
 kikkake:{
  '給与':'「あー、そうなんですね。⏸ <b>それって、金額そのものというより、上がっていく感じがしない、みたいなところもありますか？</b>」',
  '人間関係':'「<b>それは、しんどいですね。</b>」⏸「差し支えない範囲で大丈夫ですので」<span class="no">　×面白がる／職場を悪く言う</span>',
  '夜勤・体力':'「夜勤、きついですよね。<b>何年か続けると、体の方が先に言ってきますよね</b>」<span class="no">　×「まだお若いのに」</span>',
  '家庭の事情':'「<b>お子さん（ご家族）のことですね。</b>⏸ そうすると、時間の方が大事になってきますよね」→ 通勤・勤務形態の背景に直結<span class="no">　×詳しく聞き込む</span>',
  '通勤':'「毎日だと、往復で相当な時間ですもんね」',
  '評価・昇給':'「あー、そうなんですね。⏸ 上がっていく感じがしない、というところですかね」',
  '職場の方針':'「なるほど。⏸ それって、〇〇（相手の言葉）が一番大きい、ということですかね？」',
  '漠然・情報収集':'「<b>それで全然大丈夫です。</b>⏸ 逆に、今の職場で<b>ここだけは</b>、というのはありますか？」<span class="no">　×「本気で探してますか」</span>'
 },
 kyuyo_hoko:{
  '上げたい':'「<b>最低ここは絶対、というラインはありますか？</b> それとも、できればこのくらい、という希望でしょうか」',
  '同じくらいでいい':'「同じくらいですね、承知しました。⏸ 最低ここは、というラインだけ伺っておいてもいいですか」',
  '他を優先して少し下がってもいい':'「<b>そうなんですね。</b>それ、けっこう大事なところなので、あとでもう少し聞かせてください」→ 戻りで「<b>何を得るためなら</b>、下げてもいいと思えますか？」'
 },
 tasha:{
  '有':'「<b>そうですよね、何社かから連絡きますよね。</b>⏸ 教えていただいてありがとうございます」→「それなら、こちらは〇〇（違う角度）で探しますね」<span class="no">　×詮索する</span>',
  '無':'「そうなんですね。<b>では、うちだけの情報になってしまうので、比べる材料もちゃんとお出しします</b>」<span class="no">　×「うちだけにしてください」</span>',
  '確認中':'それ以上聞かない。二回目に。「今でなくて大丈夫」を守る'
 },
 sms:{
  '可':'「ありがとうございます。持ち物や確認はショートメッセージでお送りしますね」',
  '不可':'「承知しました。では電話（または選んだ手段）でご連絡しますね」'
 }
};

// 各面の台本（左）
function scriptHTML(p){
 const v=allVals();
 if(p===1)return `
 <div class="sec"><h3>0.5 繋がった瞬間 <span class="t">30秒で読む</span></h3>
  <div class="say next">「〇〇さん、はじめまして。〇〇の〇〇と申します。ご登録ありがとうございます。今、<b>5分ほど</b>お話しできますか？」
「今回ご登録いただいたのは、<b>本格的に探されている感じですか？それとも、まずは情報収集で？</b>——どちらでも大丈夫です」</div>
  ${recvBox('aite','相手の状態を選ぶと、こちらがやること')}
 </div>
 <div class="sec"><h3>1 最初のひと言 <span class="t">約2.4分・まだ宣言しない</span></h3>
  <div class="say">「ありがとうございます。<b>登録されると、たぶんもう何件かお電話きてますよね。</b>⏸ すみません、うちもその一つなんですけど。⏸
<b>同じことを何度もお聞きするつもりはないので、</b>まず、ご登録の内容だけ確認させてください。⏸</div>
  <details><summary>続き（時間を取る）</summary><div class="say">そのうえで、今日は〇〇さんがどういう働き方を探しているかを伺って、通える範囲で条件に合う求人を、<b>今日中か明日にはお送りします。</b>
<b>できれば15分</b>いただけると条件をしっかり伺えますし、余裕があれば、本当は何を変えたいのかというところまで話せると<b>外さない提案</b>ができるので、<b>トータル30分</b>ほど。<b>今日はどのくらい大丈夫そうですか？</b>」</div><p class="note">相手の答えで上の「持ち時間」を合わせる。5分→通勤圏と時期の二つ＋次回の約束。15分→短縮版の宣言＋四つ。</p></details>
 
  <details><summary>応募からの入口（求人を見て応募した人はこちら）</summary><div class="say">「〇〇さん、はじめまして。<b>△△の求人にご応募いただいた件で</b>お電話しました、Good Luckの□□です。ありがとうございます。⏸
あの求人は、<b>私どもが施設さんからお預かりしていて、ご応募の方の窓口を私が務めます。</b>⏸
まず一つだけ——<b>あの求人の、どこに惹かれましたか？</b>⏸
ありがとうございます。<b>実は、同じ条件で他にもお出しできる求人がいくつかあるので、あの求人を軸に、比べるものも一緒にお持ちします。</b>⏸ 選ぶのは〇〇さんです。
そのために、<b>施設さんに推薦するときに要る分だけ、〇〇さんのことを伺ってもいいですか？</b>⏸ 10分ほどで済みます」</div><p class="note">応募先を否定しない・窓口として名乗る・「惹かれた点」＝希望条件の入口。宣言は一言版。戻りは二回目。</p></details>
</div>
 <div class="sec"><h3>1.5 確認 <span class="t">1〜2分・パンパン</span></h3>
  <div class="say">「まず、<b>ご登録いただいた情報を確認させてください。</b>はい・いいえで大丈夫です。
正看護師さんでお間違いないですか？——ご経験は〇年——今は〇〇病院にお勤めで——お住まいは〇〇市——」
「<b>いくつか質問させてください。</b>——夜勤のご経験は？——今の月給は、夜勤込みでだいたい？——」</div>
  <p class="note">登録情報があるなら読み上げて確認するだけ。聞き直さない。背景はここでは取らない。</p>
  ${recvBox('shokureki','職歴の形の受け')}
  ${recvBox('yakin','夜勤経験の受け')}
  <div class="recv"><span class="lab">給料の受け</span>「<b>29万で、夜勤4回込みですよね。</b>」（必ず復唱）
言いたくなさそう →「<b>だいたいで大丈夫です。</b>20万台の前半か後半か、くらいでも」<span class="no">　×「安いですね」「もっともらえますよ」</span></div>
 </div>
 <div class="sec"><h3>1.8 宣言 <span class="t" id="sengenT">${SENGEN_T[st.sengen]}</span></h3>
  <div class="seg" id="sengenSeg">${['全文','短縮','一言'].map((s,i)=>`<button class="${st.sengen===i?'on':''}" data-i="${i}">${s}</button>`).join('')}</div>
  <div class="say" style="margin-top:6px">${SENGEN[st.sengen]}</div>
  <p class="note">30分→全文／15分→短縮／5分・うんざり・情報収集→一言。相手が既に本音を話し始めていたら遮らず後回し。</p>
 </div>`;
 if(p===2){
  const q={'本気':'「差し支えなければ、<b>今回、転職を考えられたきっかけ</b>を教えていただけますか？」','情報収集':'「<b>ご登録いただいたのは、今の職場で何か気になることがあって？</b>それとも、たまたま？」——たまたまなら、それでいい','他社先行':'「他の会社さんとお話しされているなら、<b>同じことを二度お聞きするのは申し訳ないので</b>、一つだけ——<b>そちらで、これは違うなと思ったことはありますか？</b>」'};
  const qq=q[v.aite]||q['本気'];
  return `
 <div class="sec"><h3>2-1 転職のきっかけ <span class="t">開いて聞く・掘らない</span></h3>
  <div class="say next">${qq}</div>
  ${v.aite&&!q[v.aite]?'<p class="note">うんざり・仕事中は台本を降りる。動く条件を一つと連絡の許可だけ。</p>':'<p class="note">相手の状態（①）で問いが変わる。今は「'+(v.aite||'本気')+'」の問い。</p>'}
  <div class="recv"><span class="lab">受け（話が止まったら）</span>「あー、そうなんですね。」⏸
「<b>それって、〇〇（相手の言葉）が一番大きい、ということですかね？</b>」
（しんどい話なら）「それは、大変でしたね。」</div>
  ${recvBox('kikkake','きっかけ別の受け')}
  <details><summary>詰まって出てこないとき（ここで初めて例を出す）</summary><div class="say">「皆さんいろいろで、<b>お給料の方もいれば、夜勤がしんどい、ご家庭の事情、という方も</b>います。〇〇さんはどのあたりが近いですか？」</div><p class="note">最初から例を出さない。出すと相手がそれに寄る。</p></details>
 </div>
 <div class="sec"><h3>2-2 転職時期 <span class="t">目標90%</span></h3>
  <div class="say">「<b>いつ頃までに</b>次の職場に移りたい、というイメージはありますか？」</div>
  <div class="recv"><span class="lab">答え別の受け</span><ul>
  <li>すぐ・1ヶ月 →「承知しました。<b>では今日中に出せるものをお送りします</b>」</li>
  <li>具体月 →「〇月ですね。<b>だと、逆算すると〇月には面接ですね</b>」</li>
  <li>未定 →「<b>決まってなくて、全然大丈夫です。</b>そういう方の方が多いので」⏸「<b>何かあれば動く、というのはありますか？</b>給料が上がる求人が出たら、とか、日勤のみのところが見つかったら、とか」<span class="no">　×急がせる</span></li></ul></div>
  <p class="note">背景（ボーナス・契約・子ども）は話の中で出ていればメモ。出ていなければここでは聞かない。戻りで。</p>
 </div>
 <div class="sec"><h3>2-3 現職の状態・3 資格・4 現状 <span class="t">確認で済んでいれば飛ばす</span></h3>
  <div class="say">「今は、お仕事はされていますか？」（在職中→「退職の意思は、職場にお伝えしていますか？」）
「経験年数と、<b>これまでどんな病棟・診療科</b>をご経験されましたか？」
「通勤は今、どのくらいかかっていますか？」</div>
  <div class="recv"><span class="lab">受け</span>「12年ですか、長いですね。」「そのご経験があると、<b>出せる求人がだいぶ変わります。</b>」（事実に驚く。お世辞にしない）</div>
 </div>`;
 }
 if(p===3)return `
 <div class="sec"><h3>5-1 通勤圏 <span class="t">目標90%・最も効く</span></h3>
  <div class="say next">「通勤は、<b>どのくらいまでなら</b>大丈夫ですか？例えば電車で30分とか、車で40分とか」
「<b>電車ですか、車ですか</b>」</div>
  <div class="recv"><span class="lab">受け</span>「車で30分ですね。<b>だと、〇〇の辺りまでは入ってきますね。</b>」（地図を見ながら範囲を言う）</div>
  <p class="note">背景（お迎え・介護・車が無い）は、②で出ていればもう分かっている。出ていなければここでは聞かない。戻りで。</p>
 </div>
 <div class="sec"><h3>5-2 希望給与 <span class="t">目標80%・三段で</span></h3>
  <div class="say">①「今のお給料は、月給でいくらくらいですか？」→ 例「28万」
②「<b>その28万を基準に、次はどうなりたいですか？</b> 上げたい、同じくらいでいい、他を優先して少し下がってもいい」
③「<b>最低ここは絶対、というラインはありますか？</b> それとも、<b>できればこのくらい、という希望</b>でしょうか」</div>
  ${recvBox('kyuyo_hoko','方向別の受け')}
  <p class="note">マストは提案の下限、できたらは順位付け。分けないと提案先がなくなる。</p>
 </div>
 <div class="sec"><h3>5-3 勤務形態 <span class="t">目標90%</span></h3>
  <div class="say">「<b>日勤だけがいいですか、夜勤もできますか？</b>」（夜勤OKなら）「月に何回くらいまでなら？」
「<b>オンコールは大丈夫ですか？</b>」</div>
  <div class="recv"><span class="lab">日勤のみなら</span>「日勤のみですね。<b>数は絞られるので、給与は少し下がる可能性があります。</b>そこは正直にお伝えしておきます」（後で揉めない）</div>
 </div>
 <div class="sec"><h3>5-4 休日</h3>
  <div class="say">「お休みのご希望はありますか？<b>土日は休みたいという方が多いですが、平日休みの方が助かる、という方もいます</b>」</div>
 </div>
 <div class="sec"><h3>6 マスト／できたら <span class="t">一項目ずつ二択で</span></h3>
  <div class="say">「いろいろ伺いました。<b>全部を満たす求人はなかなか無いのが正直なところ</b>です。一つずつ確認させてください——
通勤〇分以内、これは<b>絶対</b>ですか、<b>できれば</b>ですか？
日勤のみ、これは絶対ですか、できればですか？」</div>
  <div class="recv"><span class="lab">分岐</span>全部マスト →「全部を絶対にすると、正直、求人がほぼ無くなります。<b>どれか一つ、できたらに落とせるものはありますか？</b>」
全部できたら → 本音が出ていない。②に戻って「何を変えたいか」</div>
 </div>`;
 if(p===4){
  const w=words();
  const omote=(v.kikkake||[])[0]||'〇〇';
  const kata={'給与':'評価が上がらない／人間関係（師長・同僚）／残業が付かない','通勤':'家庭の事情（お迎え・介護）／夜勤明けの帰宅がきつい','夜勤・体力':'体力・体調／子どもの時間／人間関係','漠然・情報収集':'「今の職場で、ここだけは、というのはありますか？」'}[omote]||'評価が上がらない／人間関係／体力';
  return `
 <div class="sec"><h3>5.5 戻り <span class="t">「先ほどのお話ですが」一巡だけ</span></h3>
  <div class="say next">「先ほど、<b>${omote}</b>とおっしゃっていましたが——<b>他の方ですと、${kata}という話もよく伺います。</b>そういったところは、いかがですか？」</div>
  <p class="note">相手自身の言葉に戻る＋型を差し出す。相手は選ぶだけ。違えば「ちょっと違って…」と言いやすい。</p>
  <div class="recv"><span class="lab">分岐</span><ul>
  <li>「そうです」→ 記録。<b>それ以上は掘らない</b></li>
  <li>「いや、そういうのではなくて…」→ <b>ここが本命。</b>否定のあとに本当の理由が続く。聞く</li>
  <li>「特に…」→ <b>追わない。</b>「分かりました、また何かあれば」。本音の取得状況＝一回目は出ず</li></ul></div>
  <details${w.length?' open':''}><summary>戻る材料（条件の背景）</summary><div class="say">通勤 →「先ほど、通勤は${v.tsukin?v.tsukin+'分':'〇分'}以内と伺いましたが——<b>お子さんのお迎えとか、ご家族のことで、時間に制約がある方が多いのですが、</b>そういったご事情でしょうか？」
時期 →「${v.jiki||'〇月頃'}、とおっしゃっていましたが——<b>ボーナスの後で、とか、契約の区切りで、という方が多いのですが、</b>何かそういった区切りですか？」
${v.kyuyo_hoko==='他を優先して少し下がってもいい'?'下げてもいい →「少し下がってもいい、とおっしゃっていましたが——<b>夜勤をやめたい、お子さんの時間を取りたい、で下げる方が多いんです。</b>〇〇さんの場合は、何を優先するために、でしょう？」':''}</div></details>
 </div>
 <div class="sec"><h3>6-2 連絡 <span class="t">例を先に。勧めたいものを先頭に</span></h3>
  <div class="say">「ご連絡なんですが——<b>電話の方もショートメッセージの方もいらっしゃるんですけど、</b>LINEもあります。<b>何が一番いいですか？</b>」
「<b>出やすい時間帯</b>はありますか？日中がいちばん多いんですけど、夜の方がいいという方も、休みの日だけという方もいます」
「逆に、<b>避けた方がいい時間</b>はありますか？夜勤明けで寝ている時間とか、職場で出られない時間とか」</div>
  <p class="note">「一番多い」は事実になってから言う（今は電話が大半）。</p>
 </div>
 <div class="sec"><h3>7 他社 <span class="t">最初にお願いした件、として</span></h3>
  <div class="say">「最初にお願いした件なんですが——他の会社さんとのお話、<b>もし進んでいるところがあれば</b>、こちらもそれに合わせて動けるので、<b>差し支えない範囲で</b>教えていただけますか？」</div>
  ${recvBox('tasha','他社の受け')}
 </div>`;
 }
 if(p===5)return `
 <div class="sec"><h3>8 締め・人となり <span class="t">推薦文の一行目</span></h3>
  <div class="say next">「最後に一つだけ。施設さんに〇〇さんを紹介するとき、<b>これは伝えてほしい、というのはありますか？</b>『真面目に働きます』より、『<b>急変対応が得意です</b>』『<b>家族への説明が丁寧です</b>』みたいな方が、ちゃんと伝わるので」</div>
 </div>
 <div class="sec"><h3>良さを返す <span class="t">一通話で二つまで</span></h3>
  <div class="say">「さっきの〇〇の話——<b>それ、〇〇さんの強みですよ</b>」
「もしかして、本当に大事なのは30分じゃなくて、<b>16時半に上がれること</b>ですか？」</div>
  <p class="note">下の面で光った候補のうち、本当にそうだと思うものだけ。</p>
 </div>
 <div class="sec"><h3>次回アポ <span class="t">日時を取ってから切る</span></h3>
  <div class="say">「ありがとうございます。伺った条件で、<b>通える範囲の求人を今日中に〇件ほど</b>お送りします。<b>〇日の〇時頃</b>に、それを見ていただいた感想を伺いにお電話してもよろしいですか？」</div>
  <div class="recv"><span class="lab">取れないとき</span>「では明日、送ったあとにこちらから一度ご連絡します」でこちらの約束にする。空なら24時間後と4日後にSMSが自動で追う。</div>
 </div>
 <div class="sec"><h3>SMS同意 <span class="t">さらっと</span></h3>
  <div class="say">「それと、求人のお知らせや、面接の前の持ち物・確認は、<b>ショートメッセージでお送りしますね。大丈夫ですか？</b>」</div>
  ${recvBox('sms','')}
 </div>
 <div class="sec"><h3>担当への希望</h3>
  <div class="say">「あと一つだけ。<b>私がお休みの日はサポート役がつきますし、もし途中で担当が変わることがあったら</b>、引き継ぐ相手について——<b>こういう方がいい、というご希望があれば聞かせてください。</b>同じ年代がいい、とか、テンポよく進めてほしい、とか」</div>
  <p class="note">「〇〇さんのままで」と言われたら、それが今の担当の評価。</p>
 </div>
 <div class="sec"><h3>知らないことを聞かれたら</h3>
  <div class="recv">「すみません、そこは私、現場を経験していないので正確なことは言えません。<b>施設さんに直接聞けるのが私の仕事なので、確認して〇日までにお返しします</b>」→「施設に確認すると約束したこと」に書く</div>
 </div>`;
}
function recvBox(id,lab){
 const r=RECV[id];if(!r)return'';
 const v=allVals()[id];const sel=Array.isArray(v)?v:(v?[v]:[]);
 const items=Object.keys(r).map(k=>`<li class="${sel.includes(k)?'hit':''}">${k} → ${r[k]}</li>`).join('');
 return `<div class="recv">${lab?`<span class="lab">${lab}</span>`:''}<ul>${items}</ul></div>`;
}

/* ===== 状態 ===== */
const st={p:1,sengen:0,run:false,t0:null,acc:0,phaseT:0,phaseAcc:{}};
const BUDGET=()=>+document.getElementById('budget').value;
const SPEED=()=>+document.getElementById('speed').value;
function vals(){
 const v={};
 F.forEach(f=>{
  const el=document.querySelector(`[data-f="${f.id}"]`);if(!el)return;
  if(f.t==='chk')v[f.id]=[...el.querySelectorAll('input:checked')].map(i=>i.value);
  else if(f.t==='seg')v[f.id]=el.dataset.v||'';
  else v[f.id]=(el.value||'').trim();
 });
 return v;
}
function words(){
 const v=allVals();const m=v.memo||'';
 return m.split(/\n|／/).map(s=>s.replace(/^[「『]|[」』]$/g,'').trim()).filter(Boolean);
}

/* ===== 描画 ===== */
function buildForm(){
 const wrap=document.getElementById('form');wrap.innerHTML='';
 const p=st.p;const fs=F.filter(f=>f.p===p);
 let g='';let gdiv;
 fs.forEach(f=>{
  if(f.g!==g){g=f.g;gdiv=document.createElement('div');gdiv.className='grp';gdiv.innerHTML=`<h3>${g}</h3>`;wrap.appendChild(gdiv);}
  gdiv.appendChild(fieldEl(f));
 });
 if(p===5){const d=document.createElement('p');d.className='note';d.textContent='通話後：必ず取る8つが埋まっているか確認 → 約束した求人を送る → 自己PR文の下書き（別途）';wrap.appendChild(d);}
 restore();
}
function fieldEl(f){
 const d=document.createElement('div');d.className='f';d.id='f_'+f.id;
 const lab=`<label for="i_${f.id}">${f.l}${f.req?'<span class="req">*</span>':''}<span class="src">${f.src||''}</span></label>`;
 let inp='';
 if(f.t==='sel')inp=`<div><select id="i_${f.id}" data-f="${f.id}"><option value="">—</option>${f.o.map(o=>`<option>${o}</option>`).join('')}</select>${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='text')inp=`<div><input type="text" id="i_${f.id}" data-f="${f.id}" placeholder="${f.ph||''}">${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='num')inp=`<div class="unit"><input type="number" id="i_${f.id}" data-f="${f.id}" min="0"><span>${f.unit||''}</span></div>`;
 else if(f.t==='dt')inp=`<div><input type="datetime-local" id="i_${f.id}" data-f="${f.id}" step="60">${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='ta')inp=`<div><textarea id="i_${f.id}" data-f="${f.id}" rows="${f.rows||3}" placeholder="${f.ph||''}"></textarea>${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='chk')inp=`<div><div class="chips" data-f="${f.id}">${f.o.map(o=>`<label class="chip"><input type="checkbox" value="${o}">${o}</label>`).join('')}</div>${f.hint?`<div class="mini">${f.hint}</div>`:''}</div>`;
 else if(f.t==='seg')inp=`<div><div class="seg kbn" data-f="${f.id}" data-v="">${f.o.map(o=>`<button type="button" data-v="${o}">${o}</button>`).join('')}</div></div>`;
 d.innerHTML=lab+inp;
 return d;
}
// 値の保持（面を切り替えてもDOMを作り直すので、メモリに持つ）
const store={};
function persist(){Object.assign(store,vals());}
function restore(){
 F.forEach(f=>{
  const el=document.querySelector(`[data-f="${f.id}"]`);if(!el)return;const v=store[f.id];if(v==null)return;
  if(f.t==='chk'){el.querySelectorAll('input').forEach(i=>{i.checked=v.includes(i.value);i.parentElement.classList.toggle('on',i.checked)});}
  else if(f.t==='seg'){el.dataset.v=v;el.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));}
  else el.value=v;
 });
}
function allVals(){persist();return Object.assign({},store);}

function buildPhases(){
 const s=SPEED();const el=document.getElementById('phases');el.innerHTML='';
 PH.forEach(ph=>{
  const min=(ph.secs(s)/60).toFixed(1);
  const b=document.createElement('button');b.className='ph'+(ph.n===st.p?' on':'')+(ph.n<st.p?' done':'');b.dataset.n=ph.n;
  const pct=phasePct(ph.n);
  b.innerHTML=`<span class="n">${ph.n}</span><span class="col"><div><span class="nm">${ph.nm}</span><span class="mn">見込み ${min}分</span></div><span class="fill"><i style="width:${pct}%"></i></span></span>`;
  b.onclick=()=>go(ph.n);el.appendChild(b);
 });
}
function phasePct(n){
 const v=allVals();const fs=F.filter(f=>f.p===n);if(!fs.length)return 0;
 const filled=fs.filter(f=>has(v[f.id])).length;return Math.round(filled/fs.length*100);
}
function has(x){return Array.isArray(x)?x.length>0:!!x;}

function updateTop(){
 const v=allVals();
 // マスト
 const m=MUST.map(x=>x.ok(v));const n=m.filter(Boolean).length;
 document.getElementById('mustN').textContent=n;
 document.getElementById('mustDots').innerHTML=m.map((ok,i)=>`<i class="${ok?'on':''}" title="${MUST[i].l}"></i>`).join('');
 // 全体%（背景・本音は重く）
 let tot=0,got=0;F.filter(f=>f.p>0).forEach(f=>{const w=f.w||1;tot+=w;if(has(v[f.id]))got+=w;});
 document.getElementById('allP').textContent=Math.round(got/tot*100);
 document.getElementById('aiteChip').textContent=v.aite?'・'+v.aite:'';
 // 見込み
 const s=SPEED();const inPhase=phaseElapsed();
 let must=0,all=0;
 PH.forEach(ph=>{let sec=ph.secs(s);if(ph.n===st.p)sec=Math.max(0,sec-inPhase);if(ph.n>=st.p){all+=sec;if(ph.n<=3)must+=sec;}});
 document.getElementById('etaMust').textContent=st.p<=3?'あと'+Math.ceil(must/60)+'分':'済';
 document.getElementById('etaAll').textContent='あと'+Math.ceil(all/60)+'分';
 // 促し
 nudges(v,n);
 // 拾った言葉
 const w=words();const ul=document.getElementById('words');
 ul.innerHTML=w.length?w.map(x=>`<li title="台本の〇〇に入れる"><span class="q">「${x}」</span></li>`).join(''):'<li class="empty">面談メモに相手の言葉を一行ずつ</li>';
 ul.querySelectorAll('li:not(.empty)').forEach((li,i)=>li.onclick=()=>{document.querySelectorAll('#script .say').forEach(s=>{s.innerHTML=s.innerHTML.replace(/〇〇（相手の言葉）|〇〇（表向き）/g,'<b>'+w[i]+'</b>')});});
 // 強み
 lightTsuyomi(v);
 // 入った印
 F.forEach(f=>{const d=document.getElementById('f_'+f.id);if(d)d.classList.toggle('filled',has(v[f.id]));});
 buildPhases();
}
function nudges(v,n){
 const L=[];
 const after=(p)=>st.p>p;
 if(after(1)&&!v.aite)L.push(['相手の状態が空です（目標100%）。一言で記録','']);
 if(after(3)&&!(v.tsukin&&v.shudan))L.push(['通勤圏、まだ取れていません（目標90%の項目です）','']);
 if(after(2)&&!v.jiki)L.push(['転職時期が空です。「未定」も値','']);
 if(after(3)&&!(v.kyuyo_hoko))L.push(['希望給与が空です。「今より上/同じ/下でもいい」だけでも','']);
 if(after(3)&&!v.kinmu)L.push(['勤務形態、まだ。「日勤だけ？夜勤も？」の一言','']);
 if(after(4)&&!v.tasha)L.push(['他社状況、確認しましたか','']);
 if(after(4)&&!((v.renraku||[]).length&&(v.jikantai||[]).length))L.push(['連絡は手段＋時間帯まで取って「取れた」','']);
 if(st.p===5&&!v.appo)L.push(['次回アポ日時が空です。日時を取ってから切りましょう','']);
 if(st.p>=3&&v.tsukin&&!(v.haikei||'').length)L.push(['通勤の背景、まだ拾えていません','soft']);
 if(st.p>=4&&!v.honne&&!v.honne_st)L.push(['本音、まだ取れていません → 「先ほど'+((v.kikkake||[])[0]||'〇〇')+'と伺いましたが、他の方だと…」','soft']);
 if(v.kyuyo_hoko==='他を優先して少し下がってもいい'&&!(v.haikei||'').match(/下げ|得|ため/))L.push(['「下げてもいい」の理由（何を得るため）が背景メモに無い','soft']);
 if(!L.length)L.push([n===8?'マスト 8/8。全体は%で見る':'今の面で取るものは揃っています','ok']);
 document.getElementById('nudge').innerHTML=L.map(([t,c])=>`<li class="${c}">${t}</li>`).join('');
}
function lightTsuyomi(v){
 const text=(v.memo||'')+'\n'+(v.hitotonari||'')+'\n'+(v.haikei||'');
 const hits=[];
 document.querySelectorAll('#tsuyomi .chip').forEach(c=>{
  const tag=c.querySelector('input').value;const kws=KW[tag]||[];
  const hit=kws.some(k=>text.includes(k));c.classList.toggle('hint',hit);if(hit)hits.push(tag);
 });
 const h=document.getElementById('tsuyomiHint');
 h.textContent=hits.length?'メモの言葉から候補：'+hits.join('・')+'　→ 事実と対で口に出す。「さっきの〇〇の話、それ強みですよ」':'メモに事実が入ると、候補が光ります。事実が無い良さは出しません。';
}
function phaseElapsed(){return (st.phaseAcc[st.p]||0)+(st.run?(Date.now()-st.phaseT)/1000:0);}

function go(n){
 if(n<1||n>5)return;persist();
 if(st.run){st.phaseAcc[st.p]=phaseElapsed();st.phaseT=Date.now();}
 st.p=n;render();
}
function render(){
 buildForm(); // 先に入力欄を作って store から戻す（台本は store を読むので、この順）
 document.getElementById('script').innerHTML=scriptHTML(st.p);
 const seg=document.getElementById('sengenSeg');
 if(seg)seg.querySelectorAll('button').forEach(b=>b.onclick=()=>{st.sengen=+b.dataset.i;render();});
 wire();updateTop();
}
function wire(){
 document.querySelectorAll('#form [data-f]').forEach(el=>{
  el.addEventListener('input',()=>{updateTop();refreshRecv();});
  el.addEventListener('change',()=>{updateTop();refreshRecv();});
 });
 document.querySelectorAll('#form .chips').forEach(c=>c.querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>{i.parentElement.classList.toggle('on',i.checked);updateTop();refreshRecv();})));
 document.querySelectorAll('#form .seg.kbn').forEach(s=>s.querySelectorAll('button').forEach(b=>b.onclick=()=>{s.dataset.v=s.dataset.v===b.dataset.v?'':b.dataset.v;s.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x.dataset.v===s.dataset.v));updateTop();}));
}
function refreshRecv(){ // 受けだけ差し替え（入力中に台本全体を作り直さない）
 const keep=document.getElementById('script');const scroll=keep.scrollTop;
 const open=[...keep.querySelectorAll('details')].map(d=>d.open);
 keep.innerHTML=scriptHTML(st.p);
 [...keep.querySelectorAll('details')].forEach((d,i)=>{if(open[i]!=null)d.open=open[i]});
 const seg=document.getElementById('sengenSeg');if(seg)seg.querySelectorAll('button').forEach(b=>b.onclick=()=>{st.sengen=+b.dataset.i;render();});
 keep.scrollTop=scroll;
}

/* ===== タイマー（30分版） ===== */
function tick(){
 const e=st.acc+(st.run?(Date.now()-st.t0)/1000:0);
 const mm=Math.floor(e/60),ss=Math.floor(e%60);
 document.getElementById('clock').textContent=`${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
 const b=BUDGET()*60;const r=b-e;const rEl=document.getElementById('remain');
 const rm=Math.floor(Math.abs(r)/60),rs=Math.floor(Math.abs(r)%60);
 rEl.textContent=(r<0?'超過 ':'残り ')+`${String(rm).padStart(2,'0')}:${String(rs).padStart(2,'0')}`;
 rEl.classList.toggle('warn',r<180);
 const w=document.getElementById('warnline');
 const v=store;
 if(st.run&&r<180&&!v.appo){w.textContent=(r<0?'時間を超えています。':'残り3分です。')+'次回アポを取りましょう。';w.classList.add('on');}
 else w.classList.remove('on');
 if(st.run&&Math.floor(e)%5===0)updateTop();
}
document.getElementById('startBtn').onclick=function(){
 if(st.run){st.acc+=(Date.now()-st.t0)/1000;st.phaseAcc[st.p]=phaseElapsed();st.run=false;this.textContent='再開';}
 else{st.t0=Date.now();st.phaseT=Date.now();st.run=true;this.textContent='一時停止';}
};
document.getElementById('resetBtn').onclick=()=>{st.run=false;st.acc=0;st.phaseAcc={};document.getElementById('startBtn').textContent='開始';tick();updateTop();};
setInterval(tick,500);
document.getElementById('budget').onchange=function(){const b=+this.value;st.sengen=b>=30?0:b>=15?1:2;render();tick();};
document.getElementById('speed').onchange=()=>updateTop();

/* ===== キー ===== */
document.addEventListener('keydown',e=>{
 const tag=(e.target.tagName||'').toLowerCase();const typing=['input','textarea','select'].includes(tag);
 if(e.key==='ArrowRight'&&(!typing||e.altKey)){e.preventDefault();go(st.p+1);}
 if(e.key==='ArrowLeft'&&(!typing||e.altKey)){e.preventDefault();go(st.p-1);}
 if(e.key==='Tab'&&e.ctrlKey){e.preventDefault();go(e.shiftKey?st.p-1:st.p+1);}
});

/* ===== ⑤ 強みタグ ===== */
(function(){
 const w=document.getElementById('tsuyomi');
 w.innerHTML=O.tsuyomi.map(o=>`<label class="chip"><input type="checkbox" value="${o}">${o}</label>`).join('');
 w.dataset.f='tsuyomi';
 w.querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>{i.parentElement.classList.toggle('on',i.checked);store.tsuyomi=[...w.querySelectorAll('input:checked')].map(x=>x.value);}));
})();
// vals() は #form 内の [data-f] を見るので、強みタグは store に直接持つ（上）。allVals で合流。
const _vals=vals;
vals=function(){const v=_vals();v.tsuyomi=[...document.querySelectorAll('#tsuyomi input:checked')].map(x=>x.value);return v;};

/* ===== PORTERSへ書く内容 ===== */
function buildOut(){
 const v=allVals();const L=[];
 const fmt=x=>Array.isArray(x)?x.join('／'):x;
 const dt=x=>x?x.replace('T',' '):'';
 L.push('【レジュメ更新】Aさん　一回目ヒアリング　'+new Date().toLocaleDateString('ja-JP'));
 const m=MUST.map(x=>x.ok(v));
 L.push(`マスト ${m.filter(Boolean).length}/8　全体 ${document.getElementById('allP').textContent}%　通話 ${document.getElementById('clock').textContent}`);
 L.push('');
 let g='';
 F.filter(f=>f.p>0).forEach(f=>{
  if(!has(v[f.id]))return;
  if(f.g!==g){g=f.g;L.push('■ '+g);}
  let val=f.t==='dt'?dt(v[f.id]):fmt(v[f.id]);
  if(f.t==='num'&&f.unit)val+=' '+f.unit.split('（')[0];
  if(f.t==='ta')L.push(`${f.l}：\n${val.split('\n').map(s=>'　'+s).join('\n')}`);
  else L.push(`${f.l}：${val}`);
 });
 if((v.tsuyomi||[]).length){L.push('■ この人の良さ');L.push('強みタグ：'+v.tsuyomi.join('／'));}
 const miss=MUST.filter((x,i)=>!m[i]).map(x=>x.l);
 L.push('');L.push(miss.length?'△ 取れていないマスト：'+miss.join('／')+'　→ 次回の先頭に':'○ マスト 8/8');
 if(!v.appo)L.push('△ 次回アポが空。24時間後・4日後にSMSが自動で追う（同意：'+(v.sms||'(空白)')+'）');
 return L.join('\n');
}
document.getElementById('outBtn').onclick=()=>{document.getElementById('outText').textContent=buildOut();document.getElementById('out').classList.add('on');document.getElementById('out').scrollIntoView({behavior:'smooth'});};
document.getElementById('copyBtn').onclick=async()=>{
 const t=document.getElementById('outText').textContent;const msg=document.getElementById('copyMsg');
 try{await navigator.clipboard.writeText(t);msg.textContent='コピーしました';}
 catch(e){const r=document.createRange();r.selectNodeContents(document.getElementById('outText'));const s=getSelection();s.removeAllRanges();s.addRange(r);msg.textContent='選択しました。⌘C で';}
 setTimeout(()=>msg.textContent='',2500);
};

/* ===== 見本（Aさん・93-049 の例。個人情報なし） ===== */
const SAMPLE={aite:'本気',koyou:'正社員',shikaku:'正看護師',keiken:'急性期病棟 12年（二交代）',shokureki:'一つの職場が長い',yakin:'あり（二交代）',gessyu:'29',
 kikkake:['夜勤・体力','家庭の事情'],memo:'「夜勤がきつくなってきた」\n「子どもが小学校に上がる」\n「17時にお迎え」\n「同じような病院ばかり」\n「師長に頼まれるのは急変対応」\n「家族の話を聞くのが好き」',jiki:'2027年4月',haikei:'子どもの進学。4月が本命。\n通勤30分は17時の学童のお迎えのため。16時半上がりなら40分圏でも。\n下げてもいい理由：夜勤をやめて子どもの時間。本当のマストは日勤のみ。',
 tsukin:'30',shudan:'車',tsukin_kbn:'マスト',kyuyo_hoko:'他を優先して少し下がってもいい',kyuyo_must:'25',kyuyo_dekitara:'27',kinmu:'日勤のみ',oncall:'不可',kinmu_kbn:'マスト',yasumi:'土日（できたら）',
 fuman:['夜勤・体力','家庭との両立'],honne:'',honne_st:'一回目は出ず',renraku:['ショートメッセージ','電話'],jikantai:['日中（10〜16時）'],renraku_kibo:'夜勤明けの午前は不可。17〜20時は家事',tasha:'有',
 hitotonari:'施設に伝えてほしいこと：「家族の話を聞くのが好き。患者さんより家族が不安なことが多い」\n休日：子どもと公園。パン作り。\n返した良さ：家族を含めて看る目／生活を回し切る段取り力',hani:'人となりのみ',appo:'',sms:'可',tanto:'今の担当のままがいい。話が早いので',yakusoku:'B社は「同じような病院ばかり」→ クリニック・訪看で違う角度を3件、今日中に',tsuyomi:['急変対応','家族への説明']};
document.getElementById('sampleBtn').onclick=()=>{Object.assign(store,SAMPLE);store.tsuyomi=SAMPLE.tsuyomi;document.querySelectorAll('#tsuyomi input').forEach(i=>{i.checked=SAMPLE.tsuyomi.includes(i.value);i.parentElement.classList.toggle('on',i.checked)});render();};
document.getElementById('clearBtn').onclick=()=>{if(!confirm('入力を全部消しますか'))return;Object.keys(store).forEach(k=>delete store[k]);document.querySelectorAll('#tsuyomi input').forEach(i=>{i.checked=false;i.parentElement.classList.remove('on')});document.getElementById('out').classList.remove('on');render();};

render();tick();

;
(function(){function h(){var t=document.querySelector(".top");if(t)document.documentElement.style.setProperty("--toph",t.offsetHeight+"px");}h();window.addEventListener("resize",h);setTimeout(h,300);})();
;
(function(){function c(){var n=document.querySelectorAll("#tsuyomi .chip.hint, #tsuyomi .chip.on").length;var e=document.getElementById("tsuyomiCnt");if(e)e.textContent=n;}setInterval(c,800);})();
;

/* ===== ⑥ 通話ログ ===== */
(function(){
 const list=document.getElementById('logList'),nEl=document.getElementById('logN');
 const KEY=['夜勤','お迎え','小学校','急変','家族','説明','新人','指導','看取り','認知症','訪問','段取り','頼まれ','子ども','保護者','行事','献立','衛生','夜勤帯'];
 let t0=null;
 function hhmm(){if(!t0)t0=Date.now();const s=Math.floor((Date.now()-t0)/1000);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
 function mark(txt){let h=txt.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));KEY.forEach(k=>{h=h.split(k).join('<span class="hit">'+k+'</span>');});return h;}
 window.logAdd=function(who,txt){
  const li=document.createElement('li');li.className=who==='me'?'me':'';
  li.innerHTML='<span class="t">'+hhmm()+'</span><span class="w">'+(who==='me'?'CA':'相手')+'</span><span>'+mark(txt)+'</span>';
  li.title='面談メモに入れる';
  li.onclick=()=>{ if(who==='me'||li.classList.contains('picked'))return; const ta=document.querySelector('[data-f="memo"]')||document.querySelector('textarea[name="memo"],#memo'); const cur=(store.memo||'').trim(); store.memo=(cur?cur+'\n':'')+'「'+txt+'」'; li.classList.add('picked'); try{restore();words();lightTsuyomi(allVals());}catch(e){} };
  list.appendChild(li); nEl.textContent=list.children.length+'行'; list.scrollTop=list.scrollHeight;
 };
 const inp=document.getElementById('logInput');
 inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&inp.value.trim()){window.logAdd('you',inp.value.trim());inp.value='';}});
 const DEMO=[['me','お忙しいところありがとうございます。今5分ほどお時間いただけますか？'],['you','はい、大丈夫です。'],['me','ご登録の内容を確認させてください。正看護師さんで間違いないですか？'],['you','はい。急性期の病棟に12年います。二交代です。'],['you','夜勤がきつくなってきて。子どもが来年小学校に上がるので、17時にお迎えに行きたくて。'],['me','なるほど、夜勤と時間ですね。'],['you','夜勤帯を任されることが多くて、急変のときは私が先に動く感じでした。'],['you','家族への説明は師長から頼まれることが多かったです。'],['me','それは頼りにされていますね。'],['you','同じような病院ばかりで、訪問とかも少し気になっています。']];
 document.getElementById('logPlay').onclick=()=>{let i=0;t0=Date.now();const iv=setInterval(()=>{if(i>=DEMO.length){clearInterval(iv);return;}window.logAdd(DEMO[i][0],DEMO[i][1]);i++;},1400);};
})();

;/* ===== 音声で書き起こす（Chromeの音声認識・日本語）。相手の声も拾うには、Macの音の経路（BlackHole）を Chrome のマイクにする ===== */
(function(){
 var btn=document.getElementById('micBtn'); if(!btn) return;
 var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){ btn.disabled=true; btn.title='このブラウザでは音声認識が使えません（Chromeで開いてください）'; return; }
 var rec=null, on=false, wantOn=false, lastFinal='';
 function start(){
  rec=new SR(); rec.lang='ja-JP'; rec.continuous=true; rec.interimResults=false; rec.maxAlternatives=1;
  rec.onresult=function(e){ for(var i=e.resultIndex;i<e.results.length;i++){ var r=e.results[i]; if(!r.isFinal) continue; var txt=(r[0].transcript||'').trim(); if(!txt||txt===lastFinal) continue; lastFinal=txt; window.logAdd('you',txt); } };
  rec.onerror=function(e){ if(e.error==='not-allowed'||e.error==='service-not-allowed'){ wantOn=false; setOn(false); alert('マイクの許可が要ります。板の見出しの「別窓」で開くと許可を出せます。'); } };
  rec.onend=function(){ on=false; if(wantOn){ try{ start(); }catch(err){ setOn(false); } } else setOn(false); }; // 無音で切れても続ける
  rec.start(); on=true; setOn(true);
 }
 function setOn(v){ btn.classList.toggle('on',v); btn.textContent=v?'🎙 書き起こし中（押すと止める）':'🎙 音声で書き起こす'; }
 btn.addEventListener('click',function(){ if(wantOn){ wantOn=false; try{ rec&&rec.stop(); }catch(err){} setOn(false); } else { wantOn=true; try{ start(); }catch(err){ wantOn=false; setOn(false); } } });
})();

;/* ===== 近くの施設（地図マッチング MVP）：起点→国土地理院で座標→直線距離で近い施設→駅すぱあとで通勤時間 ===== */
(function(){
 var inp=document.getElementById('nearAddr'), go=document.getElementById('nearGo'), msg=document.getElementById('nearMsg'), list=document.getElementById('nearList'), mapEl=document.getElementById('nearMap');
 if(!inp) return;
 var DATA=null, EK=null, map=null, layer=null;
 function b2u(b){ var s=atob(b), u=new Uint8Array(s.length); for(var i=0;i<s.length;i++) u[i]=s.charCodeAt(i); return u; }
 async function loadData(){
  if(DATA) return DATA;
  var kb=null; try{ kb=localStorage.getItem('glh_key'); }catch(e){}
  if(!kb) throw new Error('この機能はサイト版（合言葉で開いた画面）でだけ使えます');
  var key=await crypto.subtle.importKey('raw',b2u(kb),{name:'AES-GCM'},false,['decrypt']);
  var r=await fetch('./facilities.enc.json',{cache:'no-store'}); if(!r.ok) throw new Error('施設データが読めません');
  var p=await r.json();
  var pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:b2u(p.iv)},key,b2u(p.ct));
  var obj=JSON.parse(new TextDecoder().decode(pt)); DATA=obj.facilities; EK=obj.ekispert||null; return DATA;
 }
 async function geocode(q){
  var r=await fetch('https://msearch.gsi.go.jp/address-search/AddressSearch?q='+encodeURIComponent(q)); var a=await r.json();
  if(!a||!a.length) throw new Error('場所が見つかりません。市区町村から書いてみてください');
  var c=a[0].geometry.coordinates; return {lat:c[1],lng:c[0],title:a[0].properties.title};
 }
 function km(a,b){ var R=6371,dl=(b.lat-a.lat)*Math.PI/180,dg=(b.lng-a.lng)*Math.PI/180,x=Math.sin(dl/2),y=Math.sin(dg/2); var h=x*x+Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*y*y; return 2*R*Math.asin(Math.sqrt(h)); }
 function esc(s){ return String(s||'').replace(/[&<>"]/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
 function loadLeaflet(){
  return new Promise(function(res,rej){
   if(window.L) return res(window.L);
   var l=document.createElement('link'); l.rel='stylesheet'; l.href='https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css'; document.head.appendChild(l);
   var sc=document.createElement('script'); sc.src='https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js'; sc.onload=function(){ res(window.L); }; sc.onerror=function(){ rej(new Error('map')); }; document.head.appendChild(sc);
  });
 }
 async function drawMap(origin,items){
  try{
   var L=await loadLeaflet(); mapEl.hidden=false;
   if(!map){ map=L.map(mapEl,{zoomControl:false,attributionControl:true}); L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png',{attribution:'国土地理院',maxZoom:18}).addTo(map); }
   if(layer) layer.remove(); layer=L.layerGroup().addTo(map);
   L.circleMarker([origin.lat,origin.lng],{radius:7,color:'#E9A2B4',fillColor:'#E9A2B4',fillOpacity:.9}).addTo(layer).bindTooltip('起点');
   var b=[[origin.lat,origin.lng]];
   items.forEach(function(f,i){ L.circleMarker([f.la,f.lo],{radius:5,color:'#3E5A8A',fillColor:'#8FB0E8',fillOpacity:.9}).addTo(layer).bindTooltip((i+1)+'. '+f.n); b.push([f.la,f.lo]); });
   setTimeout(function(){ map.invalidateSize(); map.fitBounds(b,{padding:[12,12]}); },50);
  }catch(e){ mapEl.hidden=true; }
 }

 // ===== ドアドアの時間（駅すぱあと）。座標→座標で引くので、徒歩・バス・電車を駅すぱあとが自分で組む =====
 // 1日に投げる回数の上限（評価版キーの保護。有料に上げたら枠に合わせて変える）
 var EK_DAILY_CAP=500;
 function ekCountKey(){ var d=new Date(); return 'glh_ek_'+d.getFullYear()+('0'+(d.getMonth()+1)).slice(-2)+('0'+d.getDate()).slice(-2); }
 function ekUsed(){ try{ return Number(localStorage.getItem(ekCountKey())||0); }catch(e){ return 0; } }
 async function ekFetch(path){
  var used=ekUsed(); if(used>=EK_DAILY_CAP) throw new Error('駅すぱあとの本日分の上限（'+EK_DAILY_CAP+'回）に達しました');
  try{ localStorage.setItem(ekCountKey(),String(used+1)); }catch(e){}
  var r=await fetch('https://api.ekispert.jp/v1/json/'+path+'&key='+encodeURIComponent(EK)); return r.json();
 }
 // 平日の朝8時発（通勤の目安）。今日が土日なら次の月曜
 function weekdayYmd(){ var d=new Date(); d.setDate(d.getDate()+1); while(d.getDay()===0||d.getDay()===6) d.setDate(d.getDate()+1); return ''+d.getFullYear()+('0'+(d.getMonth()+1)).slice(-2)+('0'+d.getDate()).slice(-2); }
 function lineName(n,isBus){ // バス「国際興業バス・東浦８２・新井宿駅行」→「国際興業バス 東浦82」。電車は「京浜東北・根岸線」のまま
  var s=String(n||'').replace(/[（(][^）)]*[）)]/g,'').replace(/[０-９Ａ-Ｚａ-ｚ]/g,function(c){ return String.fromCharCode(c.charCodeAt(0)-0xFEE0); }).replace(/－/g,'-').trim(); var ps=s.split('・');
  if(ps.length>1&&/行$/.test(ps[ps.length-1])) ps.pop();
  return ps.join(isBus?' ':'・').trim();
 }
 function stName(n){ return String(n||'').replace(/[（(][^）)]*[）)]/g,'').replace(/／.*$/,'').trim(); }
 function parseCourse(c){
  var rt=c.Route; var L=rt.Line; L=Array.isArray(L)?L:(L?[L]:[]); var P=rt.Point; P=Array.isArray(P)?P:(P?[P]:[]);
  var legs=L.map(function(l,i){
   var T=l.Type; var typ=(typeof T==='string')?T:((T&&T.text)||''); if(!typ) typ='walk';
   var pa=P[i]&&P[i].Station, pb=P[i+1]&&P[i+1].Station;
   return {kind:typ==='bus'?'bus':(typ==='walk'?'walk':'train'),line:typ==='walk'?'徒歩':lineName(l.Name,typ==='bus'),from:stName(pa&&pa.Name),to:stName(pb&&pb.Name),mins:Number(l.timeOnBoard||0)};
  });
  // 徒歩が続いたら一つにまとめる
  legs=legs.reduce(function(acc,l){ var p=acc[acc.length-1]; if(p&&p.kind==='walk'&&l.kind==='walk'){ p.mins+=l.mins; p.to=l.to; } else acc.push(l); return acc; },[]);
  var ride=Number(rt.timeOnBoard||0), walk=Number(rt.timeWalk||0), other=Number(rt.timeOther||0);
  return {mins:ride+walk+other,transfers:Number(rt.transferCount||0),legs:legs,ride:ride,walk:walk,other:other,bus:legs.some(function(l){ return l.kind==='bus'; })};
 }
 async function courseBetween(a,b,hhmm){ // a: {lat,lng}、b: {lat,lng} か 駅コード文字列
  var via=(a.code?a.code:(a.lat+','+a.lng+',wgs84'))+':'+(typeof b==='string'?b:(b.lat+','+b.lng+',wgs84'));
  var j=await ekFetch('search/course/extreme?viaList='+encodeURIComponent(via)+'&gcs=wgs84&answerCount=3&searchType=departure&date='+weekdayYmd()+'&time='+(hhmm||'0800'));
  var c=j.ResultSet&&j.ResultSet.Course; c=Array.isArray(c)?c:(c?[c]:[]); if(!c.length) throw new Error('経路なし');
  var best=null; c.forEach(function(x){ var t=parseCourse(x); t.cost=t.mins+4*t.transfers; if(!best||t.cost<best.cost) best=t; });
  if(!(best.mins>0)) throw new Error('時間なし');
  best.dep=(hhmm||'0800').replace(/(\d\d)(\d\d)/,'$1:$2'); return best;
 }
 async function nearestStop(f){ // 施設の最寄り（電車かバス）。一度引いたら施設に持たせて使い回す
  if(f._stop) return f._stop;
  var j=await ekFetch('geo/station?geoPoint='+f.la+','+f.lo+',wgs84&gcs=wgs84&type=train:bus');
  var pt=j.ResultSet&&j.ResultSet.Point; if(Array.isArray(pt)) pt=pt[0]; if(!pt) throw new Error('最寄りなし');
  f._stop={code:pt.Station.code,name:stName(pt.Station.Name),walk:Math.max(1,Math.round(Number(pt.Distance||0)/80))}; return f._stop;
 }
 async function doorToDoor(origin,f){
  try{ return await courseBetween(origin,{lat:f.la,lng:f.lo},'0800'); }
  catch(e){
   if(String(e.message).indexOf('上限')>=0) throw e;
   if(String(e.message).indexOf('経路なし')>=0||String(e.message).indexOf('時間なし')>=0){
    try{ var st=await nearestStop(f); var t=await courseBetween(origin,st.code,'0800'); t.legs.push({kind:'walk',line:'徒歩',from:st.name,to:'',mins:st.walk}); t.mins+=st.walk; t.walk+=st.walk; return t; }catch(e2){}
   }
   if((f.dist||0)<=2.5){ var m=Math.max(1,Math.round((f.dist||0)*1300/80)); return {mins:m,transfers:0,legs:[{kind:'walk',line:'徒歩',mins:m}],ride:0,walk:m,other:0,est:true,bus:false}; }
   throw e;
  }
 }
 // 同時に投げるのは3件まで（評価版キーなので数を絞る）
 async function mapLimited(arr,limit,fn){
  var out=new Array(arr.length), i=0;
  async function worker(){ while(i<arr.length){ var idx=i++; out[idx]=await fn(arr[idx],idx); } }
  await Promise.all(Array.from({length:Math.min(limit,arr.length)},worker));
  return out;
 }
 function timeLabel(t){
  if(!t) return '時間は取れず';
  if(t.est) return '約'+t.mins+'分（徒歩の目安・直線距離から）';
  var lines=(t.legs||[]).filter(function(l){ return l.kind!=='walk'; }).map(function(l){ return l.line+' '+l.mins+'分'; }).join('→');
  return '約'+t.mins+'分・乗り換え'+t.transfers+'回'+(lines?'（'+lines+'）':'');
 }

 // ===== 繁華街（出かける先）：施設から近い順に2つ。平日10時発の目安 =====
 var HUBS=[
  ['大宮',35.9063,139.6238,'21987','埼玉県でいちばん人が集まるターミナル。駅ビルのルミネ・エキュートに、西口のそごう・アルシェ、東口には昔ながらの飲食店街と「南銀」の飲み屋街。新幹線も止まるので、遠出の起点にもなる。','大宮.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AOmiya-STA_West.jpg'],
  ['浦和',35.8590,139.6567,'21982','伊勢丹とパルコが駅前にある県庁所在地の街。駅周辺には個人経営の飲食店や老舗が点在する。文教地区として知られ、公園や図書館も近い。','浦和.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE_Urawa-STA_West-atre.jpg'],
  ['川口',35.8003,139.7207,'22011','駅前にキュポ・ラ（図書館入り）と商店街、少し歩けばアリオ川口。京浜東北線で赤羽・上野・東京へ一本で出られ、ものづくりの街の名残で、鋳物工場跡に新しいマンションが増えている。','川口.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE_Kawaguchi-STA_East.jpg'],
  ['所沢',35.7867,139.4683,'22080','西武線の要で、駅直結のグランエミオ所沢に飲食・雑貨・食品が揃う。西口のプロペ通りは学生や家族連れで賑わう商店街。少し足を伸ばせば航空公園、狭山湖・多摩湖のハイキングコースも。都心へは池袋まで20分台。','所沢.jpg','Kaijooo／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATokorozawa_Station.2020-09-02.jpg'],
  ['川越',35.9078,139.4820,'22012','「小江戸」の名で知られる観光地。駅から北へ歩けば蔵造りの町並み、時の鐘、菓子屋横丁。駅前はアトレとクレアモール商店街。','川越.jpg','user:Fg2／Public domain','https://commons.wikimedia.org/wiki/File%3AKawagoeTowerCommons.jpg'],
  ['新宿',35.6896,139.7006,'22741','乗降客数が日本一の駅。伊勢丹・高島屋・京王の百貨店、ヨドバシ・ビックの家電街、歌舞伎町の飲食と映画館、都庁側の高層ビル街。新宿御苑や中央公園で緑にも触れられる。','新宿.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE_Shinjuku-STA_South.jpg'],
  ['渋谷',35.6580,139.7016,'22715','スクランブル交差点のある街。再開発でスクランブルスクエア・ヒカリエ・ストリームなど駅直結のビルが増え、屋上に展望台。ファッション・音楽・カフェの店が多く、少し歩けば代々木公園と表参道。','渋谷.jpg','Kakidai／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3A2018_Shibuya_Crossing.jpg'],
  ['池袋',35.7295,139.7109,'22513','埼玉方面からの玄関口。西武・東武の百貨店が駅の両側にあり、サンシャインシティには水族館・展望台・プラネタリウム。北口の中華街、東口のアニメ・サブカルの店。飲食店の数が多い。','池袋.jpg','Asanagi／CC0','https://commons.wikimedia.org/wiki/File%3AEast_entrance_of_Ikebukuro_Station_2023-11-09.jpg'],
  ['東京',35.6812,139.7671,'22828','丸の内と八重洲。駅ナカのグランスタ、駅ビルのグラントウキョウ、八重洲地下街に、丸ビル・KITTEの飲食とショップ。赤レンガの駅舎を眺めながら皇居まで歩ける。新幹線の起点なので、帰省や旅行の出発点にもなる。','東京.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATokyo-STA_Marunouchi-Entrance_2023.jpg'],
  ['有楽町・銀座',35.6750,139.7633,'23036','銀座の百貨店（三越・松屋）とブランド店、和光の時計塔。有楽町側には映画館とマルイ、ガード下の飲食店街。少し改まった買い物や食事、記念日の外食に。日曜は中央通りが歩行者天国になる。','有楽町_銀座.jpg','Kentagon／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AGinzaWako_Tokyo2012.JPG'],
  ['上野',35.7138,139.7770,'22528','アメ横の活気と、上野公園の美術館・博物館・動物園が隣り合う街。御徒町側には多慶屋や宝飾の問屋街、湯島・谷中へも歩ける。北関東・東北からの玄関口で、新幹線も止まる。','上野.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE-Ueno-STA.jpg'],
  ['品川',35.6285,139.7387,'22709','新幹線と羽田空港への足がよく、出張や旅行に便利。駅ビルのアトレとエキュート、港南口のオフィス街と飲食店。高輪側には泉岳寺、少し先に品川シーサイドのショッピングモール。','品川.jpg','Aimaimyi／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AShinagawa_Station_-01.jpg'],
  ['立川',35.6989,139.4137,'22799','多摩地区の中心で、伊勢丹・ルミネ・グランデュオが駅に直結。北口のペデストリアンデッキで駅周辺の商業ビルがつながっている。昭和記念公園は四季の花と広い芝生。','立川.jpg','DiKnK8713／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATachikawa_sta_N_20210725.jpg'],
  ['吉祥寺',35.7031,139.5797,'22637','井の頭公園の池と森、サンロード・ダイヤ街の商店街、ハモニカ横丁の小さな飲み屋。個人店のカフェ・雑貨・古着が多い。新宿・渋谷へは電車で15〜20分。','吉祥寺.jpg','やねまか／CC0','https://commons.wikimedia.org/wiki/File%3A%E3%82%AD%E3%83%A9%E3%83%AA%E3%83%8A%E4%BA%AC%E7%8E%8B%E5%90%89%E7%A5%A5%E5%AF%BA%E3%83%BB%E3%82%A2%E3%83%88%E3%83%AC%E5%90%89%E7%A5%A5%E5%AF%BA.jpg'],
  ['町田',35.5420,139.4466,'22976','東京と神奈川の境にある商業地。駅周辺に小田急百貨店・マルイ・ルミネ・東急ツインズが密集し、仲見世商店街や古着屋も多い。横浜線と小田急線が交わり、横浜・新宿の両方へ出やすい。','町田.jpg','Yamada munetaka／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJR_MACHIDA_STATION.jpg'],
  ['北千住',35.7494,139.8050,'22630','5路線が通る東側の要で、都内の主要駅へ一本で出やすい。駅にはマルイ・ルミネ、西口には昔ながらの商店街と居酒屋。大学が集まる学生街でもある。','北千住.jpg','Miyusuke／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3A%E5%8C%97%E5%8D%83%E4%BD%8F%E9%A7%85%E8%A5%BF%E5%8F%A3.jpg'],
  ['錦糸町',35.6967,139.8143,'22640','下町の繁華街。パルコ・テルミナ・アルカキットが駅周辺にあり、南口は飲食店街。錦糸公園は広く、スカイツリーまで歩いて行ける。総武線快速で東京駅まで8分。','錦糸町.jpg','しんぎんぐきゃっと／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3A%E9%8C%A6%E7%B3%B8%E7%94%BA%E9%A7%85%E5%8D%97%E5%8F%A3%28TERMINA%29.jpg'],
  ['横浜',35.4658,139.6223,'23368','西口の高島屋・そごう・ジョイナス・ルミネ、東口のポルタ地下街。少し行けばみなとみらい、赤レンガ倉庫、中華街、山下公園。海と観覧車が見える。','横浜.jpg','Sakura Torch／CC0','https://commons.wikimedia.org/wiki/File%3AYokohama_Station_20240630.jpg'],
  ['川崎',35.5313,139.6968,'23126','ラゾーナ川崎（映画館・食品・雑貨）と地下街アゼリア、東口の商店街と飲食。東京駅へも横浜駅へも20分以内で、両方を使い分けられる。競馬場や工場夜景など少し変わった楽しみもある。','川崎.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE_Kawasaki-STA_East.jpg'],
  ['藤沢',35.3383,139.4871,'23304','湘南の玄関口。駅ビルのルミネと小田急湘南ゲートに、江ノ電で江の島・鎌倉へ。海まで自転車で行ける距離。小田急線・東海道線で都内へも一本。','藤沢.jpg','SElefant／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AFujisawa_Station_SouthGate.jpg'],
  ['本厚木',35.4400,139.3644,'23318','県央の中心で、駅周辺にミロード・イオン・商店街がまとまる。小田急線で新宿まで50分ほど。少し行けば丹沢の山と相模川、温泉施設もあり、休日にすぐ自然に触れられる。','本厚木.jpg','Asturio Cantabrio／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AMylord_1_ac_%282%29.jpg'],
  ['千葉',35.6132,140.1134,'22361','県都のターミナル。そごう千葉店・ペリエ千葉が駅前にあり、中央公園まわりに飲食店。モノレールで千葉港や動物公園へ。東京駅へは総武線快速で40分ほど。','千葉.jpg','Xser21／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AChiba_Station_2024.jpg'],
  ['船橋',35.7018,139.9853,'22427','東武百貨店・シャポー船橋・フェイスが駅前に並び、少し行けばららぽーとTOKYO-BAY、IKEA。船橋港の魚市場や、ふなばしアンデルセン公園も。総武線・京成線・東武線で都内・成田の両方へ出やすい。','船橋.jpg','Mister0124／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AFunabashi_Station_Near_South_Exit.jpg'],
  ['柏',35.8621,139.9710,'22228','東葛地域の中心で、高島屋・柏モディ・ビックカメラ、古着屋や音楽の店が集まる。つくばエクスプレスの柏の葉キャンパスにはららぽーと。上野・東京へは常磐線で30分台。','柏.jpg','ヒタチギ／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AKashiwa_station%28cropped%29.jpg'],
  ['津田沼',35.6913,140.0203,'22370','駅前にイオンモール・モリシア・ペリエ津田沼、大学が多く学生の街でもある。総武線快速で東京駅まで30分ほど。','津田沼.jpg','Archiroid21／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATsudanuma_Station_south_2024.jpg'],
  ['梅田',34.7025,135.4959,'25853','関西最大の繁華街で、阪急・阪神・大丸の百貨店、グランフロント、ルクア、ヨドバシが集まる。広い地下街で雨でも移動できる。新幹線は隣の新大阪から。','梅田.jpg','Zairon／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AOsaka_Umeda_Sky_Building_Panoramablick_05.jpg'],
  ['なんば',34.6659,135.5013,'29090','道頓堀・心斎橋へ歩ける大阪の南の中心。高島屋・なんばパークス・なんばCITY、法善寺横丁の飲食、黒門市場。粉ものから寿司までの飲食店が集まる。関西空港へは南海で一本。','なんば.jpg','Kirakirameister／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3ANamba_Station.JPG'],
  ['天王寺',34.6467,135.5134,'26062','あべのハルカスとキューズモール、天王寺公園と動物園。JR・地下鉄・近鉄が集まり、奈良・和歌山方面へも出やすい。新世界の通天閣まで歩けて、串カツの店が並ぶ。','天王寺.jpg','inunami／CC BY 2.0','https://commons.wikimedia.org/wiki/File%3ATennoji_Station_20221209140008.jpg'],
  ['京橋',34.6967,135.5342,'25901','大阪城公園の隣で、JR環状線・京阪・地下鉄長堀鶴見緑地線の乗換駅。駅周辺は庶民的な飲食店街と京阪モール。大阪ビジネスパークの高層ビル群が近く、城の緑と都会が同居する。','京橋.jpg','Tokumeigakarinoaoshima／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJR_Kyobashi_Station.jpg'],
  ['三宮',34.6948,135.1955,'29086','神戸の中心。センター街の商店街、元町の中華街（南京町）、旧居留地のブランド店とカフェ。北に六甲山、南に海と、山も海も歩ける距離にある。大阪・梅田へはJR新快速で20分台。','三宮.jpg','Mont Blank rich／CC0','https://commons.wikimedia.org/wiki/File%3AJR_%E4%B8%89%E3%83%8E%E5%AE%AE%E9%A7%85.jpg'],
  ['京都',34.9858,135.7588,'25647','駅ビルにジェイアール京都伊勢丹とヨドバシ、駅前にイオンモール。清水寺・伏見稲荷・嵐山などの観光地へはバスと電車で。京都タワーが目印で、東寺まで歩ける。新幹線で東京・博多へも一本。','京都.jpg','MaedaAkihiko／CC0','https://commons.wikimedia.org/wiki/File%3AKyoto-STA_Central.jpg'],
  ['河原町',35.0038,135.7686,'25635','四条河原町。高島屋・大丸のある京都いちばんの繁華街で、先斗町・木屋町の飲食街が鴨川沿いに続く。錦市場、祇園、八坂神社へ歩いて行ける。夜は鴨川べりで川床や散歩。','河原町.jpg','Hide1228／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AShijo_dori_sign.JPG'],
  ['名古屋',35.1709,136.8815,'25077','駅前にJRゲートタワー・高島屋・名鉄・近鉄の百貨店、地下街のエスカとユニモール。きしめん・味噌カツなど名古屋めしの店が集まる。新幹線で東京へ1時間半、大阪へ50分。','名古屋.jpg','Tomio344456／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AView_of_Nagoya_Station%2C_Tsubaki-cho_Nakamura_Ward_Nagoya_2022.jpg'],
  ['栄',35.1710,136.9085,'24945','名古屋の繁華街。松坂屋・三越・パルコに、久屋大通公園と名古屋テレビ塔。オアシス21のガラス屋根の広場が待ち合わせの定番。飲食店とライブハウスが多く、夜も賑わう。','栄.jpg','Akahito Yamabe／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ANagoya_city_88.jpg'],
  ['博多',33.5902,130.4207,'28283','駅ビルのアミュプラザ博多と阪急、地下街。ラーメン・もつ鍋・水炊きの店が駅周辺に集まる。新幹線の起点で、空港へは地下鉄で5分という近さ。中洲の屋台街まで歩ける。','博多.jpg','ぱちょぴ／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AJR_Hakata_City_2011_Jan.jpg'],
  ['天神',33.5914,130.3989,'28236','福岡いちばんの繁華街。岩田屋・三越・大丸の百貨店、パルコ・ソラリアのファッションビル、地下街。夜は屋台が並び、中洲へも歩ける。天神ビッグバンの再開発で新しいビルが増えている。','天神.jpg','JKT-c／CC BY 3.0','https://commons.wikimedia.org/wiki/File%3AFukuoka_City_-_Watanabe-dori_Avenue_-_01.JPG'],
  ['札幌',43.0687,141.3508,'20220','駅直結のステラプレイス・大丸と地下街。大通公園・すすきのまで地下歩行空間で雨や雪でも歩ける。時計台、テレビ塔、冬は雪まつり。新千歳空港へは快速で40分。','札幌.jpg','663highland／CC BY 2.5','https://commons.wikimedia.org/wiki/File%3AJR_Sapporo_Sta03n3200.jpg'],
  ['仙台',38.2601,140.8822,'21044','東北最大の街。駅前のエスパル・パルコ・ロフト、一番町のアーケード商店街が長く続く。牛タンや笹かまの店、定禅寺通のケヤキ並木。新幹線で東京へ1時間半。','仙台.jpg','掬茶／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ASendai_Station_20230806.jpg'],
  ['広島',34.3978,132.4753,'27365','新しい駅ビル（ミナモア）ができ、路面電車が駅ビルの2階まで乗り入れる。八丁堀・本通の繁華街へは路面電車で10分。平和記念公園、原爆ドーム、宮島へも路面電車と船で。お好み焼きの店が街のあちこちにある。','広島.jpg','Wikiyasu／CC0','https://commons.wikimedia.org/wiki/File%3A%E5%BA%83%E5%B3%B6%E9%A7%85%E9%A7%85%E8%88%8E.jpg'],
  ['静岡',34.9719,138.3885,'23545','駅前に伊勢丹・パルコ・松坂屋、呉服町の商店街が長く続く。駿府城公園と静岡浅間神社が街の中心にあり、少し行けば日本平と久能山。新幹線で東京へ1時間。','静岡.jpg','江戸村のとくぞう／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AShizuoka_Station_201016a.jpg'],
  ['岡山',34.6663,133.9180,'27051','駅前にイオンモール岡山と高島屋、表町の商店街。後楽園と岡山城まで路面電車で10分。瀬戸大橋で四国へ、新幹線で大阪へ45分。','岡山.jpg','ほっきー／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3A%E5%B2%A1%E5%B1%B1%E9%A7%85_%E6%9D%B1%E5%8F%A3_2022.jpg'],
  ['鹿児島中央',31.5838,130.5418,'29007','駅ビルのアミュプラザと観覧車、天文館の繁華街へは路面電車で10分。桜島を眺めながらのフェリーや温泉、黒豚・さつま揚げの店。新幹線で博多へ1時間半。','鹿児島中央.jpg','Tokyo-Good／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AKagoshima-Chuo-Station-building20201004.jpg'],
  ['高崎',36.3229,139.0129,'21913','北関東の交通の要で、新幹線・在来線が集まる。駅ビルのモントレー、高島屋、駅西口の飲食店街。パスタの街として知られ、少し行けば榛名山・伊香保温泉。','高崎.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE-Takasaki-STA_West.jpg'],
  ['宇都宮',36.5592,139.8985,'21736','駅東口の再開発でLRT（路面電車）が走り、新しい広場ができた。餃子の店が駅周辺と東口に集まり、オリオン通りの商店街と二荒山神社が街の中心。新幹線で東京へ50分。','宇都宮.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AUtsunomiya-STA_West.jpg'],
  ['水戸',36.3706,140.4762,'21710','県都で、駅ビルのエクセルとエクセルみなみ、駅南口の飲食店街。偕楽園の梅、千波湖の散歩道。国道50号沿いに大型店が並ぶ車の街でもある。','水戸.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJRE_Mito-STA_North.jpg'],
  ['松山',33.8395,132.7657,'27845','四国最大の街。松山市駅の高島屋（屋上に観覧車）と、大街道・銀天街のアーケード商店街。道後温泉へ路面電車で20分、松山城は街の真ん中。','松山.jpg','CT-May／CC0','https://commons.wikimedia.org/wiki/File%3AIyotetsu_Takashimaya_20260517.jpg'],
  ['高松',34.3507,134.0467,'27724','四国の玄関口。駅前のサンポート高松、丸亀町・南新町のアーケード商店街が長く続く。讃岐うどんの店は市内のあちこちに。栗林公園まで電車で数分。','高松.jpg','Shogo1999／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATakamatsu_Station_%28Kagawa%29_20240327.jpg'],
  ['熊本',32.7899,130.6893,'28627','駅ビルのアミュプラザくまもと。繁華街は市電で10分ほどの通町筋・下通・上通のアーケードで、熊本城がすぐ隣。馬刺し・辛子蓮根の店が集まる。','熊本.jpg','Jdjuice／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AKumamoto-station-032021.jpg'],
  ['金沢',36.578,136.648,'23740','駅の鼓門が目印。駅ビルの金沢百番街、香林坊・片町の百貨店と繁華街へバスで10分。近江町市場、兼六園、ひがし茶屋街と歩ける観光地が多い。','金沢.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AKanazawa-STA_Kenrokuen-entrance.jpg'],
  ['新潟',37.9122,139.0619,'24033','駅の南口に大型店、万代シテイ（バスセンター・ラブラ・ビルボードプレイス）と古町の商店街へバスで。信濃川沿いの散歩道と、日本海の海産物。','新潟.jpg','ShutetsuTrain／CC BY 4.0','https://commons.wikimedia.org/wiki/File%3A%E6%96%B0%E6%BD%9F%E9%A7%85_%EF%BC%882026%E5%B9%B4_8%E6%9C%887%E6%97%A5%EF%BC%89.jpg'],
  ['長野',36.6431,138.1887,'24282','駅ビルのMIDORI、善光寺へ続く中央通りの商店街。駅から善光寺まで歩いて30分。新幹線で東京へ1時間半。冬はスキー場が近い。','長野.jpg','快速踊り子／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ANagano_Station_2023-05-27.jpg'],
  ['岐阜',35.41,136.7566,'24429','駅前のアクティブG、柳ケ瀬の商店街へ歩いて15分ほど。長良川の鵜飼と岐阜城。名古屋へJRで20分と近く、買い物は名古屋という人も多い。','岐阜.jpg','Saigen Jiro／CC0','https://commons.wikimedia.org/wiki/File%3AGifu_Station%2C_ekisha.jpg'],
  ['奈良',34.6832,135.818,'26669','近鉄奈良駅の周りに東向・もちいどのの商店街。奈良公園と東大寺・興福寺は歩いてすぐ。大阪（難波）へ近鉄で40分弱。','奈良.jpg','Mont Blank rich／CC0','https://commons.wikimedia.org/wiki/File%3A%E8%BF%91%E9%89%84%E5%A5%88%E8%89%AF%E9%A7%85%EF%BC%882024%E5%B9%B4%EF%BC%89.jpg'],
  ['和歌山',34.2325,135.1868,'26839','駅前に近鉄百貨店、ぶらくり丁の商店街。和歌山城が街の中心で、加太・和歌浦の海が近い。大阪（天王寺）へJRで1時間ほど。','和歌山.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AWakayama-STA_Central-entrance_MIO.jpg'],
  ['姫路',34.8268,134.69,'26524','駅前から姫路城へまっすぐ大通りが伸びる。駅ビルのピオレ、みゆき通りの商店街。神戸へ新快速で40分、大阪へ1時間。','姫路.jpg','KishujiRapid／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJR_Himeji_Station_20200312.jpg'],
  ['小倉',33.8865,130.8823,'28155','北九州の中心。駅ビルのアミュプラザ、魚町銀天街・旦過市場、小倉城とリバーウォーク。新幹線で博多へ15分。','小倉.jpg','NEOTOKYO INFINITY／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AKokura_Station_2025.jpeg'],
  ['長崎',32.7524,129.8717,'28534','駅ビルのアミュプラザ長崎、浜町のアーケード商店街へ路面電車で。中華街、グラバー園、稲佐山の夜景。坂の多い港町。','長崎.jpg','Houjyou-Minori／CC0','https://commons.wikimedia.org/wiki/File%3ANagasaki_Station_20200407_03.jpg'],
  ['大分',33.2337,131.6062,'28742','駅ビルのアミュプラザおおいた（屋上に庭園と観覧車）、府内五番街の商店街。別府温泉へ電車で15分。','大分.jpg','大分帰省中／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AOita_sta_funai_2015.JPG'],
  ['那覇',26.2137,127.6923,'29464','国際通りの土産物店と飲食店、牧志公設市場。ゆいレールで空港へ15分。首里城、波の上ビーチ。車社会だが那覇市内はモノレールと徒歩で動ける。','那覇.jpg','663highland／CC BY 2.5','https://commons.wikimedia.org/wiki/File%3AKokusai-dori08s3s4440.jpg'],
  ['郡山',37.398,140.3873,'21483','福島県の商業の中心。駅前にビッグアイ（展望台）と商店街、新幹線で東京へ1時間20分。猪苗代湖と磐梯山が近い。','郡山.jpg','663highland／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3A260801_Koriyama_Station_Koriyama_Fukushima_pref_Japan02s3.jpg'],
  ['盛岡',39.7013,141.1366,'20940','駅前の商業ビルと、中津川沿いの城下町の街並み。大通・菜園の飲食店、わんこそば・冷麺・じゃじゃ麺の店。新幹線で東京へ2時間強。','盛岡.jpg','MaedaAkihiko／CC0','https://commons.wikimedia.org/wiki/File%3AMorioka-STA_South.jpg'],
  ['秋田',39.7167,140.1329,'21137','駅ビルのトピコとアルス、広小路の商店街。千秋公園（久保田城跡）が駅のすぐ横。竿燈まつりと、きりたんぽ。','秋田.jpg','掬茶／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AAkita_Station_west_exit_20200823c.jpg'],
  ['山形',38.2483,140.3268,'21392','駅前の霞城セントラル（展望ロビー）、七日町の商店街。霞城公園と蔵王温泉。さくらんぼ・芋煮の街。','山形.jpg','Mister0124／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJR_East_Yamagata_Station_East_Exit%2C_Yamagata_Pref.jpg'],
  ['青森',40.8288,140.7355,'20619','駅前のA-FACTORY、ねぶたの家ワ・ラッセ、青森魚菜センターののっけ丼。新幹線は新青森から。八甲田山と浅虫温泉が近い。','青森.jpg','Tachiwaki.john.River／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AAomori_Station_Higashiguchi.jpg'],
  ['福島',37.7543,140.459,'21551','駅前の商店街とパセオ通り。飯坂温泉へ電車で20分、花見山と桃の産地。新幹線で東京へ1時間半。','福島.jpg','D-s-yama／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AFukushima-station_west.jpg'],
  ['前橋',36.383,139.0733,'21946','群馬の県庁所在地。駅から少し離れた中心街に商店街と、再開発でできた白井屋ホテル周辺の新しい店。赤城山が近い。','前橋.jpg','MaedaAkihiko／CC0','https://commons.wikimedia.org/wiki/File%3AJRE_Maebashi-STA_Platforms_03.jpg'],
  ['甲府',35.6669,138.5691,'23408','駅前に岡島百貨店跡の再開発と商店街、舞鶴城公園（甲府城跡）。ほうとうの店、ワイナリーへも近い。新宿へ特急で1時間半。','甲府.jpg','江戸村のとくぞう／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AK%C5%8Dfu_Station_201904a.jpg'],
  ['松本',36.2306,137.9647,'24325','国宝松本城まで駅から歩いて15分。縄手通り・中町通りの街並み、駅前のパルコ跡の再開発。上高地・美ヶ原の入口。','松本.jpg','柑橘類／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AMatsumoto_Castle_1-1.jpg'],
  ['浜松',34.7038,137.7345,'23604','駅ビルのメイワン、駅前の商業ビル群と繁華街。浜名湖と鰻、楽器の街。新幹線で東京・名古屋の両方へ。','浜松.jpg','純一末永／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AJR%E6%B5%9C%E6%9D%BE%E9%A7%85%E5%8C%97%E5%8F%A3.jpg'],
  ['豊橋',34.7627,137.3818,'25063','駅ビルのカルミア、路面電車で行く繁華街。駅前の大通りに商業施設。名古屋へJR快速で50分。','豊橋.jpg','Mister0124／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AToyohashi_Station_East_Exit.jpg'],
  ['四日市',34.9667,136.6244,'25342','近鉄四日市駅前に近鉄百貨店とアーケード商店街。名古屋へ近鉄で30分。コンビナートの夜景で知られる。','四日市.jpg','z tanuki／CC BY 3.0','https://commons.wikimedia.org/wiki/File%3AKintesu_yokkaichi_%2C_%E8%BF%91%E9%89%84_%E5%9B%9B%E6%97%A5%E5%B8%82_-_panoramio.jpg'],
  ['津',34.7328,136.5088,'25392','県庁所在地。駅前に商業ビル、津城跡と偕楽公園。名古屋へ近鉄で1時間弱。','津.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATsu-STA_East.jpg'],
  ['富山',36.7013,137.2133,'24721','駅と路面電車が一体になった新しい駅。駅前のマリエとまちなかの総曲輪、富山城。立山連峰の眺め、ますの寿司と白えび。','富山.jpg','Araisyohei／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AToyama_station_2019-08-12%281%29_sa.jpg'],
  ['福井',36.0622,136.2236,'23855','新幹線で東京へ3時間。駅前に再開発でできたハピリンと商業施設、恐竜のモニュメント。東尋坊と越前海岸へ。','福井.jpg','Jjp 233／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AHappiring.JPG'],
  ['鳥取',35.4938,134.2226,'26880','駅前のシャミネと商店街。鳥取砂丘へバスで20分、市内に温泉が湧く。','鳥取.jpg','Asturio Cantabrio／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATottori_Station_south_side_ac.jpg'],
  ['松江',35.4738,133.0632,'27021','宍道湖のほとり。駅前の一畑百貨店跡と商店街、松江城と武家屋敷の町並み。出雲大社へ一畑電車で。','松江.jpg','Rsa／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AMatsue_Station-North-20110730.jpg'],
  ['新山口',34.0937,131.3937,'27468','新幹線の駅。山口市の中心（湯田温泉・山口駅周辺）へバスで20分。周辺は住宅地。','新山口.jpg','EXECUTOR／CC0','https://commons.wikimedia.org/wiki/File%3AShin-Yamaguchi_Station_2.jpg'],
  ['徳島',34.0745,134.5513,'27648','駅前のアミコ・そごう跡の商業施設、眉山のロープウェイ。阿波おどりの街。神戸へ高速バスで2時間。','徳島.jpg','Rebirth10／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3ATokushima_JR_Sta_2020%2C9.jpg'],
  ['高知',33.5667,133.5433,'27969','はりまや橋、帯屋町のアーケード商店街、ひろめ市場の飲食。高知城と日曜市。路面電車で市内を動ける。','高知.jpg','MaedaAkihiko／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3AKochi-STA.jpg'],
  ['佐賀',33.2641,130.2973,'28389','駅前の商業ビルと、佐賀城本丸歴史館。福岡（博多）へ特急で40分と近い。','佐賀.jpg','SuFlyer／CC0','https://commons.wikimedia.org/wiki/File%3ASaga_Station_North_Gate_2021-10.jpg'],
  ['宮崎',31.9155,131.4296,'28903','駅前のアミュプラザみやざき、橘通りの繁華街。青島・日南海岸のドライブ、チキン南蛮とマンゴー。','宮崎.jpg','Peachkk／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3A%E5%AE%AE%E5%B4%8E%E9%A7%85%E5%89%8D.jpg'],
  ['沼津',35.102,138.8612,'23600','駅前の商業ビルと仲見世商店街、沼津港の魚市場と飲食店。富士山と駿河湾の眺め。東京へ新幹線（三島から）で1時間。','沼津.jpg','MaedaAkihiko／CC0','https://commons.wikimedia.org/wiki/File%3AJRC_Numazu_STA_South.jpg'],
  ['八王子',35.6558,139.3389,'22905','多摩地区西の中心。駅ビルのセレオ、東急スクエア、放射線通りの商店街。高尾山へ電車で20分。新宿へJRで40分。','八王子.jpg','103momo／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AHachioji_Station_North_2014.jpg'],
  ['大船',35.3541,139.5308,'23096','鎌倉と横浜の間。駅前のルミネウィング、大船仲通りの商店街と市場。鎌倉へ5分、横浜へ20分。','大船.jpg','Kouchiumi／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AOfunaStkasamaguchi.jpg'],
  ['海老名',35.4528,139.3912,'23088','駅前にららぽーと海老名、ビナウォーク。小田急・相鉄・JRの3路線で、新宿・横浜へ一本。','海老名.jpg','ja:利用者:Machiro／CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File%3AEbina_Station.jpg'],
  ['つくば',36.0826,140.1117,'29410','つくばエクスプレスで秋葉原へ45分。駅前のトナリエ（旧クレオ）とイーアスつくば、研究学園都市らしい広い道と公園。','つくば.jpg','Miyuki Meinaka／CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File%3ATX_Tsukuba_station_exits.jpg']
 ];
 function nearHubs(f,n){ return HUBS.map(function(h){ return {n:h[0],lat:h[1],lng:h[2],code:h[3],desc:h[4],img:h[5],credit:h[6],csrc:h[7],dist:km({lat:f.la,lng:f.lo},{lat:h[1],lng:h[2]})}; }).filter(function(h){ return h.dist<=60; }).sort(function(a,b){ return a.dist-b.dist; }).slice(0,n||2); }
 // 近い順に3つ当たって、90分以内で行ける街を2つまで。90分以内が無ければ、いちばん近い1つだけ（遠いことは分数で分かる）
 async function hubAccess(f){
  var hs=nearHubs(f,3); var out=[];
  for(var i=0;i<hs.length;i++){ var h=hs[i];
   try{ h.t=await courseBetween({lat:f.la,lng:f.lo},h.code,'1000'); }
   catch(e){ h.t=null; try{ var st=await nearestStop(f); var t=await courseBetween({code:st.code},h.code,'1000'); t.legs.unshift({kind:'walk',line:'徒歩',from:'',to:st.name,mins:st.walk}); t.mins+=st.walk; t.walk+=st.walk; h.t=t; }catch(e2){} }
   out.push(h); }
  var ok=out.filter(function(h){ return h.t&&h.t.mins<=90; }).sort(function(a,b){ return a.t.mins-b.t.mins; }).slice(0,2);
  if(ok.length) return ok;
  var withT=out.filter(function(h){ return h.t; }).sort(function(a,b){ return a.t.mins-b.t.mins; });
  return withT.length?[withT[0]]:out.slice(0,1);
 }
 function renderList(o,items,pending){
  list.innerHTML='';
  items.forEach(function(f,i){
   var li=document.createElement('li');
   var jobs=Object.keys(f.j||{}).map(function(k){ return k+' '+f.j[k]; }).join('・');
   var timeText=pending?'計算中…':timeLabel(f.time);
   li.innerHTML='<span class="km">'+(f.time?f.time.mins+'分':f.dist.toFixed(1)+'km')+'</span><span class="nm">'+(i+1)+'. '+esc(f.n)+'</span>'+(f.rich?'<span class="richTag">求人票あり</span>':'')+'<br><span class="sub">'+esc(f.d||f.t)+(f.c?'／'+esc(f.c):'')+(f.k?'／'+esc(f.k):'')+'</span><br><span class="jobs">Open：'+esc(jobs)+'</span><br><span class="tm'+(f.time?' got':'')+'">'+esc(timeText)+'</span>';
   li.title=f.a; list.appendChild(li);
  });
 }
 async function run(){
  var q=inp.value.trim(); if(!q) return; msg.textContent='探しています…'; list.innerHTML='';
  try{
   var data=await loadData(); fillJobSelect(data); var o=await geocode(q);
   var pool=data.map(function(f){ return Object.assign({dist:km({lat:o.lat,lng:o.lng},{lat:f.la,lng:f.lo})},f); }).filter(function(f){ return f.dist<=40; }).sort(function(x,y){ return x.dist-y.dist; }).slice(0,25);
   if(!pool.length){ msg.textContent='起点：'+o.title+'　40km以内にOpen求人のある施設がありません'; return; }
   if(!EK){
    msg.textContent='起点：'+o.title+'　近い順 '+pool.length+'件（40km以内・鍵なしのため距離順）';
    renderList(o,pool.slice(0,15),false); drawMap(o,pool.slice(0,15)); lastOrigin=o; lastRanked=pool.slice(0,15); updateMkBtn(); return;
   }
   msg.textContent='起点：'+o.title+'　ドアドアの時間を計算中…（'+pool.length+'件）';
   renderList(o,pool.slice(0,15),true);
   var capHit=null;
   await mapLimited(pool,3,async function(f){ if(capHit) return; try{ f.time=await doorToDoor(o,f); }catch(e){ f.time=null; if(String(e.message).indexOf('上限')>=0) capHit=e.message; } });
   if(capHit){ msg.textContent=capHit+'。近い順（距離）で出します'; }
   var withTime=pool.filter(function(f){ return f.time; }).sort(function(x,y){ return x.time.mins-y.time.mins; });
   var withoutTime=pool.filter(function(f){ return !f.time; });
   var ranked=withTime.concat(withoutTime).slice(0,15);
   if(!capHit) msg.textContent='起点：'+o.title+'　ドアドアの時間が近い順 '+ranked.length+'件（40km以内の候補'+pool.length+'件から・平日8時発の目安。駅すぱあと 本日'+ekUsed()+'/'+EK_DAILY_CAP+'回）';
   renderList(o,ranked,false); drawMap(o,ranked); lastOrigin=o; lastRanked=ranked; updateMkBtn();
  }catch(e){ msg.textContent=e.message||String(e); }
 }
 
 // ===== この人向けページ（求職者向け・おすすめ求人）。合言葉なし・長いURLだけで開けるページを作る =====
 var mkBtn=document.getElementById('mkPageBtn'), mkMsg=document.getElementById('mkPageMsg');
 var lastOrigin=null, lastRanked=null;
 // この人の職種：欄（nearJob）で選ぶ。初期値は見出しの「看護師・一回目」の職種。施設データにある職種を選択肢にする
 var JOB_ORDER=['看護師','准看護師','介護職','保育士','ケアマネジャー','生活相談員','理学療法士','作業療法士','言語聴覚士','薬剤師','管理栄養士','栄養士','調理師','事務','送迎ドライバー','その他'];
 function fillJobSelect(data){
  var sel=document.getElementById('nearJob'); if(!sel||sel.options.length) return;
  var cnt={}; data.forEach(function(f){ Object.keys(f.j||{}).forEach(function(k){ cnt[k]=(cnt[k]||0)+f.j[k]; }); });
  var keys=Object.keys(cnt).sort(function(a,b){ var ia=JOB_ORDER.indexOf(a), ib=JOB_ORDER.indexOf(b); if(ia<0) ia=99; if(ib<0) ib=99; return ia-ib||cnt[b]-cnt[a]; });
  var head=''; try{ var t=document.querySelector('.top h1 small'); if(t) head=(t.textContent||'').split(/[・･]/)[0].trim(); }catch(e){}
  keys.forEach(function(k){ var o=document.createElement('option'); o.value=k; o.textContent=k+'（求人 '+cnt[k]+'）'; if(k===head) o.selected=true; sel.appendChild(o); });
 }
 function candidateProfile(){
  var prof=''; try{ var sel=document.getElementById('nearJob'); if(sel&&sel.value) prof=sel.value; }catch(e){}
  if(!prof){ try{ var t=document.querySelector('.top h1 small'); if(t) prof=(t.textContent||'').split(/[・･]/)[0].trim(); }catch(e){} }
  var st=(window.store)||{};
  return {job:prof, koyou:st.koyou||'', keiken:st.keiken||''};
 }
 function scoreOne(cand,f){
  var reasons=[]; var score=0;
  if(cand.job && f.j && f.j[cand.job]){ score+=45; reasons.push('希望の「'+cand.job+'」の求人があります（'+f.j[cand.job]+'件）'); }
  if(f.time){
   var m=f.time.mins;
   if(m<=30){ score+=35; } else if(m<=45){ score+=22; } else if(m<=60){ score+=10; }
   reasons.push('自宅から約'+m+'分'+(f.time.est?'（徒歩の目安）':'・乗り換え'+f.time.transfers+'回'+(f.time.bus?'（バス利用）':'')));
  } else { score+=5; }
  if(cand.keiken){
   var toks=cand.keiken.split(/[\s（）()・、,]+/).filter(function(t){ return t.length>=2; });
   var hay=(f.d||'')+(f.t||''); var hit=toks.some(function(t){ return hay.indexOf(t)>=0; });
   if(hit){ score+=20; reasons.push('ご経験に近い施設形態（'+(f.d||f.t)+'）'); }
  }
  var jdJ=(f.jd&&cand.job)?f.jd[cand.job]:null;
  if(jdJ&&jdJ.rich){ score+=15; } else if(f.rich){ score+=8; }
  if(jdJ&&jdJ.f){ var nl=nightLines(jdJ.f).join(' '); if(/日勤のみ|夜勤なし|夜勤無し/.test(nl)) reasons.push('求人票に「日勤のみ」の記載があります'); }
  if(f.area&&f.area.p&&f.area.p.st&&f.area.p.st[0]&&f.area.p.st[0].d<=0.6) reasons.push(f.area.p.st[0].n+'駅から徒歩'+walkMin(f.area.p.st[0].d)+'分');
  return {score:Math.min(100,score),reasons:reasons};
 }


 function hashStr(s){ var h=0; s=String(s||''); for(var i=0;i<s.length;i++){ h=(h*31+s.charCodeAt(i))>>>0; } return h; }
 function searchLink(name,addr){ return 'https://www.google.com/search?q='+encodeURIComponent(name+' '+(addr||'')); }
 var HERO_IMG={'医療':'hero_iryo.jpg','施設入居':'hero_shisetsu.jpg','通所':'hero_tsusho.jpg','在宅・訪問':'hero_homon.jpg','保育・児童':'hero_hoiku.jpg'};
 function heroImg(t){ return '../../../assets/'+(HERO_IMG[t]||'hero_other.jpg'); }
 // 施設そのものの写真（CAが撮った／法人からもらった）。gl-recommend の assets/f/<施設ID>/ に置き、manifest.json に載せる
 var PHOTO_BASE='https://akasa0521-spec.github.io/gl-recommend/assets/f/';
 async function loadPhotoManifest(){ try{ var r=await fetch(PHOTO_BASE+'manifest.json',{cache:'no-store'}); if(!r.ok) return {}; return await r.json(); }catch(e){ return {}; } }
 function facPhoto(f,name){ return '../../../assets/f/'+encodeURIComponent(f.i)+'/'+encodeURIComponent(name); }
 function photoGallery(f){
  var ps=(Array.isArray(f.photos)?f.photos:[]).slice(1,5); if(!ps.length) return '';
  return '<div class="block"><h2>施設の写真</h2><div class="gal">'+ps.map(function(n){ return '<img src="'+facPhoto(f,n)+'" alt="" loading="lazy">'; }).join('')+'</div></div>';
 }
 function mapLink(addr){ return 'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(addr); }
 function esc2(s){ return esc(s); }
 function nl2br(s){ return esc2(s).replace(/\n/g,'<br>'); }
 // ===== 紺×ゴールド。実在の求人サイトに近いトーン。装飾のグラデーションと絵文字はやめる =====

 var FIELD_ORDER=['kyuyo','teate','jikan','kyujitsu','naiyo','shikaku','taigu','shiyo','other'];
 function cleanLine(t){ return String(t||'').replace(/^[・◆■●◎○★☆✅＊*]\s*/,'').replace(/^(給与|賃金|報酬)\s*[:：]\s*/,''); }
 function renderLines(lines,max){
  lines=(lines||[]).filter(function(ln,i,a){ if(!/^【.+】$/.test(String(ln))) return true; var nx=a[i+1]; return nx!==undefined && !/^【.+】$/.test(String(nx)); });
  var items=(lines||[]).map(function(ln){
   var cls='',t=String(ln);
   if(/^【.+】$/.test(t)){ cls='sub'; t=t.replace(/^【|】$/g,''); }
   else if(/^※/.test(t)){ cls='note'; }
   else if(/^[・◆■●◎○★☆✅＊*]/.test(t)){ t=t.replace(/^[・◆■●◎○★☆✅＊*]\s*/,''); }
   else { cls='plain'; }
   return '<li class="'+cls+'">'+esc2(t)+'</li>';
  });
  if(max&&items.length>max){
   return '<ul class="ln">'+items.slice(0,max).join('')+'</ul><details class="more"><summary>すべて見る（あと'+(items.length-max)+'件）</summary><ul class="ln">'+items.slice(max).join('')+'</ul></details>';
  }
  return '<ul class="ln">'+items.join('')+'</ul>';
 }
 function payClass(t){ // 行の種類：月／時／年／不明。語が無ければ金額の大きさで決める
  if(/月給|月額|月収/.test(t)) return 'm'; if(/時給/.test(t)) return 'h'; if(/日給/.test(t)) return 'd'; if(/年俸|年収/.test(t)) return 'y';
  var m=t.replace(/,/g,'').match(/(\d+)\s*万?\s*円/); if(!m) return '';
  var v=Number(m[1]); if(/万\s*円/.test(t)) v*=10000;
  if(v>=1000000) return 'y'; if(v>=100000) return 'm'; if(v>=5000) return 'd'; if(v>=700) return 'h'; return '';
 }
 var PAY_LABEL={m:'月給',h:'時給',d:'日給',y:'年俸'};
 function pickPay(k){ // 見出しにする給与の行：月 → 時 → 日 → 年 → 先頭。語が無い行には「月給」などを補う
  k=(k||[]).map(cleanLine).filter(Boolean); if(!k.length) return {line:'',rest:[]};
  var pref=['m','h','d','y'];
  for(var i=0;i<pref.length;i++){ for(var j=0;j<k.length;j++){ if(payClass(k[j])===pref[i]&&/\d/.test(k[j])){ var line=k[j]; if(!/月給|月額|月収|時給|日給|年俸|年収/.test(line)) line=PAY_LABEL[pref[i]]+' '+line; return {line:line,rest:k.slice(0,j).concat(k.slice(j+1))}; } } }
  return {line:k[0],rest:k.slice(1)};
 }
 function payHeadline(f){ return pickPay(f&&f.kyuyo).line; }
 // 夜勤・日勤の手がかり：求人票の全項目から「夜勤／当直／日勤のみ／オンコール」を含む行を集める
 function nightLines(f){
  var out=[]; FIELD_ORDER.forEach(function(k){ (f[k]||[]).forEach(function(ln){ var t=cleanLine(ln); if(/夜勤|当直|日勤のみ|日勤帯|オンコール|準夜|深夜/.test(t)&&out.indexOf(t)<0) out.push(t); }); });
  return out.slice(0,5);
 }
 function firstRichJob(fac,job){
  var jd=fac.jd||{};
  if(job&&jd[job]&&jd[job].rich) return {name:job,d:jd[job]};
  var ks=Object.keys(jd); for(var i=0;i<ks.length;i++){ if(jd[ks[i]].rich) return {name:ks[i],d:jd[ks[i]]}; }
  return ks.length?{name:ks[0],d:jd[ks[0]]}:null;
 }
 var SITE_BASE='https://akasa0521-spec.github.io/gl-recommend/';
 function ogTags(title,desc,img){ return '<meta property="og:title" content="'+esc2(title)+'"><meta property="og:description" content="'+esc2(desc)+'"><meta property="og:image" content="'+esc2(img)+'"><meta property="og:type" content="website"><meta name="twitter:card" content="summary_large_image">'; }
 var FONT_LINK='<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Zen+Kaku+Gothic+New:wght@700;900&family=Noto+Sans+JP:wght@400;700&display=swap" rel="stylesheet">';
 var SEEKER_CSS = '*{box-sizing:border-box}'+
  ':root{--navy:#0E2F3F;--navy2:#123B4F;--gold:#C79A3E;--paper:#F6F4EF;--ink:#1B2430;--sub:#5B6570;--line:#E3DFD4;--card:#fff}'+
  'html{-webkit-text-size-adjust:100%}'+
  'body{margin:0;background:var(--paper);font-family:"Noto Sans JP",-apple-system,"Hiragino Sans",sans-serif;color:var(--ink);line-height:1.7}'+
  '.wrap{max-width:640px;margin:0 auto;padding:0 0 64px}'+
  'a{color:inherit;text-decoration:none}'+
  '.eyebrow{font-size:11px;letter-spacing:.12em;color:var(--gold);font-weight:700;font-family:"Zen Kaku Gothic New",sans-serif}'+
  '.heroimg{display:block;width:100%;height:200px;object-fit:cover;background:var(--navy)}'+
  '.herotext{background:var(--navy);padding:18px 22px 22px;color:#fff}'+
  '.herotext h1{font-family:"Zen Kaku Gothic New",sans-serif;font-size:24px;line-height:1.35;margin:6px 0 4px;font-weight:700}'+
  '.herotext .sub{font-size:12.5px;color:rgba(255,255,255,.72)}'+
  '.herotext .chips{margin-top:12px;display:flex;flex-wrap:wrap;gap:6px}'+
  '.herotext .chip{font-size:11.5px;border:1px solid rgba(255,255,255,.45);border-radius:999px;padding:3px 10px;color:#fff}'+
  'footer{text-align:center;color:#B9B2A2;font-size:11px;margin-top:30px;letter-spacing:.06em}'+
  '@media print{.herotext,.cta,.cnt,.rs.line i{color:var(--navy)!important;background:none!important}.herotext .sub{color:var(--sub)}.herotext .chip{border-color:var(--navy);color:var(--navy)}.stat,.job,.hub,.addr,.cta,.aer{break-inside:avoid}.more summary{display:none}}';
 function buildIndexPage(cand,list){
  var rows=list.map(function(x,i){
   var f=x.f; var slug='c'+(i+1); var rj=firstRichJob(f,cand.job); var pay=rj?payHeadline(rj.d.f):'';
   var koyou=rj&&rj.d.koyou?rj.d.koyou:'';
   return '<a class="row" href="./'+slug+'/">'+
    '<div class="rb"><div class="rn">'+esc2(f.n)+'</div>'+
    '<div class="rj">'+esc2(Object.keys(f.j||{}).join(' / '))+(koyou?'　<span class="rk">'+esc2(koyou)+'</span>':'')+'</div>'+
    (pay?'<div class="rp">'+esc2(pay)+'</div>':'')+
    (f.time?'<div class="rl">'+(f.time.est?'徒歩の目安（直線距離から）':esc2(routeShort(f.time)))+'</div>':'')+
    (areaLine(f)?'<div class="ra">'+esc2(areaLine(f))+'</div>':'')+
    '</div>'+
    (f.time?'<div class="rt"><b>'+f.time.mins+'</b><span>分</span>'+(f.time.est?'':'<i>乗換'+f.time.transfers+'</i>')+'</div>':'')+
    '<div class="rg">›</div></a>';
  }).join('');
  var css=SEEKER_CSS+
   '.hero .herotext p{font-size:13px;line-height:1.8;color:rgba(255,255,255,.75);margin:4px 0 0;max-width:46ch}'+
   '.list{padding:6px 18px 0}'+
   '.row{display:flex;align-items:center;gap:12px;padding:16px 4px;border-bottom:1px solid var(--line)}'+
   '.rb{flex:1;min-width:0}.rn{font-family:"Zen Kaku Gothic New",sans-serif;font-weight:700;font-size:15.5px;line-height:1.4}'+
   '.rj{font-size:12px;color:var(--sub);margin-top:2px}.rk{font-size:11px;color:var(--navy);background:#EAF0F4;border-radius:3px;padding:1px 6px}'+
   '.rp{font-size:13px;color:var(--navy);font-weight:700;margin-top:4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'+
   '.rl{font-size:11px;color:var(--sub);margin-top:3px}.ra{font-size:11px;color:var(--navy);margin-top:2px}'+
   '.rt{flex:0 0 auto;text-align:right;color:var(--navy);line-height:1.1}.rt b{font:900 20px "Zen Kaku Gothic New","Noto Sans JP",sans-serif}.rt span{font-size:10.5px;color:var(--sub)}.rt i{display:block;font-style:normal;font-size:10px;color:var(--sub);margin-top:3px}'+
   '.rg{flex:0 0 auto;color:var(--gold);font-size:18px}';
  return '<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+
   '<meta name="robots" content="noindex,nofollow"><title>おすすめの求人</title>'+ogTags('おすすめの求人',(cand.job?cand.job+'の求人を':'求人を')+list.length+'件、通勤時間が近い順に',SITE_BASE+'assets/hero_other.jpg')+FONT_LINK+'<style>'+css+'</style></head><body><div class="wrap">'+
   '<div class="hero"><img class="heroimg" src="../../assets/hero_other.jpg" alt=""><div class="herotext"><div class="eyebrow">GOOD LUCK RECOMMEND</div><h1>おすすめの求人</h1>'+
   '<p>'+(cand.job?esc2(cand.job)+'の求人のうち、':'')+'給与・勤務条件まで確認できるものを、通勤時間が近い順にまとめました。気になるものがあれば、担当までお気軽にどうぞ。</p></div></div>'+
   '<div class="list">'+rows+'</div><footer>GOOD LUCK</footer></div></body></html>';
 }
 function routeStrip(t){
  if(!t) return '';
  if(t.est) return '<div class="route"><span class="rs walk">直線距離から見た徒歩の目安です（経路は取れませんでした）</span></div>';
  var parts=[], lastSt=null;
  (t.legs||[]).forEach(function(l){
   if(l.kind==='walk'){ if(l.mins) parts.push('<span class="rs walk">徒歩 '+l.mins+'分</span>'); lastSt=null; return; }
   if(l.from&&l.from!==lastSt) parts.push('<span class="rs st'+(l.kind==='bus'?' bs':'')+'">'+esc2(l.from)+'</span>');
   parts.push('<span class="rs line'+(l.kind==='bus'?' bus':'')+'">'+(l.kind==='bus'?'<i>バス</i>':'')+esc2(l.line)+'　'+l.mins+'分</span>');
   if(l.to){ parts.push('<span class="rs st'+(l.kind==='bus'?' bs':'')+'">'+esc2(l.to)+'</span>'); lastSt=l.to; }
  });
  return '<div class="route">'+parts.join('<span class="arr">›</span>')+'</div>'+'<div class="rnote">平日'+(t.dep||'8:00')+'発の目安。'+(t.other?'乗り換え・待ち時間 約'+t.other+'分を含みます':'')+'</div>';
 }
 function routeShort(t){
  if(!t||t.est||!t.legs||!t.legs.length) return '';
  var s=(t.legs||[]).filter(function(l){ return l.kind!=='walk'; }).map(function(l){ return (l.kind==='bus'?'バス ':'')+l.line+' '+l.mins+'分'; }).join(' › ');
  return s+(t.walk?'（徒歩'+t.walk+'分を含む）':'');
 }
 // ===== エリアの暮らし（OpenStreetMap の周辺データ＋繁華街までの時間） =====
 var AREA_LABEL={sup:'スーパー',conv:'コンビニ',drug:'ドラッグストア・薬局',bakery:'パン屋',eat:'飲食店',cafe:'カフェ',hosp:'病院・医院',clinic:'クリニック・歯科',post:'郵便局',bank:'銀行',lib:'図書館',park:'公園',gym:'スポーツ施設',mall:'ショッピング施設'};
 function walkMin(kmv){ return Math.max(1,Math.round(kmv*1300/80)); }
 function areaLine(f){ // 一覧に出す一行：最寄り駅と徒歩
  var a=f.area; if(!a) return '';
  var st=(a.p&&a.p.st&&a.p.st[0]); var parts=[];
  if(st) parts.push(st.n+'駅 徒歩'+walkMin(st.d)+'分');
  if(a.c&&a.c.sup) parts.push('スーパー'+a.c.sup);
  if(a.c&&a.c.eat) parts.push('飲食店'+a.c.eat);
  return parts.join('・');
 }
 function areaText(f){ // データから言えることだけを短く。数字の根拠は c（800m圏の件数）
  var a=f.area; if(!a) return ''; var c=a.c||{}, p=a.p||{}; var s=[];
  var st=p.st&&p.st[0];
  if(st&&st.d<=0.6) s.push(st.n+'駅まで歩ける、駅に近い立地です。');
  else if(st&&st.d<=1.2) s.push('最寄りは'+st.n+'駅で徒歩'+walkMin(st.d)+'分ほど。');
  else if(p.bus&&p.bus[0]) s.push('駅からは離れていて、バス（'+p.bus[0].n+'）か車が前提のエリアです。');
  var eat=(c.eat||0)+(c.cafe||0);
  // 徒歩10分圏の件数は一文にまとめる（同じ言い回しを繰り返さない）
  var parts=[];
  if(c.sup) parts.push('スーパー'+c.sup+'軒'+(c.sup===1&&p.sup&&p.sup[0]?'（'+p.sup[0].n+'）':''));
  if(c.conv) parts.push('コンビニ'+c.conv+'軒');
  if(eat) parts.push('飲食店・カフェ'+eat+'軒');
  if(c.park) parts.push('公園'+c.park+'か所');
  var med=(c.hosp||0)+(c.clinic||0); if(med) parts.push('病院・クリニック'+med+'か所');
  if(parts.length) s.push('徒歩10分圏に、'+parts.join('、')+'。');
  else s.push('徒歩10分圏には、地図データ上の店や施設が見つかりませんでした。');
  if(c.mall) s.push((p.mall&&p.mall[0]?p.mall[0].n:'ショッピング施設')+'が徒歩圏にあります。');
  return s.join('');
 }
 function areaCounts(f){
  var a=f.area; if(!a||!a.c) return ''; var c=a.c, p=a.p||{};
  var order=['sup','conv','drug','eat','cafe','bakery','mall','park','hosp','clinic','post','bank','lib','gym'];
  var items=order.filter(function(k){ return c[k]; }).map(function(k){
   var names=(p[k]||[]).map(function(x){ return x.n; }).slice(0,2);
   return '<span class="ac"><b>'+AREA_LABEL[k]+'</b> '+c[k]+(names.length?'<small>'+esc2(names.join('・'))+(c[k]>names.length?' ほか':'')+'</small>':'')+'</span>';
  });
  return items.length?'<div class="acs">'+items.join('')+'</div>':'';
 }
 var LIC_URL={'CC BY-SA 4.0':'https://creativecommons.org/licenses/by-sa/4.0/deed.ja','CC BY-SA 3.0':'https://creativecommons.org/licenses/by-sa/3.0/deed.ja','CC BY 4.0':'https://creativecommons.org/licenses/by/4.0/deed.ja','CC BY 3.0':'https://creativecommons.org/licenses/by/3.0/deed.ja','CC BY 2.5':'https://creativecommons.org/licenses/by/2.5/deed.ja','CC BY 2.0':'https://creativecommons.org/licenses/by/2.0/deed.ja','CC0':'https://creativecommons.org/publicdomain/zero/1.0/deed.ja'};
 function creditHtml(h){ // 「写真：撮影者（Commonsへ）／ライセンス（条文へ）・切り抜きあり」
  var ps=String(h.credit||'').split('／'); var who=ps[0]||'', lic=ps[1]||'';
  var licLink=LIC_URL[lic]?'<a href="'+LIC_URL[lic]+'" target="_blank" rel="noopener">'+esc2(lic)+'</a>':esc2(lic);
  return '写真：<a href="'+esc2(h.csrc)+'" target="_blank" rel="noopener">'+esc2(who)+'</a>'+(lic?'／'+licLink:'')+'・縮小と切り抜きあり';
 }
 function hubBlock(hubs){
  if(!hubs||!hubs.length) return '';
  return hubs.map(function(h){
   var t=h.t; var how=t?routeShort(t):'';
   var photo=h.img?'<img class="hp" src="../../../assets/hubs/'+encodeURIComponent(h.img)+'" alt="'+esc2(h.n)+'" loading="lazy">':'';
   var credit=h.img?'<div class="hc">'+creditHtml(h)+'</div>':'';
   return '<div class="hub">'+photo+'<div class="hb"><div class="hh"><span class="hn">'+esc2(h.n)+'</span>'+(t?'<span class="ht"><b>'+t.mins+'</b>分・乗り換え'+t.transfers+'回</span>':'<span class="ht">時間は取れませんでした</span>')+'</div>'+(how?'<div class="hw">'+esc2(how)+'</div>':'')+'<p>'+esc2(h.desc)+'</p>'+credit+'</div></div>';
  }).join('')+'<div class="anote">繁華街までは平日10時発の目安です。</div>';
 }
 // デフォルメ地図：施設を中心に、徒歩5分・10分の輪と、駅・バス停・スーパー・公園・病院の位置関係。道路は描かない
 function areaMapSvg(f,hubs){
  var a=f.area; if(!a) return '';
  var W=360,H=300,cx=180,cy=156,PX=112; // 800m = 112px。スマホ幅（375px）でほぼ等倍になる
  var cosl=Math.cos(f.la*Math.PI/180);
  function xy(la,lo){ var dx=(lo-f.lo)*cosl*111.32, dy=-(la-f.la)*110.57; return [cx+dx*PX/0.8, cy+dy*PX/0.8]; }
  function clamp(pt,margin){ var dx=pt[0]-cx, dy=pt[1]-cy, rx=W/2-margin, ry=H/2-margin; var k=Math.max(Math.abs(dx)/rx,Math.abs(dy)/ry,1); return [cx+dx/k, cy+dy/k, k>1]; }
  var out=[], under=[], placed=[], texts=[];
  function T(t){ if(t) texts.push(t); return ''; }
  // ラベルの重なり避け：右→下→上→左の順に置ける場所を探し、どこも重なるなら描かない（点は描く）
  function fits(x0,w,y){ if(x0<4||x0+w>W-4) return false; for(var i=0;i<placed.length;i++){ var b=placed[i]; if(Math.abs(b.y-y)<13 && x0<b.x1+4 && x0+w>b.x0-4) return false; } return true; }
  function mark(x,y,r){ placed.push({x0:x-r,x1:x+r,y:y}); }
  function label(x,y,text,cls,anchor){
   var w=text.length*10.5, x0=anchor==='middle'?x-w/2:(anchor==='end'?x-w:x);
   if(anchor==='middle'){ if(x0<4) x0=4; if(x0+w>W-4) x0=W-4-w; }
   if(!fits(x0,w,y)) return '';
   placed.push({x0:x0,x1:x0+w,y:y});
   return '<text x="'+(anchor==='middle'?x0+w/2:(anchor==='end'?x0+w:x0))+'" y="'+y+'" class="'+cls+'" text-anchor="'+(anchor||'start')+'">'+esc2(text)+'</text>';
  }
  function labelNear(x,y,text,cls){ // 点のそばに置く。右→下→上→左
   var tries=[[x+9,y+4,'start'],[x,y+20,'middle'],[x,y-12,'middle'],[x-9,y+4,'end']];
   for(var i=0;i<tries.length;i++){ var t=label(tries[i][0],tries[i][1],text,cls,tries[i][2]); if(t) return t; }
   return '';
  }
  out.push('<circle cx="'+cx+'" cy="'+cy+'" r="'+PX+'" fill="#EEF2EE" stroke="#CFD8D3" stroke-dasharray="4 4"/>');
  out.push('<circle cx="'+cx+'" cy="'+cy+'" r="'+(PX/2)+'" fill="#E6ECE6" stroke="#CFD8D3" stroke-dasharray="4 4"/>');
  T(label(8,14,'北 ↑　位置関係の略図（道路は省略）','ml'));
  // 中心の施設名を先に確保する（いちばん大事。描くのは最後）
  mark(cx,cy,10); var fname=String(f.n||''); if(fname.length>30) fname=fname.slice(0,29)+'…';
  var facLabel=label(cx,cy-15,fname,'mn b','middle'); if(!facLabel){ placed.push({x0:4,x1:W-4,y:cy-15}); facLabel='<text x="'+cx+'" y="'+(cy-15)+'" class="mn b" text-anchor="middle" textLength="'+(W-16)+'" lengthAdjust="spacingAndGlyphs">'+esc2(fname)+'</text>'; }
  var p=a.p||{};
  (p.st||[]).forEach(function(x){ var q=clamp(xy(x.la,x.lo),34); mark(q[0],q[1],9); out.push('<rect x="'+(q[0]-8)+'" y="'+(q[1]-8)+'" width="16" height="16" rx="3" fill="#0E2F3F"/><text x="'+q[0]+'" y="'+(q[1]+4)+'" class="mi" text-anchor="middle">駅</text>'); T(label(q[0],q[1]+22,x.n+'駅'+((q[2]&&x.d!=null)?'（'+Number(x.d).toFixed(1)+'km）':''),'mn b','middle')); });
  (hubs||[]).forEach(function(h){ var q=clamp(xy(h.lat,h.lng),14); var ang=Math.atan2(q[1]-cy,q[0]-cx); var anc=Math.cos(ang)>0.3?'end':(Math.cos(ang)<-0.3?'start':'middle'); var arrow=Math.cos(ang)>0.3?' ›':(Math.cos(ang)<-0.3?'‹ ':(Math.sin(ang)<0?' ↑':' ↓')); var y=Math.min(H-8,Math.max(28,q[1]+4)); var txt=(anc==='start'?arrow:'')+h.n+'方面'+(h.t?' '+h.t.mins+'分':'')+(anc==='start'?'':arrow);
   var ys=[y,y-14,y+14,y-28,y+28].filter(function(v){ return v>=24&&v<=H-6; }); for(var i=0;i<ys.length;i++){ var t=label(q[0],ys[i],txt,'mh',anc); if(t){ texts.push(t); break; } } });
  T(label(cx+PX/2+3,cy+14,'徒歩5分','ml')); T(label(cx+PX+3,cy+14,'徒歩10分','ml'));
  (p.bus||[]).forEach(function(x){ var q=xy(x.la,x.lo); mark(q[0],q[1],6); out.push('<circle cx="'+q[0]+'" cy="'+q[1]+'" r="5" fill="#fff" stroke="#0E2F3F" stroke-width="1.5"/>'); T(labelNear(q[0],q[1],x.n+' バス停','mn')); });
  (p.sup||[]).forEach(function(x){ var q=xy(x.la,x.lo); mark(q[0],q[1],7); out.push('<rect x="'+(q[0]-6)+'" y="'+(q[1]-6)+'" width="12" height="12" rx="2" fill="#C79A3E"/>'); T(labelNear(q[0],q[1],x.n,'mn')); });
  (p.mall||[]).forEach(function(x){ var q=xy(x.la,x.lo); mark(q[0],q[1],8); out.push('<rect x="'+(q[0]-7)+'" y="'+(q[1]-7)+'" width="14" height="14" rx="2" fill="#C79A3E" stroke="#fff" stroke-width="2"/>'); T(labelNear(q[0],q[1],x.n,'mn')); });
  (p.hosp||[]).forEach(function(x){ var q=xy(x.la,x.lo); out.push('<circle cx="'+q[0]+'" cy="'+q[1]+'" r="7" fill="#fff" stroke="#C0504D" stroke-width="1.5"/><path d="M'+(q[0]-3.5)+' '+q[1]+'h7M'+q[0]+' '+(q[1]-3.5)+'v7" stroke="#C0504D" stroke-width="2"/>'); mark(q[0],q[1],8); T(labelNear(q[0],q[1],x.n,'mn')); });
  (p.park||[]).forEach(function(x){ var q=xy(x.la,x.lo); under.push('<circle cx="'+q[0]+'" cy="'+q[1]+'" r="12" fill="#BFD9BE" opacity=".8"/>'); T(label(q[0],q[1]+22,x.n,'mn','middle')||labelNear(q[0],q[1],x.n,'mn')); });
  out.push('<circle cx="'+cx+'" cy="'+cy+'" r="9" fill="#C79A3E" stroke="#fff" stroke-width="3"/><circle cx="'+cx+'" cy="'+cy+'" r="3" fill="#fff"/>'+facLabel);
  return '<svg class="amap" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="周辺の略図">'+out.slice(0,2).join('')+under.join('')+out.slice(2).join('')+texts.join('')+'</svg>';
 }
 // 上空からの写真：国土地理院の空中写真タイル（z=18、3×3枚）を直接並べる。保存しない・費用ゼロ・出典は「地理院タイル」
 function aerialBlock(f){
  if(!f.la||!f.lo) return '';
  var z=18, n=Math.pow(2,z); var lat=Number(f.la)*Math.PI/180;
  var xf=(Number(f.lo)+180)/360*n, yf=(1-Math.log(Math.tan(lat)+1/Math.cos(lat))/Math.PI)/2*n;
  var x0=Math.floor(xf), y0=Math.floor(yf);
  var px=((xf-x0+1)/3*100).toFixed(2), py=((yf-y0+1)/3*100).toFixed(2);
  var imgs=''; for(var dy=-1;dy<=1;dy++) for(var dx=-1;dx<=1;dx++) imgs+='<img src="https://cyberjapandata.gsi.go.jp/xyz/seamlessphoto/'+z+'/'+(x0+dx)+'/'+(y0+dy)+'.jpg" alt="" loading="lazy">';
  var span=Math.round(3*40075000*Math.cos(lat)/n/10)*10;
  return '<div class="aer"><div class="aerg">'+imgs+'</div><span class="aerpin" style="left:'+px+'%;top:'+py+'%"></span><span class="aercap">上空から（約'+span+'m四方）　写真：<a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener">地理院タイル</a>（国土地理院）</span></div>';
 }
 function areaSection(f,hubs){
  var a=f.area; if(!a&&!(hubs&&hubs.length)) return '';
  var p=(a&&a.p)||{}; var st=p.st&&p.st[0], bus=p.bus&&p.bus[0];
  var head='';
  if(st||bus){ head='<div class="ast">'+(st?'<span><b>最寄り駅</b> '+esc2(st.n)+'　徒歩'+walkMin(st.d)+'分</span>':'')+(bus?'<span><b>バス停</b> '+esc2(bus.n)+'　徒歩'+walkMin(bus.d)+'分</span>':'')+'</div>'; }
  var txt=areaText(f);
  return '<div class="block"><h2>このエリアの暮らし</h2>'+areaMapSvg(f,hubs)+aerialBlock(f)+head+(txt?'<p class="atext">'+esc2(txt)+'</p>':'')+areaCounts(f)+
   (a?'<div class="anote">徒歩10分圏（約800m）の店・施設の数は地図データ（<a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">© OpenStreetMap contributors</a>）からの集計です。営業状況は変わることがあります。徒歩は直線距離の1.3倍を80m/分で計算した目安です。</div>':'')+
   (hubs&&hubs.length?'<h3 class="ah">出かけるならこの街へ</h3>'+hubBlock(hubs):'')+'</div>';
 }
 function factRow(label,html){ return html?'<tr><th>'+label+'</th><td>'+html+'</td></tr>':''; }
 function buildJobBlock(name,d,count){
  var f=d.f||{};
  var pay='';
  if(f.kyuyo&&f.kyuyo.length){
   var pp=pickPay(f.kyuyo);
   pay='<div class="pay">'+esc2(pp.line)+'</div>'+(pp.rest.length?renderLines(pp.rest,6):'');
  }
  if(f.teate&&f.teate.length){ pay+=renderLines(f.teate,4); }
  var jikan=''; if(d.kinmu) jikan+='<div class="plain1">'+esc2(d.kinmu)+'</div>'; if(f.jikan) jikan+=renderLines(f.jikan,6);
  var nl=nightLines(f);
  var night=nl.length?renderLines(nl,5):'<span class="na">求人票に記載なし。担当にお尋ねください</span>';
  var facts=factRow('給与',pay)+factRow('夜勤・日勤',night)+factRow('勤務時間',jikan)+factRow('休日・休暇',f.kyujitsu?renderLines(f.kyujitsu,6):'')+factRow('雇用形態',d.koyou?esc2(d.koyou):'')+factRow('試用期間',f.shiyo?renderLines(f.shiyo,4):'');
  var secs='';
  if(f.naiyo) secs+='<div class="sec"><h3>仕事内容</h3>'+renderLines(f.naiyo,8)+'</div>';
  if(f.shikaku) secs+='<div class="sec"><h3>応募資格</h3>'+renderLines(f.shikaku,8)+'</div>';
  if(f.taigu) secs+='<div class="sec"><h3>待遇・福利厚生</h3>'+renderLines(f.taigu,8)+'</div>';
  if(f.other) secs+='<div class="sec"><h3>そのほか</h3>'+renderLines(f.other,8)+'</div>';
  return '<section class="job"><div class="jhd"><h2>'+esc2(name)+'</h2><div class="jtags">'+(d.koyou?'<span class="tag">'+esc2(d.koyou)+'</span>':'')+'<span class="cnt">募集 '+count+'名</span></div></div>'+
   (d.title?'<p class="jtitle">'+esc2(d.title)+'</p>':'')+
   (facts?'<table class="facts">'+facts+'</table>':'')+secs+'</section>';
 }
 function buildCompanyPage(cand,f,s,idx,total){
  var jd=f.jd||{};
  var order=Object.keys(f.j||{}).sort(function(a,b){ var ra=(jd[a]&&jd[a].rich)?1:0, rb=(jd[b]&&jd[b].rich)?1:0; if(a===cand.job) ra+=2; if(b===cand.job) rb+=2; return rb-ra; });
  // 出すのは希望職種の求人票1枚だけ（なければ揃っている職種を1つ）。ほかの職種は一行で
  var main=order[0]; var jobs=main?buildJobBlock(main,jd[main]||{},f.j[main]):'';
  var others=order.slice(1); if(others.length) jobs+='<p class="others">ほかに '+esc2(others.join('・'))+' の募集もあります。気になる場合は担当まで。</p>';
  var why=s.reasons.map(function(r){ return '<li>'+esc2(r)+'</li>'; }).join('');
  var chips=Object.keys(f.j||{}).map(function(k){ return '<span class="chip">'+esc2(k)+'</span>'; }).join('');
  var css=SEEKER_CSS+
   '.statwrap{padding:0 22px;margin-top:-18px;position:relative}'+
   '.stat{background:var(--card);border-radius:10px;padding:14px 18px;box-shadow:0 14px 30px -18px rgba(14,47,63,.55);border-top:3px solid var(--gold)}'+
   '.stathead{display:flex;align-items:baseline;gap:10px}.stat b{font:900 30px "Zen Kaku Gothic New","Noto Sans JP",sans-serif;color:var(--navy)}.stathead span{font-size:12px;color:var(--sub)}'+
   '.route{display:flex;flex-wrap:wrap;align-items:center;gap:4px 6px;margin-top:10px;font-size:12px;line-height:1.5}'+
   '.rs.st{font-weight:700;color:var(--navy)}.rs.line{background:#EAF0F4;border-radius:3px;padding:2px 8px;color:var(--navy)}.rs.walk{color:var(--sub)}.arr{color:var(--gold);font-weight:700}'+
   '.rs.line.bus{background:#F3EBDA}.rs.line i{font-style:normal;font-size:10px;background:var(--gold);color:#fff;border-radius:2px;padding:0 4px;margin-right:5px}.rs.st.bs{font-weight:400}'+
   '.rnote{font-size:11px;color:var(--sub);margin-top:6px}'+
   '.amap{display:block;width:100%;height:auto;background:#F9FAF8;border:1px solid var(--line);border-radius:10px;font-family:"Noto Sans JP",sans-serif}'+
   '.amap text{paint-order:stroke;stroke:#F9FAF8;stroke-width:3px;stroke-linejoin:round}'+
   '.amap .ml{font-size:10px;fill:#8A948F}.amap .mn{font-size:11px;fill:#33404A}.amap .mn.b{font-weight:700;fill:var(--navy);font-size:12px}.amap .mi{font-size:9px;fill:#fff;font-weight:700}.amap .mh{font-size:11px;font-weight:700;fill:var(--gold)}'+
   '.aer{position:relative;margin-top:8px;border-radius:10px;overflow:hidden;border:1px solid var(--line);background:#DDE3DD}.aerg{display:grid;grid-template-columns:repeat(3,1fr);line-height:0}.aerg img{width:100%;aspect-ratio:1;object-fit:cover;display:block}'+
   '.aerpin{position:absolute;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:50%;background:var(--gold);border:3px solid #fff;box-shadow:0 0 0 2px rgba(14,47,63,.35)}'+
   '.aercap{position:absolute;left:0;right:0;bottom:0;padding:4px 10px;font-size:10px;color:#fff;background:linear-gradient(transparent,rgba(0,0,0,.55))}'+
   '.ast{display:flex;flex-wrap:wrap;gap:6px 18px;font-size:13px;margin-top:12px}.ast b{color:var(--sub);font-size:11px;margin-right:4px}'+
   '.atext{font-size:13.5px;line-height:1.85;margin:10px 0 0}'+
   '.acs{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}.ac{font-size:12px;background:var(--card);border:1px solid var(--line);border-radius:6px;padding:5px 9px;line-height:1.4}.ac b{color:var(--navy);font-weight:700}.ac small{display:block;font-size:10.5px;color:var(--sub)}'+
   '.anote{font-size:11px;color:var(--sub);margin-top:8px;line-height:1.6}.anote a,.aercap a{color:inherit;text-decoration:underline}'+
   '.ah{font-family:"Zen Kaku Gothic New",sans-serif;font-size:13.5px;color:var(--navy);margin:18px 0 8px}'+
   '.hub{background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-top:10px}.hp{display:block;width:100%;height:170px;object-fit:cover;background:#E6ECE6}.hb{padding:12px 14px 12px}.hc{font-size:10.5px;color:#9AA3A0;margin-top:6px}.hc a{color:inherit;text-decoration:underline}.hh{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:baseline;gap:4px 8px}.hn{font-family:"Zen Kaku Gothic New",sans-serif;font-weight:700;font-size:16px;color:var(--navy)}.ht{font-size:12px;color:var(--sub)}.ht b{white-space:nowrap}.ht b{font:900 20px "Zen Kaku Gothic New","Noto Sans JP",sans-serif;color:var(--navy)}'+
   '.hw{font-size:11.5px;color:var(--sub);margin-top:2px}.hub p{font-size:12.5px;line-height:1.7;margin:6px 0 0}'+
   '.heroimg.real{height:240px}.gal{display:grid;grid-template-columns:1fr 1fr;gap:6px}.gal img{width:100%;height:120px;object-fit:cover;border-radius:6px;background:#E6ECE6}'+
   '.job{margin:22px 18px 0;background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px 18px 8px}'+
   '.jhd{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}'+
   '.jhd h2{font-family:"Zen Kaku Gothic New",sans-serif;font-size:19px;color:var(--navy);margin:0;line-height:1.3}'+
   '.jtags{display:flex;gap:6px;flex:0 0 auto;align-items:center}'+
   '.tag{font-size:11px;color:var(--navy);background:#EAF0F4;border-radius:3px;padding:3px 8px;white-space:nowrap}'+
   '.cnt{font-size:11px;color:#fff;background:var(--navy);border-radius:3px;padding:3px 8px;white-space:nowrap}'+
   '.jtitle{margin:6px 0 0;font-size:13px;color:var(--sub)}.others{margin:10px 18px 0;font-size:12px;color:var(--sub)}'+
   '.facts{width:100%;border-collapse:collapse;margin:14px 0 4px;font-size:13px;table-layout:fixed}'+
   '.facts th{width:6em;text-align:left;vertical-align:top;padding:10px 8px 10px 0;color:var(--sub);font-weight:700;font-size:12px;border-top:1px solid var(--line)}'+
   '.facts td{padding:10px 0;border-top:1px solid var(--line);vertical-align:top}'+
   '.facts tr:first-child th,.facts tr:first-child td{border-top:0}'+
   '.pay{font:900 19px/1.35 "Zen Kaku Gothic New",sans-serif;color:var(--navy);margin-bottom:4px}'+
   '.plain1{margin-bottom:2px}'+
   '.ln{list-style:none;margin:0;padding:0}.ln li{position:relative;padding-left:14px;margin:2px 0;line-height:1.65}'+
   '.ln li:before{content:"・";position:absolute;left:0;color:var(--gold)}'+
   '.ln li.plain{padding-left:0}.ln li.plain:before{content:""}'+
   '.ln li.note{padding-left:0;font-size:12px;color:var(--sub)}.ln li.note:before{content:""}'+
   '.ln li.sub{padding-left:0;font-weight:700;color:var(--navy);margin-top:8px}.ln li.sub:before{content:""}'+
   '.more{margin-top:4px}.more summary{cursor:pointer;color:var(--navy);font-size:12px;font-weight:700;list-style:none;padding:6px 0}.more summary::-webkit-details-marker{display:none}.more summary:before{content:"＋ "}.more[open] summary:before{content:"－ "}'+
   '.sec{padding:12px 0 10px;border-top:1px solid var(--line);font-size:13px}.sec h3{font-family:"Zen Kaku Gothic New",sans-serif;font-size:13.5px;color:var(--navy);margin:0 0 6px}'+
   '.block{margin:22px 18px 0}.block h2{font-family:"Zen Kaku Gothic New",sans-serif;font-size:14px;color:var(--navy);margin:0 0 10px;padding-bottom:6px;border-bottom:2px solid var(--gold);display:inline-block}'+
   '.why{margin:0;padding:0;list-style:none;font-size:13px}.why li{padding-left:18px;position:relative;margin:4px 0}.why li:before{content:"―";position:absolute;left:0;color:var(--gold)}'+
   '.addr{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px;font-size:13px;color:var(--sub)}'+
   '.addr .links{display:flex;flex-wrap:wrap;gap:8px 18px;margin-top:8px}.addr a{color:var(--navy);font-weight:700;font-size:12.5px}'+
   '.cta{margin:26px 18px 0;background:var(--navy);color:#fff;border-radius:10px;padding:18px 20px;font-size:13.5px;line-height:1.8}'+
   '.cta.mini{margin-top:14px;padding:12px 16px;font-size:12.5px}.cta.mini b{display:inline;font-size:13px;margin-right:6px}.na{color:var(--sub);font-size:12px}'+
   '.cta b{display:block;font-family:"Zen Kaku Gothic New",sans-serif;font-size:15px;margin-bottom:4px}'+
   '.nav{display:flex;justify-content:space-between;padding:22px 22px 0;font-size:12.5px}.nav a{color:var(--sub);font-weight:700}.nav .idx{color:#B9B2A2}';
  return '<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+
   '<meta name="robots" content="noindex,nofollow"><title>'+esc2(f.n)+'</title>'+ogTags(f.n,(f.d||f.t||'')+(f.time?'　自宅から約'+f.time.mins+'分':''),(f.photos&&f.photos.length)?SITE_BASE+'assets/f/'+encodeURIComponent(f.i)+'/'+encodeURIComponent(f.photos[0]):SITE_BASE+'assets/'+(HERO_IMG[f.t]||'hero_other.jpg'))+FONT_LINK+'<style>'+css+'</style><script>addEventListener("beforeprint",function(){document.querySelectorAll("details").forEach(function(d){d.open=true;});});</script></head><body><div class="wrap">'+
   '<div class="hero"><img class="heroimg'+((f.photos&&f.photos.length)?' real':'')+'" src="'+((f.photos&&f.photos.length)?facPhoto(f,f.photos[0]):heroImg(f.t))+'" alt="">'+
   '<div class="herotext"><div class="eyebrow">'+esc2(f.t||'求人')+(f.d?' ｜ '+esc2(f.d):'')+'</div><h1>'+esc2(f.n)+'</h1>'+
   (f.c?'<div class="sub">'+esc2(f.c)+'</div>':'')+'<div class="chips">'+chips+'</div></div></div>'+
   (f.time?'<div class="statwrap"><div class="stat"><div class="stathead"><b>'+f.time.mins+'</b><span>分・自宅から'+(f.time.est?'':'　乗り換え'+f.time.transfers+'回')+'</span></div>'+routeStrip(f.time)+'</div></div>':'')+
   jobs+
   '<div class="cta mini"><b>気になったら、担当まで。</b>夜勤の回数など載っていない条件もお尋ねください。</div>'+
   photoGallery(f)+
   areaSection(f,f.hubs)+
   (why?'<div class="block"><h2>おすすめする理由</h2><ul class="why">'+why+'</ul></div>':'')+
   '<div class="block"><h2>アクセス</h2><div class="addr">'+esc2(f.a)+'<div class="links"><a href="'+mapLink(f.a)+'" target="_blank" rel="noopener">地図で見る ›</a><a href="'+searchLink(f.n,f.a)+'" target="_blank" rel="noopener">施設名で調べる ›</a></div></div></div>'+
   '<div class="cta"><b>この求人が気になったら</b>担当までご連絡ください。見学の調整や、載っていない条件の確認も、こちらで進めます。</div>'+
   '<div class="nav"><a class="idx" href="../">‹ 一覧へ戻る</a><span>'+idx+' / '+total+'</span></div>'+
   '<footer>GOOD LUCK</footer></div></body></html>';
 }
 function corpKey(f){ return (f.c&&f.c.trim())||String(f.n||'').replace(/[\s　]/g,'').slice(0,6); }
 function pickDiverse(sorted,n){
  var cnt={}, out=[], rest=[];
  sorted.forEach(function(x){ var k=corpKey(x.f); if((cnt[k]||0)<2){ cnt[k]=(cnt[k]||0)+1; out.push(x); } else rest.push(x); });
  return out.concat(rest).slice(0,n);
 }
 function buildSeekerBundle(cand,list){
  var pages={};
  pages['index.html']=buildIndexPage(cand,list);
  list.forEach(function(x,i){ pages['c'+(i+1)+'/index.html']=buildCompanyPage(cand,x.f,x.s,i+1,list.length); });
  return pages;
 }
 function updateMkBtn(){
  if(lastRanked && lastRanked.length){ mkBtn.disabled=false; } else { mkBtn.disabled=true; }
 }
 mkBtn&&mkBtn.addEventListener('click',async function(){
  if(!lastOrigin) return;
  var cand=candidateProfile();
  mkBtn.disabled=true; mkMsg.textContent='求人票が揃っている施設を集めています…';
  try{
   var data=await loadData(); var o=lastOrigin; var manifest=await loadPhotoManifest();
   var pool=data.filter(function(f){ return f.rich; }).map(function(f){ return Object.assign({dist:km({lat:o.lat,lng:o.lng},{lat:f.la,lng:f.lo})},f); }).filter(function(f){ return f.dist<=40; });
   var pref=cand.job?pool.filter(function(f){ return f.jd&&f.jd[cand.job]&&f.jd[cand.job].rich; }):[];
   var base=(pref.length>=3?pref:pool).sort(function(x,y){ return x.dist-y.dist; }).slice(0,30);
   if(!base.length){ mkMsg.textContent='40km以内に、求人票が揃っている施設がありません。'; mkBtn.disabled=false; return; }
   var known={}; (lastRanked||[]).forEach(function(f){ if(f.time) known[f.i]=f.time; });
   if(EK){ mkMsg.textContent='ドアドアの時間を計算しています…（'+base.length+'件）'; await mapLimited(base,3,async function(f){ if(known[f.i]){ f.time=known[f.i]; return; } try{ f.time=await doorToDoor(o,f); }catch(e){ f.time=null; } }); }
   var scored=pickDiverse(base.map(function(f){ return {f:f,s:scoreOne(cand,f)}; }).sort(function(a,b){ return b.s.score-a.s.score; }),8);
   scored.sort(function(a,b){ var ta=a.f.time?a.f.time.mins:9999, tb=b.f.time?b.f.time.mins:9999; return ta-tb; }); // 選んだあとは時間の近い順（前書きどおり）
   scored.forEach(function(x){ x.f.photos=manifest[x.f.i]||[]; });
   if(EK){ mkMsg.textContent='繁華街までの時間を調べています…（'+scored.length+'社）'; await mapLimited(scored,2,async function(x){ try{ x.f.hubs=await hubAccess(x.f); }catch(e){ x.f.hubs=nearHubs(x.f,2).map(function(h){ h.t=null; return h; }); } }); }
   else { scored.forEach(function(x){ x.f.hubs=nearHubs(x.f,2).map(function(h){ h.t=null; return h; }); }); }
   var pages=buildSeekerBundle(cand,scored);
   var blob=new Blob([JSON.stringify({pages:pages})],{type:'application/json'}); var url=URL.createObjectURL(blob);
   var a=document.createElement('a'); a.href=url; a.download='おすすめ求人.json'; document.body.appendChild(a); a.click(); a.remove();
   setTimeout(function(){ URL.revokeObjectURL(url); },4000);
   mkMsg.innerHTML=scored.length+'社ぶん、ページを作りました（職種：'+esc(cand.job||'指定なし')+'）（求人票が揃っている施設だけ。一覧＋企業ごとに1枚）。駅すぱあと 本日'+ekUsed()+'/'+EK_DAILY_CAP+'回。公開は<br><code>node publish_seeker.mjs &lt;ファイル&gt;</code>（gl-hearing-site内）';
  }catch(e){ mkMsg.textContent='作れませんでした：'+(e.message||e); }
  mkBtn.disabled=false;
 });

  go.addEventListener('click',run); inp.addEventListener('keydown',function(e){ if(e.key==='Enter') run(); });
})();

;document.getElementById('logHead').addEventListener('click',function(){document.getElementById('log').classList.toggle('open')});
document.getElementById('bottomBar').addEventListener('click',function(){document.getElementById('bottom').classList.toggle('open')});

// bridge.js（別スクリプト）から使う
window.F=F;window.FM=FM;window.store=store;window.allVals=allVals;window.render=render;

;(function(){ // 上段の高さが変わったら --toph を追従（フォント読込・幅変更・折り返し）
 var top=document.querySelector('.top'); if(!top||!window.ResizeObserver) return;
 new ResizeObserver(function(){ document.documentElement.style.setProperty('--toph', top.offsetHeight+'px'); }).observe(top);
 window.addEventListener('load',function(){ document.documentElement.style.setProperty('--toph', top.offsetHeight+'px'); });
})();

;/* ===== 連続架電：リストを順にかける。かける → 通話 → 結果を押す → 次の人（自動でかける）。
   発信は PORTERS 側（content.js）が tel: を開く。Mac の「iPhoneから通話」が有効なら iPhone の回線から出る。
   終話は板から見えないので、結果のボタンが「次へ」の合図。結果は localStorage に残り、CSVで出せる ===== */
(function(){
 var card=document.getElementById('dialCard'); if(!card) return;
 var $=function(id){ return document.getElementById(id); };
 var KEY='glh_dialq';
 var q={items:[],i:0};
 try{ var saved=JSON.parse(localStorage.getItem(KEY)||'null'); if(saved&&Array.isArray(saved.items)) q=saved; }catch(e){}
 function save(){ try{ localStorage.setItem(KEY,JSON.stringify(q)); }catch(e){} }
 function esc(s){ return String(s||'').replace(/[&<>"]/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
 function normTel(t){ var d=String(t||'').replace(/[^\d]/g,''); return (d.length===10||d.length===11)?d:''; }
 function fmtTel(d){ d=normTel(d); if(!d) return ''; if(d.length===11) return d.replace(/(\d{3})(\d{4})(\d{4})/,'$1-$2-$3'); if(/^0(3|6)/.test(d)) return d.replace(/(\d{2})(\d{4})(\d{4})/,'$1-$2-$3'); return d.replace(/(\d{3,4})(\d{2,3})(\d{4})/,'$1-$2-$3'); }
 function parseText(t){
  var out=[]; String(t||'').split(/\n/).forEach(function(line){
   line=line.trim(); if(!line) return;
   var m=line.match(/0\d{1,4}[-‐−–ー]?\d{1,4}[-‐−–ー]?\d{3,4}/); if(!m) return;
   var tel=normTel(m[0]); if(!tel) return;
   var rest=line.replace(m[0],' ').split(/[\s　,、\t]+/).filter(Boolean);
   out.push({n:rest[0]||'',tel:fmtTel(tel),memo:rest.slice(1).join(' ')});
  }); return out;
 }
 function cur(){ return q.items[q.i]||null; }
 function render(){
  var n=q.items.length, done=q.items.filter(function(x){ return x.r; }).length;
  $('dialStat').textContent=n?('全 '+n+' 件・済 '+done):'';
  $('dialMsg').textContent=n?(q.i<n?'':'全部かけ終わりました。CSVで保存できます'):'リストが空です。「PORTERSの画面から拾う」か「貼り付けから読む」。';
  var c=cur();
  if(c){ $('dialNow').hidden=false; $('dialPos').textContent=(q.i+1)+' / '+n; $('dialName').textContent=c.n||'（名前なし）'; $('dialTel').textContent=c.tel; $('dialMemo').textContent=c.memo||''; }
  else $('dialNow').hidden=true;
  $('dialList').innerHTML=q.items.map(function(x,i){
   return '<li class="'+(i===q.i?'now':(x.r?'done':''))+'" data-i="'+i+'"><span>'+(i+1)+'.</span><span>'+esc(x.n||'（名前なし）')+'</span><span class="mini">'+esc(x.tel)+'</span>'+(x.r?'<span class="r'+(x.r==='話せた'?' ok':'')+'">'+esc(x.r)+'</span>':'')+'</li>';
  }).join('');
 }
 function dial(){
  var c=cur(); if(!c) return;
  c.at=new Date().toISOString().slice(0,16).replace('T',' '); save();
  if(window.glhBridge&&window.glhBridge.hasParent()) window.glhBridge.dial(c.tel);
  else { try{ window.location.href='tel:'+normTel(c.tel); }catch(e){} }
 }
 function setList(items,label){
  if(!items.length){ $('dialMsg').textContent='電話番号が見つかりませんでした'+(label?'（'+label+'）':''); return; }
  q={items:items,i:0}; save(); render();
  $('dialMsg').textContent=items.length+'件を読みました'+(label?'（'+label+'）':'')+'。「かける」で始めます';
 }
 $('dialScan').addEventListener('click',function(){
  if(!(window.glhBridge&&window.glhBridge.hasParent())){ $('dialMsg').textContent='PORTERSの中で開いているときだけ拾えます（別窓でも可）'; return; }
  $('dialMsg').textContent='PORTERSの画面を読んでいます…'; window.glhBridge.scanPhones();
 });
 window.addEventListener('glh-phones',function(e){ var items=(e.detail||[]).map(function(x){ return {n:x.n||'',tel:fmtTel(x.tel),memo:x.memo||''}; }).filter(function(x){ return x.tel; }); setList(items,'PORTERSの画面'); });
 $('dialPaste').addEventListener('click',function(){
  var ta=$('dialText');
  if(ta.hidden){ ta.hidden=false; ta.focus(); $('dialPaste').textContent='この内容で読む'; return; }
  setList(parseText(ta.value),'貼り付け'); ta.hidden=true; $('dialPaste').textContent='貼り付けから読む';
 });
 $('dialClear').addEventListener('click',function(){ if(!q.items.length||confirm('リストと結果を消します。よいですか')){ q={items:[],i:0}; save(); render(); } });
 $('dialGo').addEventListener('click',dial);
 card.querySelectorAll('.dres .btn').forEach(function(b){
  b.addEventListener('click',function(){
   var c=cur(); if(!c) return; c.r=b.getAttribute('data-r'); c.done=new Date().toISOString().slice(0,16).replace('T',' ');
   // 次の「未了」へ
   var j=q.i+1; while(j<q.items.length&&q.items[j].r) j++; q.i=j; save(); render();
   if($('dialAuto').checked&&cur()) dial();
  });
 });
 $('dialBack').addEventListener('click',function(){ if(q.i>0){ q.i--; var c=cur(); if(c) delete c.r; save(); render(); } });
 $('dialList').addEventListener('click',function(e){ var li=e.target.closest('li[data-i]'); if(!li) return; q.i=Number(li.getAttribute('data-i')); save(); render(); });
 $('dialCsv').addEventListener('click',function(){
  var rows=[['名前','電話','結果','かけた時刻','メモ']].concat(q.items.map(function(x){ return [x.n,x.tel,x.r||'',x.at||'',x.memo||'']; }));
  var csv='﻿'+rows.map(function(r){ return r.map(function(v){ return '"'+String(v||'').replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob=new Blob([csv],{type:'text/csv'}); var url=URL.createObjectURL(blob); var a=document.createElement('a'); a.href=url; a.download='架電結果_'+new Date().toISOString().slice(0,10)+'.csv'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){ URL.revokeObjectURL(url); },4000);
 });
 render();
})();
