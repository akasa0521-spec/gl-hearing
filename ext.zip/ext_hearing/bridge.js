/* PORTERS との橋。hearing.js（試作93-068）の F / store / render を使う */
(function(){
 'use strict';
 // 試作の項目名 → PORTERS の項目名（違うものだけ）
 var ALIAS={
  '面談メモ':'事実メモ',
  '給与マスト':'給与マスト（月給・万円）',
  '現在の月収':'現在の月収[万円]',
  '希望の月収':'希望の月収[万円]',
  '経験職種／経験施設形態':'経験職種',
  '保有資格':null   // PORTERSは職種別の欄。ここからは書かない
 };

 function jikiGuess(v){ // 希望転職時期：自由記述 → PORTERSの選択肢
  var s=String(v||'');
  if(/即|すぐ|今すぐ|至急/.test(s)) return '即転職希望';
  if(/未定|情報収集|決めて/.test(s)) return '未定(情報収集中)';
  var m=s.match(/(\d{4})\s*年\s*(\d{1,2})\s*月/);
  if(m){ var now=new Date(); var months=(parseInt(m[1],10)-now.getFullYear())*12+(parseInt(m[2],10)-(now.getMonth()+1));
   if(months<=1) return '即転職希望'; if(months<=6) return '3ヶ月～半年(本格的に転職先を検討)'; return '1年以内(いい転職先があれば)'; }
  if(/3ヶ月|半年/.test(s)) return '3ヶ月～半年(本格的に転職先を検討)';
  if(/1年|一年/.test(s)) return '1年以内(いい転職先があれば)';
  return '';
 }
 function plabel(f){ return (f.l in ALIAS)?ALIAS[f.l]:f.l; }
 function fmtDt(x){ return x?x.replace('T',' '):''; } // "YYYY-MM-DD HH:mm"（PORTERS側で日付欄と時刻欄に分ける）
 var PARENT_ORIGINS=['https://hrbc.porterscloud.com','https://hrbc-jp.porterscloud.com']; // PORTERSは2つの入口がある
 function okOrigin(o){ return PARENT_ORIGINS.indexOf(o)>=0||o==='null'||/^file:/.test(o||''); } // file: は同梱の test_edit.html 用
 // 送り先は PORTERS に限定（親が別サイトなら届かない）。file: は同梱の test_edit.html 用に '*'
 var PARENT_TARGET=(location.protocol==='file:')?'*':null; // 親から最初の便が届いた時に確定する
 function host(){ try{ if(window.opener&&window.opener!==window) return window.opener; }catch(err){} return window.parent!==window?window.parent:null; } // 別窓なら opener、板なら parent
 function toParent(m){ var hw=host(); if(!hw) return; if(PARENT_TARGET){ hw.postMessage(m,PARENT_TARGET); return; } PARENT_ORIGINS.forEach(function(o){ try{ hw.postMessage(m,o); }catch(err){} }); } // 宛先違いは黙って捨てられるので両方へ送る
 function collect(){
  var v=allVals(); var out=[];
  F.forEach(function(f){
   var lab=plabel(f); if(!lab) return;
   var val=v[f.id]; if(val==null||val===''||(Array.isArray(val)&&!val.length)) return;
   if(f.t==='dt') val=fmtDt(val);
   if(f.id==='jiki') val=[val, jikiGuess(val)];            // PORTERSは選択肢。原文→当てはまる選択肢の順で試す
   if(f.id==='yasumi') val=String(val).split('').filter(function(c){return '月火水木金土日祝'.indexOf(c)>=0;}); // 「土日」→ 土・日
   out.push({label:lab,type:f.t,value:val});
  });
  return out;
 }
 var msg=document.getElementById('bridgeMsg');
 function say(t){ msg.textContent=t; }
 var topEl=document.getElementById('glhTopMsg'); // 上の帯（結果と次の一手を、下まで見に行かなくても分かるように）
 function topMsg(t,ok){ if(!topEl) return; topEl.textContent=t||''; topEl.className='glh-topmsg'+(ok?' ok':''); if(t) topEl.removeAttribute('hidden'); else topEl.setAttribute('hidden','hidden'); }
 var NEXT='板を閉じました。画面の「保存」を押してください（右下の「ヒアリング」で板は戻せます）';
 // 初回の案内。× で消したら次から出さない（localStorage: glh_guide_seen）
 try{
  var guide=document.getElementById('glhGuide'), guideClose=document.getElementById('glhGuideClose');
  if(guide&&localStorage.getItem('glh_guide_seen')!=='1') guide.removeAttribute('hidden');
  if(guideClose) guideClose.addEventListener('click',function(){ try{ localStorage.setItem('glh_guide_seen','1'); }catch(err){} if(guide) guide.setAttribute('hidden','hidden'); });
 }catch(err){}
 document.getElementById('writeBtn').addEventListener('click',function(){
  var items=collect();
  if(!items.length){ say('入力がまだありません'); return; }
  say('書き込み中…');
  toParent({type:'glh-write',items:items});
 });
 document.getElementById('readBtn').addEventListener('click',function(){
  var labels=F.map(function(f){return {id:f.id,label:plabel(f),type:f.t};}).filter(function(x){return x.label;});
  say('読み込み中…');
  toParent({type:'glh-read',labels:labels});
 });
 window.addEventListener('message',function(e){
  if(e.source!==host()||!okOrigin(e.origin)) return;
  if(!PARENT_TARGET&&PARENT_ORIGINS.indexOf(e.origin)>=0) PARENT_TARGET=e.origin;
  var d=e.data||{}; if(typeof d.type!=='string'||d.type.indexOf('glh-')!==0) return;
  if(d.type==='glh-result'){
   var t=''; var okN=(d.written&&d.written.length)||0;
   if(okN) t+='書きました（'+okN+'）：'+d.written.join('／')+'\n';
   if(d.missing&&d.missing.length) t+='PORTERS側に無い（'+d.missing.length+'）：'+d.missing.join('／')+'\n';
   if(okN) t+=NEXT; else if(d.note) t+=d.note;
   say(t||'書ける項目がありませんでした');
   if(okN) topMsg('書きました（'+okN+'項目）。'+NEXT,true);
  }
  if(d.type==='glh-values'){
   var n=0;
   (d.values||[]).forEach(function(x){
    var f=FM[x.id]; if(!f) return;
    var val=x.value; if(val==null||val===''||(Array.isArray(val)&&!val.length)) return;
    if(f.t==='dt'&&typeof val==='string') val=val.replace(' ','T').replace(/\//g,'-').slice(0,16);
    if(f.t==='chk'&&!Array.isArray(val)) val=String(val).split(/[／,、]/).map(function(s){return s.trim();}).filter(Boolean);
    if(f.t==='num'){ var m=String(val).match(/\d+(\.\d+)?/); if(!m) return; val=m[0]; } // 「30分以内」→ 30
    if(f.t==='sel'&&Array.isArray(val)) val=val[0]||'';
    store[f.id]=val; n++;
   });
   try{ render(); }catch(err){}
   say(n?'PORTERSから '+n+' 項目を読みました':'PORTERS側に読める項目がありません（レジュメの編集画面で開いてください）');
  }
  if(d.type==='glh-context'){
   var el=document.querySelector('.stat .v'); // 相手
   if(el&&d.name) el.textContent=d.name;
   if(!d.editing){ say('※ レジュメの編集画面ではありません。書き込みは、レジュメを開いて「編集」を押してから。'); topMsg('いまはレジュメの編集画面ではありません。レジュメを開いて「編集」を押してから書き込めます'); }
   else { say(''); topMsg(''); }
  }
 });
 // 連続架電：板→親（PORTERSの画面）に「電話番号を拾って」「この番号にかけて」。親からの答えは CustomEvent で hearing.js へ
 window.glhBridge={
  hasParent:function(){ return !!host(); },
  scanPhones:function(){ toParent({type:'glh-scan-phones'}); },
  dial:function(tel){ toParent({type:'glh-dial',tel:tel}); }
 };
 window.addEventListener('message',function(e){
  if(e.source!==host()||!okOrigin(e.origin)) return;
  var d=e.data||{}; if(d.type==='glh-phones') window.dispatchEvent(new CustomEvent('glh-phones',{detail:d.items||[]}));
 });
 // 親に「準備できた」を伝える
 toParent({type:'glh-ready'});
})();
