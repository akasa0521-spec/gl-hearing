/* GL ヒアリング：PORTERS の画面に、ヒアリング画面（hearing.html）を重ねて出し、
   「PORTERSへ書き込む」で編集画面の項目に値を入れる。項目は表示名で探す（位置やidに依存しない） */
(function () {
  'use strict';
  var root=null, shadow=null, panelEl=null, frame=null, headSub=null;
  var EXT_ORIGIN=new URL(chrome.runtime.getURL('')).origin;
  // 画面本体はサイトから読む（合言葉付き）。拡張を入れ直さなくても、サイトを更新すれば全員に届く
  var REMOTE_URL='https://akasa0521-spec.github.io/gl-hearing/';
  var SITE_ORIGIN='https://akasa0521-spec.github.io';
  var BOARD_URL='https://akasa0521-spec.github.io/gl-share/board_top.html';
  var USE_REMOTE=true; // false にすると同梱の hearing.html（拡張内）に戻る
  var FRAME_ORIGIN=USE_REMOTE?SITE_ORIGIN:EXT_ORIGIN; // 送り先。受け口は両方許す（下の isFrameOrigin）
  function isFrameOrigin(o){ return o===SITE_ORIGIN||o===EXT_ORIGIN; }
  var readySeen=false;

  // ===== PORTERS側 DOM =====
  function norm(s){ return (s||'').replace(/\s+/g,'').replace(/[〜～~]/g,'〜').replace(/[（(]/g,'（').replace(/[）)]/g,'）').replace(/[\[［]/g,'[').replace(/[\]］]/g,']').replace(/[*＊]|必須$/g,''); }
  function isOurs(el){ return !!(root&&(el===root||root.contains(el))); }
  // ラベル要素を探す。<label> を最優先（編集画面）。表示画面の td.info-label 等は後ろ
  function labelNodes(label){
    var want=norm(label); if(!want) return [];
    var exact=[], loose=[];
    function scan(selector, allowChildren){
      var all=document.querySelectorAll(selector);
      for (var i=0;i<all.length;i++){
        var el=all[i]; if(isOurs(el)) continue;
        if(!allowChildren && el.children.length>0 && !(el.children.length===1 && el.children[0].tagName==='SPAN')) continue;
        if(el.querySelector && el.querySelector('input,select,textarea')) continue; // 選択肢の label（中にinputがある）は項目名ではない
        var t=norm(el.textContent); if(!t||t.length>want.length+6) continue;
        if(t===want) exact.push(el);
        else if(t.indexOf(want)===0) loose.push(el);
      }
    }
    scan('label', true);
    if(exact.length) return exact.concat(loose);
    scan('th, td, legend, dt, span, p, div', false);
    return exact.concat(loose);
  }
  var CTRL='select, textarea, input:not([type=hidden]):not([type=button]):not([type=submit])';
  function controlsIn(node){
    if(!node) return [];
    var c=node.querySelectorAll(CTRL), list=[];
    for (var j=0;j<c.length;j++){ if(!c[j].disabled && !isOurs(c[j])) list.push(c[j]); }
    return list;
  }
  function isFieldLabel(el){ return el.tagName==='LABEL' && !el.querySelector('input,select,textarea'); }
  function controlsNear(labelEl){
    // 1) label の次の兄弟
    var list=controlsIn(labelEl.nextElementSibling); if(list.length) return list;
    // 2) label[for]
    if(labelEl.htmlFor){ var t=document.getElementById(labelEl.htmlFor); if(t&&!t.disabled) return [t]; }
    // 3) PORTERS編集画面：入力欄はラベルの「枠」の隣の枠にある。先祖を5段まで上りながら、後ろの兄弟を順に見る。
    //    次の項目のラベルに先に当たったら、そこで打ち切る（他の項目の入力欄を拾わない）
    var child=labelEl, node=labelEl.parentElement;
    for (var up=0; up<5 && node; up++){
      var s=child.nextElementSibling;
      while(s){
        if(s.matches&&s.matches(CTRL)&&!s.disabled&&!isOurs(s)) return [s];
        var lab=s.querySelector&&s.querySelector('label');
        var cs=controlsIn(s);
        if(cs.length){
          if(lab&&isFieldLabel(lab)&&(lab.compareDocumentPosition(cs[0])&Node.DOCUMENT_POSITION_FOLLOWING)) return [];
          return cs;
        }
        if(lab&&isFieldLabel(lab)) return [];
        s=s.nextElementSibling;
      }
      child=node; node=node.parentElement;
    }
    return [];
  }
  function findControls(label){
    var ls=labelNodes(label);
    for (var i=0;i<ls.length;i++){ var c=controlsNear(ls[i]); if(c.length) return c; }
    return [];
  }
  function setNative(el,value){
    var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:(el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype);
    var d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set) d.set.call(el,value); else el.value=value;
    el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true}));
    if(el.tagName==='INPUT') el.dispatchEvent(new Event('blur',{bubbles:true}));
  }
  function setChecked(el,on){
    if(el.checked===on) return true;
    el.click(); // React は実クリックが一番確実
    if(el.checked!==on){
      var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'checked'); d.set.call(el,on);
      el.dispatchEvent(new Event('click',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true}));
    }
    return el.checked===on;
  }
  function optText(el){ // checkbox/radio の表示名
    var l=el.closest('label'); if(l) return norm(l.textContent);
    if(el.id){ var l2=document.querySelector('label[for="'+el.id+'"]'); if(l2) return norm(l2.textContent); }
    return norm((el.nextSibling&&el.nextSibling.textContent)||el.parentElement.textContent);
  }
  function match(text,want){ text=norm(text); want=norm(want); if(!text||!want) return false; return text===want||text.indexOf(want)===0||(want.indexOf(text)===0&&text.length>=2); }
  function pickOption(opts, want){ // 完全一致 → 前方一致 → 部分一致
    var w=norm(want); if(!w) return null;
    var i, t;
    for (i=0;i<opts.length;i++){ if(norm(opts[i].text)===w) return opts[i]; }
    for (i=0;i<opts.length;i++){ t=norm(opts[i].text); if(t.length>=1&&t!=='-'&&(t.indexOf(w)===0||w.indexOf(t)===0&&t.length>=2)) return opts[i]; }
    for (i=0;i<opts.length;i++){ t=norm(opts[i].text); if(t.length>=2&&(t.indexOf(w)>=0||w.indexOf(t)>=0)) return opts[i]; }
    return null;
  }
  function numOf(s){ var m=String(s==null?'':s).replace(/[０-９]/g,function(c){return String.fromCharCode(c.charCodeAt(0)-0xFEE0);}).match(/\d+(\.\d+)?/); return m?parseFloat(m[0]):NaN; }
  function pickRadioByNumber(radios, n){ // 「30」→「30分以内」（以上で一番近い。無ければ最大）
    var best=null, bestN=Infinity, maxR=null, maxN=-Infinity;
    radios.forEach(function(r){ var k=numOf(optText(r)); if(isNaN(k)) return; if(k>=n&&k<bestN){best=r;bestN=k;} if(k>maxN){maxR=r;maxN=k;} });
    return best||maxR;
  }
  function isDateInput(c){ return c.tagName==='INPUT'&&/date-input/.test(c.className||''); }
  function isTimeInput(c){ return c.tagName==='INPUT'&&/time-input/.test(c.className||''); }
  function isTextCtrl(c){ return c.tagName==='TEXTAREA'||(c.tagName==='INPUT'&&/^(text|number|tel|search|datetime-local|date|time|)$/.test(c.type||'')); }
  function splitDt(v){ // "2026-09-04T13:30" / "2026-09-04 13:30" / "2026/09/04 13:30" → {d:'2026/09/04', t:'13:30'}
    var s=String(v||'').trim(); var m=s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2}))?/);
    if(!m) return {d:s,t:''};
    var p=function(x){return String(x).padStart(2,'0');};
    return {d:m[1]+'/'+p(m[2])+'/'+p(m[3]), t:m[4]?p(m[4])+':'+m[5]:''};
  }

  function writeOne(item){
    var cs=findControls(item.label); if(!cs.length) return 'missing';
    var val=item.value; var arr=Array.isArray(val)?val:[val];
    var sel=cs.filter(function(c){return c.tagName==='SELECT';})[0];
    var boxes=cs.filter(function(c){return c.type==='checkbox';});
    var radios=cs.filter(function(c){return c.type==='radio';});
    var dIn=cs.filter(isDateInput)[0], tIn=cs.filter(isTimeInput)[0];
    var text=cs.filter(function(c){return isTextCtrl(c)&&!isDateInput(c)&&!isTimeInput(c);})[0];
    // 日時：date-input と time-input に分けて入れる
    if(item.type==='dt'||dIn||tIn){
      var dt=splitDt(arr[0]);
      if(dIn||tIn){ if(dIn) setNative(dIn,dt.d); if(tIn&&dt.t) setNative(tIn,dt.t); return 'ok'; }
      if(text){ setNative(text, dt.d+(dt.t?' '+dt.t:'')); return 'ok'; }
    }
    if(sel){
      var opts=Array.prototype.slice.call(sel.options);
      var o=null; for (var i=0;i<arr.length&&!o;i++){ o=pickOption(opts,arr[i]); }
      if(!o) return 'nooption';
      setNative(sel,o.value); return 'ok';
    }
    if(boxes.length>1||(boxes.length===1&&Array.isArray(val))){
      var hit=0; boxes.forEach(function(b){ var on=arr.some(function(v){return match(optText(b),v);}); if(on) hit++; setChecked(b,on); });
      return hit?'ok':'nooption';
    }
    if(radios.length){
      var r=radios.filter(function(b){return arr.some(function(v){return match(optText(b),v);});})[0];
      if(!r){ var n=numOf(arr[0]); if(!isNaN(n)) r=pickRadioByNumber(radios,n); }
      if(!r) return 'nooption';
      return setChecked(r,true)?'ok':'nooption';
    }
    if(text){ setNative(text, Array.isArray(val)?val.join('／'):String(val)); return 'ok'; }
    if(boxes.length===1){ setChecked(boxes[0], /^(可|はい|あり|有|true|1)$/.test(String(val))); return 'ok'; }
    return 'missing';
  }
  function readOne(x){
    var cs=findControls(x.label); if(!cs.length) return null;
    var sel=cs.filter(function(c){return c.tagName==='SELECT';})[0];
    var boxes=cs.filter(function(c){return c.type==='checkbox';});
    var radios=cs.filter(function(c){return c.type==='radio';});
    var dIn=cs.filter(isDateInput)[0], tIn=cs.filter(isTimeInput)[0];
    var text=cs.filter(function(c){return isTextCtrl(c)&&!isDateInput(c)&&!isTimeInput(c);})[0];
    if(dIn||tIn){ var d=(dIn&&dIn.value||'').trim(), t=(tIn&&tIn.value||'').trim(); return d?(d+(t?' '+t:'')):''; }
    if(sel){ var o=sel.options[sel.selectedIndex]; return o&&o.value!==''&&o.text.trim()!=='-'?o.text.trim():''; }
    if(boxes.length>1) return boxes.filter(function(b){return b.checked;}).map(function(b){return optText(b);});
    if(radios.length){ var r=radios.filter(function(b){return b.checked;})[0]; return r?optText(r):''; }
    if(text) return text.value||'';
    if(boxes.length===1) return boxes[0].checked?'可':'';
    return null;
  }
  // 編集画面か：項目名の <label> の隣に入力欄がある
  function isEditing(){
    return findControls('入口メモ').length>0 || findControls('相手の状態').length>0 || findControls('事実メモ').length>0;
  }
  // 開いているレジュメ／求職者の見出し要素。PORTERS の詳細パネルは「きらさんテスト (12904)」のように名前＋IDの見出しを持つ。
  // 画面に見えているその形の要素のうち、いちばん大きい字のものを取る（一覧の行の名前は括弧IDが付かないので混ざらない）
  var NAME_ID_RE=/^(.{1,30}?)\s*[（(]\s*\d{3,8}\s*[)）]\s*$/;
  var nameEl=null;
  function findNameEl(){
    var best=null, bestSize=0;
    // 「きらさんテスト (12904)」が一つの要素でも、名前とIDが別の部品に分かれていても拾う：
    // 文字全体がその形に合う要素のうち、いちばん内側（子にも同じ形の要素が無い）で、いちばん字が大きいもの
    var all=document.querySelectorAll('h1,h2,h3,h4,b,strong,span,div,p,a');
    for(var i=0;i<all.length;i++){
      var el=all[i]; if(isOurs(el)) continue;
      var t=(el.textContent||'').replace(/\s+/g,' ').trim(); if(t.length>40||!NAME_ID_RE.test(t)) continue;
      var inner=false; for(var c=0;c<el.children.length;c++){ var ct=(el.children[c].textContent||'').replace(/\s+/g,' ').trim(); if(NAME_ID_RE.test(ct)){ inner=true; break; } }
      if(inner) continue;
      if(!el.getClientRects().length) continue;
      var fs=parseFloat(getComputedStyle(el).fontSize)||0;
      if(fs>bestSize){ bestSize=fs; best=el; }
    }
    return best;
  }
  function personName(){
    // 相手の名前は、開いているレジュメ／求職者の見出しからだけ拾う。一覧や検索の見出しは拾わない
    nameEl=null;
    var dlg=document.querySelector('[role=dialog]'); var h=dlg?dlg.querySelector('h1,h2,h3'):null;
    var t=(h?h.textContent:'').trim();
    if(!t||!NAME_ID_RE.test(t)){ var ne=findNameEl(); if(ne){ nameEl=ne; t=(ne.textContent||'').trim(); } }
    if(!t){ var m=(document.title||'').match(/^(.+?)\s*[-|｜]/); if(m) t=m[1].trim(); }
    if(!t||/一覧|検索|条件|設定|レポート|PORTERS/.test(t)) return '';
    return t.replace(/\s*[（(]\s*\d+\s*[)）]\s*$/,'').slice(0,20);
  }
  // 別窓（モニター側に出す）。開いている間は板ではなく別窓と話す
  var popWin=null, POP_ORIGIN=null;
  function popAlive(){ try{ return !!(popWin&&!popWin.closed); }catch(err){ return false; } }
  function post(m){ if(popAlive()){ popWin.postMessage(m,POP_ORIGIN||FRAME_ORIGIN); return; } if(frame&&frame.contentWindow) frame.contentWindow.postMessage(m,FRAME_ORIGIN); }
  function openPop(){
    if(popAlive()){ try{ popWin.focus(); }catch(err){} sendCtx(); return; }
    var url=(USE_REMOTE&&readySeen&&FRAME_ORIGIN===SITE_ORIGIN)||(USE_REMOTE&&!readySeen)?REMOTE_URL:chrome.runtime.getURL('hearing.html');
    popWin=window.open(url,'glh-pop','popup=yes,width=1200,height=840'); POP_ORIGIN=null;
    if(popWin){ toggle(false); }
  }
  // 開いているレジュメ（右の詳細か編集画面）の電話番号。「電話」の項目名の近くにある番号を優先し、無ければ画面内の最初の番号
  function personTel(){
    try{
      // 探す範囲：見出しが見つかっていればその詳細パネル（見出しの先祖で、電話番号を含むいちばん近い箱）。無ければダイアログ、無ければ画面全体
      var scope=null;
      if(nameEl){ var anc=nameEl.parentElement; for(var k=0;k<12&&anc&&anc!==document.body;k++){ if(TEL_RE.test(anc.innerText||'')){ scope=anc; break; } anc=anc.parentElement; } }
      if(!scope) scope=document.querySelector('[role=dialog]')||document.body;
      var labs=[].slice.call(scope.querySelectorAll('th,td,label,span,div')).filter(function(el){ return !isOurs(el)&&el.children.length===0&&/^電話/.test((el.textContent||'').trim()); });
      for(var i=0;i<labs.length;i++){ var row=labs[i].closest('tr')||labs[i].parentElement; var m=row&&(row.innerText||'').match(TEL_RE); if(m){ var d=normTel(m[0]); if(d) return fmtTel(d); } }
      var m2=(scope.innerText||'').match(TEL_RE); if(m2){ var d2=normTel(m2[0]); if(d2) return fmtTel(d2); }
    }catch(err){}
    return '';
  }
  function sendCtx(){
    var name='', tel=''; try{ name=personName(); }catch(err){} try{ tel=personTel(); }catch(err){}
    try{ if(headSub) headSub.textContent=name?('相手　'+name):''; }catch(err){} // 板の見出しに相手の名前
    post({type:'glh-context',editing:isEditing(),name:name,tel:tel});
  }
  // 書いたあと、編集ウィンドウの「保存」が見える位置まで送る（板を × で閉じたらすぐ押せるように）。閉じるのは人が押す
  function findSave(){
    var all=document.querySelectorAll('button, input[type=submit], input[type=button]'), hit=null;
    for (var i=0;i<all.length;i++){
      var b=all[i]; if(isOurs(b)) continue;
      var t=(b.tagName==='INPUT'?b.value:b.textContent)||''; if(t.trim()!=='保存') continue;
      if(!b.getClientRects().length) continue; // 表示されていない
      hit=b; if(b.closest&&b.closest('[role="dialog"]')) break; // 編集ウィンドウの中のものを優先
    }
    return hit;
  }
  function ensureStyle(){
    if(document.getElementById('glh-style')) return;
    var st=document.createElement('style'); st.id='glh-style';
    st.textContent='@keyframes glhPulse{0%{box-shadow:0 0 0 0 rgba(183,155,219,.95)}100%{box-shadow:0 0 0 16px rgba(183,155,219,0)}}'
      +'.glh-save-glow{animation:glhPulse 1.1s ease-out infinite!important;outline:3px solid #B79BDB!important;outline-offset:2px!important}'
      +'#glh-save-banner{position:fixed;z-index:2147483002;left:50%;top:14px;transform:translateX(-50%);display:flex;align-items:center;gap:12px;background:linear-gradient(90deg,#C9D8F2,#F4DCE0);color:#2B3A55;font:600 14px/1.4 "Zen Kaku Gothic New","Noto Sans JP",-apple-system,"Hiragino Sans",sans-serif;padding:10px 14px 10px 16px;border-radius:999px;box-shadow:0 12px 30px -10px rgba(43,58,85,.45);border:1px solid rgba(255,255,255,.7)}'
      +'#glh-save-banner button{font:700 13px "Zen Kaku Gothic New","Noto Sans JP",sans-serif;border:0;border-radius:999px;padding:6px 14px;cursor:pointer;background:#2B3A55;color:#fff}'
      +'#glh-save-banner button.x{background:transparent;color:#2B3A55;padding:6px 8px;font-size:16px}';
    document.documentElement.appendChild(st);
  }
  var saveTimer=null;
  function clearSaveGuide(){
    var b=document.getElementById('glh-save-banner'); if(b) b.remove();
    var g=document.querySelector('.glh-save-glow'); if(g) g.classList.remove('glh-save-glow');
    if(saveTimer){ clearInterval(saveTimer); saveTimer=null; }
  }
  // 書いたあと：「保存」を光らせ、上に案内を出す。保存が押されるか、編集ウィンドウが閉じるまで残す
  function scrollToSave(count){
    try{
      ensureStyle(); clearSaveGuide();
      var hit=findSave(); if(!hit) return;
      hit.classList.add('glh-save-glow'); hit.scrollIntoView({block:'center'});
      var bn=document.createElement('div'); bn.id='glh-save-banner';
      var msg=document.createElement('span'); msg.textContent=(count?count+'項目を入れました。':'入れました。')+'編集ウィンドウ下の「保存」を押すと確定します';
      var go=document.createElement('button'); go.type='button'; go.textContent='保存へ'; go.addEventListener('click',function(){ var h=findSave(); if(h){ h.scrollIntoView({block:'center'}); h.classList.add('glh-save-glow'); } });
      var x=document.createElement('button'); x.type='button'; x.className='x'; x.textContent='×'; x.addEventListener('click',clearSaveGuide);
      bn.appendChild(msg); bn.appendChild(go); bn.appendChild(x); document.body.appendChild(bn);
      hit.addEventListener('click',clearSaveGuide,{once:true});
      var n=0; saveTimer=setInterval(function(){ n++; if(!isEditing()||!document.contains(hit)||n>240) clearSaveGuide(); },500);
    }catch(err){}
  }

  // 開いているレジュメの「編集」ボタン（拡張のものではない、見えているもの）
  function clickEdit(){
    try{
      var all=document.querySelectorAll('button'); 
      for(var i=0;i<all.length;i++){ var b=all[i]; if(isOurs(b)) continue; if((b.textContent||'').trim()!=='編集') continue; if(!b.getClientRects().length) continue; b.click(); return true; }
    }catch(err){}
    return false;
  }
  function doWrite(items,fromPop){
    var written=[],missing=[],noopt=[];
    if(!isEditing()){
      post({type:'glh-result',written:[],missing:items.map(function(it){return it.label;}),note:'※ レジュメの編集画面が開いていないので入りません。レジュメを開いて「編集」を押してから、もう一度。'});
      return;
    }
    items.forEach(function(it){ var r; try{ r=writeOne(it);}catch(err){ r='missing'; }
      if(r==='ok') written.push(it.label); else if(r==='nooption') noopt.push(it.label+'（選択肢に無い）'); else missing.push(it.label); });
    var saveBtn=written.length?findSave():null;
    var note=written.length?(saveBtn?'PORTERSに書き込み、続けて「保存」を押しました。':'書き込みました。編集ウィンドウ下の「保存」を押して確定してください。'):'入れられる項目がありませんでした。';
    post({type:'glh-result',written:written,missing:missing.concat(noopt),note:note});
    if(written.length){
      if(!fromPop) toggle(false); try{ window.focus(); }catch(err){}
      if(saveBtn){ setTimeout(function(){ try{ saveBtn.click(); }catch(err){} ensureStyle(); clearSaveGuide(); flash(written.length+'項目を入れて「保存」を押しました'); },350); }
      else setTimeout(function(){ scrollToSave(written.length); },250);
    }
  }
  function flash(text){
    try{ var bn=document.createElement('div'); bn.id='glh-save-banner'; var m=document.createElement('span'); m.textContent=text; bn.appendChild(m); document.body.appendChild(bn); setTimeout(function(){ bn.remove(); },5000); }catch(err){}
  }

  // ===== 版の見張り：サイトの version.json と自分の版を比べ、古ければPORTERSの画面に案内の帯を出す =====
  function cmpVer(a,b){ var x=String(a).split('.').map(Number), y=String(b).split('.').map(Number); for(var i=0;i<3;i++){ var d=(y[i]||0)-(x[i]||0); if(d) return d; } return 0; }
  function checkUpdate(){
    try{
      var mine=chrome.runtime.getManifest().version;
      fetch(SITE_ORIGIN+'/gl-hearing/version.json?n='+Date.now(),{cache:'no-store'}).then(function(r){ return r.json(); }).then(function(v){
        if(!v||!v.ext||cmpVer(mine,v.ext)<=0) return;
        var key='glh_skip_'+v.ext; try{ if(sessionStorage.getItem(key)) return; }catch(err){}
        ensureStyle();
        var bn=document.createElement('div'); bn.id='glh-update-banner';
        bn.style.cssText='position:fixed;z-index:2147483002;left:50%;top:14px;transform:translateX(-50%);display:flex;align-items:center;gap:12px;background:linear-gradient(90deg,#C9D8F2,#F4DCE0);color:#2B3A55;font:600 13.5px/1.4 "Zen Kaku Gothic New","Noto Sans JP",-apple-system,"Hiragino Sans",sans-serif;padding:9px 12px 9px 16px;border-radius:999px;box-shadow:0 12px 30px -10px rgba(43,58,85,.45);border:1px solid rgba(255,255,255,.7)';
        var m=document.createElement('span'); m.textContent='GL ヒアリング拡張の新しい版 '+v.ext+' があります（いま '+mine+'）';
        // zip は版ごとに別のURL（?v=）で取る。GitHub Pages が10分だけ古い zip を配ることがあり、それを掴ませない
        var zipUrl=(v.zip||(SITE_ORIGIN+'/gl-hearing/ext.zip'))+'?v='+encodeURIComponent(v.ext);
        var a=document.createElement('a'); a.href=zipUrl; a.textContent='ダウンロード'; a.style.cssText='font-weight:700;border-radius:999px;padding:5px 12px;background:#2B3A55;color:#fff;text-decoration:none';
        var how=document.createElement('span'); how.textContent='→ 解凍して同じフォルダに上書き → chrome://extensions で「更新（↻）」→ PORTERSを再読み込み。フォルダが自動で同期されているMacなら ↻ だけでよい'; how.style.cssText='font-weight:500;color:#5A6275';
        var x=document.createElement('button'); x.type='button'; x.textContent='×'; x.style.cssText='border:0;background:transparent;font-size:16px;cursor:pointer;color:#2B3A55'; x.addEventListener('click',function(){ bn.remove(); try{ sessionStorage.setItem(key,'1'); }catch(err){} });
        bn.appendChild(m); bn.appendChild(a); bn.appendChild(how); bn.appendChild(x); document.body.appendChild(bn);
      }).catch(function(){});
    }catch(err){}
  }
  setTimeout(checkUpdate,3000);

  // ===== メッセージ（相手は板の iframe だけ。origin はサイトのものに限る） =====
  window.addEventListener('message',function(e){
    var fromPop=popAlive()&&e.source===popWin; var fromFrame=frame&&e.source===frame.contentWindow;
    if(!fromPop&&!fromFrame) return;
    if(!isFrameOrigin(e.origin)) return; // サイト（github.io）か、同梱に戻したときは拡張の origin
    var d=e.data||{}; if(typeof d.type!=='string'||d.type.indexOf('glh-')!==0) return;
    if(d.type==='glh-ready'){ if(fromPop){ POP_ORIGIN=e.origin; } else { readySeen=true; FRAME_ORIGIN=e.origin; } sendCtx(); }
    if(d.type==='glh-write'){
      var items=d.items||[];
      // 編集画面でなければ、開いているレジュメの「編集」を押して開くのを待つ（最大4秒）
      if(!isEditing()&&clickEdit()){
        var waited=0; var tm=setInterval(function(){ waited+=200; if(isEditing()||waited>=4000){ clearInterval(tm); doWrite(items,fromPop); } },200);
      } else doWrite(items,fromPop);
    }
    if(d.type==='glh-dial'){ dialTel(d.tel); }
    if(d.type==='glh-scan-phones'){ var items=[]; try{ items=scanPhones(); }catch(err){} post({type:'glh-phones',items:items}); }
    if(d.type==='glh-read'){
      var labels=d.labels||[];
      var doRead=function(){ var vals=[]; labels.forEach(function(x){ var v; try{ v=readOne(x);}catch(err){ v=null; } if(v!=null) vals.push({id:x.id,value:v}); }); post({type:'glh-values',values:vals}); };
      // 読めるのは編集画面の入力欄だけ。開いていなければ「編集」を押して開いてから読む
      if(!isEditing()&&clickEdit()){ var w2=0; var t2=setInterval(function(){ w2+=200; if(isEditing()||w2>=4000){ clearInterval(t2); doRead(); } },200); }
      else doRead();
    }
  });

  // ===== 電話：発信と、画面の番号拾い =====
  // 発信は tel: リンクと同じ（Mac の「iPhoneから通話」が有効なら FaceTime 経由で iPhone の回線から出る）。
  // 初回だけ Chrome が「FaceTime を開きますか」と聞く（「常に許可」で次から出ない）。macOS 側の確認は毎回出る
  var TEL_RE=/0\d{1,4}[-‐−–ー]?\d{1,4}[-‐−–ー]?\d{3,4}/g;
  function normTel(t){ var d=String(t||'').replace(/[^\d]/g,''); return (d.length===10||d.length===11)?d:''; }
  function fmtTel(d){ if(d.length===11) return d.replace(/(\d{3})(\d{4})(\d{4})/,'$1-$2-$3'); if(/^0[3-9]\d{8}$/.test(d)&&/^0(3|6)/.test(d)) return d.replace(/(\d{2})(\d{4})(\d{4})/,'$1-$2-$3'); return d.replace(/(\d{3,4})(\d{2,3})(\d{4})/,'$1-$2-$3'); }
  function dialTel(tel){ var d=normTel(tel); if(!d) return; try{ window.location.href='tel:'+d; }catch(err){} }
  function textNodesWithTel(){
    var out=[]; var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){
      if(!n.nodeValue||n.nodeValue.length<10) return NodeFilter.FILTER_REJECT;
      var p=n.parentElement; if(!p||isOurs(p)) return NodeFilter.FILTER_REJECT;
      var tag=p.tagName; if(tag==='SCRIPT'||tag==='STYLE'||tag==='TEXTAREA'||tag==='NOSCRIPT') return NodeFilter.FILTER_REJECT;
      return TEL_RE.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT; }});
    var n; while((n=w.nextNode())&&out.length<400) out.push(n);
    return out;
  }
  function rowName(node,tel){
    // 番号の行（tr / li / role=row / データグリッドの行）から、名前らしい文字列を拾う。無ければ空
    var row=node.parentElement&&node.parentElement.closest('tr, li, [role="row"], [class*="MuiDataGrid-row"], [class*="row"]');
    if(!row) return '';
    var t=(row.innerText||'').split(/\n+/).map(function(x){ return x.trim(); }).filter(function(x){ return x&&x.replace(/[^\d]/g,'')!==tel&&!/^[\d\-‐−–ー\s()（）]+$/.test(x); });
    var cand=t.find(function(x){ return /[぀-ヿ一-龯]/.test(x)&&x.length<=24; })||'';
    return cand;
  }
  function scanPhones(){
    var seen={}, items=[];
    textNodesWithTel().forEach(function(n){
      var m=n.nodeValue.match(TEL_RE)||[];
      m.forEach(function(raw){ var d=normTel(raw); if(!d||seen[d]) return; seen[d]=1; items.push({n:rowName(n,d),tel:fmtTel(d),memo:''}); });
    });
    return items.slice(0,300);
  }
  // 画面の番号の横に📞（押すと発信）。PORTERS の DOM は触らず、うちの層に重ねて置く（React が壊れない）
  var badgeWrap=null, badgeTimer=null;
  function placeBadges(){
    if(!shadow) return;
    if(!badgeWrap){ badgeWrap=document.createElement('div'); badgeWrap.className='glh-badges'; shadow.appendChild(badgeWrap); }
    badgeWrap.textContent='';
    // 板ごと PORTERS の編集画面（transform 付きの層）の中に置き直されることがあり、その中では position:fixed が
    // 画面ではなくその層の左上基準になる。層の左上の位置ぶんを引いて、画面の座標に合わせる
    var base=badgeWrap.getBoundingClientRect(); var offX=base.left||0, offY=base.top||0;
    var nodes=textNodesWithTel(), count=0;
    nodes.forEach(function(n){
      if(count>=80) return;
      var text=n.nodeValue, re=new RegExp(TEL_RE.source,'g'), m;
      while((m=re.exec(text))&&count<80){
        var d=normTel(m[0]); if(!d) continue;
        var r=document.createRange(); r.setStart(n,m.index); r.setEnd(n,m.index+m[0].length);
        var rect=r.getBoundingClientRect(); if(!rect.width||rect.bottom<0||rect.top>innerHeight) continue;
        var b=document.createElement('button'); b.type='button'; b.className='glh-tel'; b.textContent='📞'; b.title='iPhone でかける：'+fmtTel(d);
        // 番号の左に置く（右は隣の列の文字と被る）。左に余白が無いときだけ右
        var bx=(rect.left>=30)?(rect.left-26):(rect.right+4);
        b.style.left=(bx-offX)+'px'; b.style.top=(rect.top+rect.height/2-11-offY)+'px';
        (function(dd){ b.addEventListener('click',function(ev){ ev.preventDefault(); ev.stopPropagation(); dialTel(dd); }); })(d);
        badgeWrap.appendChild(b); count++;
      }
    });
  }
  function scheduleBadges(){ if(badgeTimer) return; badgeTimer=setTimeout(function(){ badgeTimer=null; try{ placeBadges(); }catch(err){} },350); }
  function watchBadges(){
    try{
      new MutationObserver(scheduleBadges).observe(document.body,{childList:true,subtree:true,characterData:true});
      window.addEventListener('scroll',scheduleBadges,true); window.addEventListener('resize',scheduleBadges);
      setTimeout(scheduleBadges,1500);
    }catch(err){}
  }

  // ===== UI =====
  function h(tag,attrs,children){ var el=document.createElement(tag); attrs=attrs||{}; Object.keys(attrs).forEach(function(k){ if(k==='class') el.className=attrs[k]; else if(k==='text') el.textContent=attrs[k]; else el.setAttribute(k,attrs[k]); }); (children||[]).forEach(function(c){ if(c) el.appendChild(c); }); return el; }
  function buildPanel(){
    if(document.getElementById('gl-hearing-ext-root')) return;
    root=document.createElement('div'); root.id='gl-hearing-ext-root';
    shadow=root.attachShadow({mode:'open'});
    var link=document.createElement('link'); link.rel='stylesheet'; link.href=chrome.runtime.getURL('panel.css'); shadow.appendChild(link);
    var wrap=h('div',{class:'glh-root'}); shadow.appendChild(wrap);
    var fab=h('button',{class:'glh-fab',type:'button',text:'ヒアリング'}); fab.addEventListener('click',function(){ if(popAlive()){ openPop(); } else toggle(true); }); wrap.appendChild(fab);
    // 分析への入口：営業ボード（鍵付きサイト）。PORTERSの中には埋め込めないので、別タブで開く
    var ana=h('a',{class:'glh-fab glh-fab-ana',href:BOARD_URL,target:'_blank',rel:'noopener',text:'分析'}); wrap.appendChild(ana);
    panelEl=h('div',{class:'glh-panel',hidden:'hidden'});
    headSub=h('span',{class:'glh-url',text:''});
    var head=h('div',{class:'glh-head'},[h('b',{text:'GL ヒアリング'}),headSub]);
    var pop=h('button',{class:'glh-close glh-pop',type:'button',text:'別窓',title:'別の窓に出す（モニター側に動かせる）'}); pop.addEventListener('click',openPop);
    var wide=h('button',{class:'glh-close',type:'button',text:'⇔',title:'幅を切り替え'}); wide.addEventListener('click',function(){ panelEl.classList.toggle('wide'); });
    var close=h('button',{class:'glh-close',type:'button',text:'×',title:'閉じる'}); close.addEventListener('click',function(){ toggle(false); });
    head.appendChild(pop); head.appendChild(wide); head.appendChild(close); panelEl.appendChild(head);
    frame=h('iframe',{class:'glh-frame',allow:'microphone',src:USE_REMOTE?REMOTE_URL:chrome.runtime.getURL('hearing.html')});
    panelEl.appendChild(frame);
    // サイト側が読めない（未公開・通信不可）ときは、同梱の画面に切り替える
    // サイト側が読めない（未公開・通信不可）ときだけ、同梱の画面に切り替える。
    // 合言葉の入力中（サイトは読めている）は落とさない：iframe の load が来たかで判断する
    var frameLoaded=false; frame.addEventListener('load',function(){ frameLoaded=true; });
    if(USE_REMOTE){ setTimeout(function(){ if(!readySeen&&!frameLoaded){ try{ frame.src=chrome.runtime.getURL('hearing.html'); FRAME_ORIGIN=EXT_ORIGIN; }catch(err){} } },8000); }
    wrap.appendChild(panelEl); document.documentElement.appendChild(root);
  }
  var ctxTimer=null, lastCtx='';
  function sendCtxIfChanged(){ var name='',tel=''; try{ name=personName(); }catch(err){} try{ tel=personTel(); }catch(err){} var key=name+'|'+tel+'|'+(isEditing()?1:0); if(key===lastCtx) return; lastCtx=key; sendCtx(); }
  function toggle(open){
    if(!panelEl) return;
    if(open){ panelEl.removeAttribute('hidden'); lastCtx=''; sendCtx(); if(!ctxTimer) ctxTimer=setInterval(function(){ try{ if(!panelEl.hasAttribute('hidden')||popAlive()) sendCtxIfChanged(); }catch(err){} },3000); }
    else panelEl.setAttribute('hidden','hidden');
  }
  // PORTERSの編集画面（モーダル）は焦点を自分の中に閉じ込める（50msごとに奪い返す）ので、
  // 編集画面が開いている間は板をその内側に置き直す。閉じたら元に戻す。見た目は変わらない。
  function findModal(){
    var ds=document.querySelectorAll('[role="dialog"], .MuiDialog-root, [class*="MuiModal-root"], [class*="MuiDialog-root"]');
    for (var i=ds.length-1;i>=0;i--){ var d=ds[i]; if(isOurs(d)) continue; if(d.getClientRects().length) return d; }
    return null;
  }
  var reparentTimer=null;
  function reparent(){
    if(!root) return;
    var m=findModal();
    var host=m? (m.closest('[class*="MuiModal-root"]')||m) : document.documentElement;
    if(root.parentNode!==host){ try{ host.appendChild(root); }catch(err){} }
  }
  function watchModals(){
    try{
      new MutationObserver(function(){ if(reparentTimer) return; reparentTimer=setTimeout(function(){ reparentTimer=null; reparent(); },150); })
        .observe(document.body,{childList:true,subtree:false});
      setInterval(reparent,1500);
    }catch(err){}
  }
  // 上のタブ（求職者／レジュメ／…）は PORTERS では「押すとメニューが開く」だけ。
  // 押したらその一覧へ移るようにする（メニュー&一覧の menu_id を li の id から読む）。マウスオーバーのメニューは PORTERS のまま。
  var LIST_PATH={ 'person-menu':'/can/search', 'resume-menu':'/resume/search', 'process-menu':'/process/search', 'job-menu':'/job/search', 'recruiter-menu':'/recf/search', 'report-menu':'/report' };
  function listUrlFor(li){
    var cls=(li.className||'').match(/\b([a-z]+-menu)\b/); var idm=(li.id||'').match(/main-menu-id-(\d+)/);
    if(!cls||!LIST_PATH[cls[1]]) return null;
    var path=LIST_PATH[cls[1]];
    return path+(idm&&path!=='/report'?'?menu_id='+idm[1]:'');
  }
  function tabClickToList(){
    var handler=function(e){
      try{
        var a=e.target.closest&&e.target.closest('#main-menu > li > a'); if(!a) return;
        var li=a.parentElement; var url=listUrlFor(li);
        if(!url){ // 経路が分からないメニュー（法人など）は、中の「検索」を押したことにする
          var as=li.querySelectorAll('ul a'), pick=null;
          for (var j=0;j<as.length;j++){ if((as[j].textContent||'').trim()==='検索'){ pick=as[j]; break; } }
          if(!pick) return;
          e.preventDefault(); e.stopPropagation(); if(e.type==='click') pick.click(); return;
        }
        e.preventDefault(); e.stopPropagation();
        if(e.type==='click') location.assign(url);
      }catch(err){}
    };
    document.addEventListener('mousedown',handler,true);
    document.addEventListener('click',handler,true);
  }
  // 一覧を開くと PORTERS が「検索条件」の窓を自動で開いて 0件のまま止まる。
  // 窓が開いていたら「検索する」を一度押して、一覧をそのまま出す（条件はPORTERSの既定のまま）。
  function autoRunSearch(){
    var tries=0;
    var t=setInterval(function(){
      tries++;
      try{
        var head=[...document.querySelectorAll('h1,h2,h3,div,span')].find(function(e){ return !isOurs(e)&&e.children.length===0&&/一覧\s*検索条件$/.test((e.textContent||'').replace(/\s+/g,' ').trim()); });
        var btn=[...document.querySelectorAll('button')].find(function(b){ return !isOurs(b)&&b.getClientRects().length&&/^検索する$/.test((b.textContent||'').trim()); });
        var zero=/検索結果：0件/.test(document.body.innerText||'');
        if(head&&btn&&zero){ btn.click(); clearInterval(t); return; }
      }catch(err){}
      if(tries>8) clearInterval(t);
    },800);
  }
  function init(){ buildPanel(); watchModals(); tabClickToList(); autoRunSearch(); watchBadges(); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
